(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var getSlug;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/ongoworks_speakingurl/packages/ongoworks_speakingurl.js       //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/ongoworks:speakingurl/speakingurl.js                     //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
getSlug = Npm.require('speakingurl');                                // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////   // 11
                                                                          // 12
}).call(this);                                                            // 13
                                                                          // 14
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ongoworks:speakingurl'] = {
  getSlug: getSlug
};

})();

//# sourceMappingURL=ongoworks_speakingurl.js.map
