(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/cards.js                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('card', function (cardId) {                             // 1
  check(cardId, String);                                               // 2
  return Cards.find({ _id: cardId });                                  // 3
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=cards.js.map
