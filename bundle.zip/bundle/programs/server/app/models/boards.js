(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/boards.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Boards = new Mongo.Collection('boards');                               // 1
                                                                       //
Boards.attachSchema(new SimpleSchema({                                 // 3
  title: {                                                             // 4
    type: String                                                       // 5
  },                                                                   //
  slug: {                                                              // 7
    type: String                                                       // 8
  },                                                                   //
  archived: {                                                          // 10
    type: Boolean                                                      // 11
  },                                                                   //
  createdAt: {                                                         // 13
    type: Date,                                                        // 14
    denyUpdate: true                                                   // 15
  },                                                                   //
  // XXX Inconsistent field naming                                     //
  modifiedAt: {                                                        // 18
    type: Date,                                                        // 19
    denyInsert: true,                                                  // 20
    optional: true                                                     // 21
  },                                                                   //
  // De-normalized number of users that have starred this board        //
  stars: {                                                             // 24
    type: Number                                                       // 25
  },                                                                   //
  // De-normalized label system                                        //
  'labels.$._id': {                                                    // 28
    // We don't specify that this field must be unique in the board because that
    // will cause performance penalties and is not necessary since this field is
    // always set on the server.                                       //
    // XXX Actually if we create a new label, the `_id` is set on the client
    // without being overwritten by the server, could it be a problem?
    type: String                                                       // 34
  },                                                                   //
  'labels.$.name': {                                                   // 36
    type: String,                                                      // 37
    optional: true                                                     // 38
  },                                                                   //
  'labels.$.color': {                                                  // 40
    type: String,                                                      // 41
    allowedValues: ['green', 'yellow', 'orange', 'red', 'purple', 'blue', 'sky', 'lime', 'pink', 'black']
  },                                                                   //
  // XXX We might want to maintain more informations under the member sub-
  // documents like de-normalized meta-data (the date the member joined the
  // board, the number of contributions, etc.).                        //
  'members.$.userId': {                                                // 50
    type: String                                                       // 51
  },                                                                   //
  'members.$.isAdmin': {                                               // 53
    type: Boolean                                                      // 54
  },                                                                   //
  'members.$.isActive': {                                              // 56
    type: Boolean                                                      // 57
  },                                                                   //
  permission: {                                                        // 59
    type: String,                                                      // 60
    allowedValues: ['public', 'private']                               // 61
  },                                                                   //
  color: {                                                             // 63
    type: String,                                                      // 64
    allowedValues: ['belize', 'nephritis', 'pomegranate', 'pumpkin', 'wisteria', 'midnight']
  },                                                                   //
  description: {                                                       // 74
    type: String,                                                      // 75
    optional: true                                                     // 76
  }                                                                    //
}));                                                                   //
                                                                       //
Boards.helpers({                                                       // 81
  /**                                                                  //
   * Is supplied user authorized to view this board?                   //
   */                                                                  //
  isVisibleBy: function (user) {                                       // 85
    if (this.isPublic()) {                                             // 86
      // public boards are visible to everyone                         //
      return true;                                                     // 88
    } else {                                                           //
      // otherwise you have to be logged-in and active member          //
      return user && this.isActiveMember(user._id);                    // 91
    }                                                                  //
  },                                                                   //
                                                                       //
  /**                                                                  //
   * Is the user one of the active members of the board?               //
   *                                                                   //
   * @param userId                                                     //
   * @returns {boolean} the member that matches, or undefined/false    //
   */                                                                  //
  isActiveMember: function (userId) {                                  // 101
    if (userId) {                                                      // 102
      return this.members.find(function (member) {                     // 103
        return member.userId === userId && member.isActive;            //
      });                                                              //
    } else {                                                           //
      return false;                                                    // 105
    }                                                                  //
  },                                                                   //
                                                                       //
  isPublic: function () {                                              // 109
    return this.permission === 'public';                               // 110
  },                                                                   //
                                                                       //
  lists: function () {                                                 // 113
    return Lists.find({ boardId: this._id, archived: false }, { sort: { sort: 1 } });
  },                                                                   //
                                                                       //
  activities: function () {                                            // 117
    return Activities.find({ boardId: this._id }, { sort: { createdAt: -1 } });
  },                                                                   //
                                                                       //
  activeMembers: function () {                                         // 121
    return _.where(this.members, { isActive: true });                  // 122
  },                                                                   //
                                                                       //
  activeAdmins: function () {                                          // 125
    return _.where(this.members, { isActive: true, isAdmin: true });   // 126
  },                                                                   //
                                                                       //
  memberUsers: function () {                                           // 129
    return Users.find({ _id: { $in: _.pluck(this.members, 'userId') } });
  },                                                                   //
                                                                       //
  getLabel: function (name, color) {                                   // 133
    return _.findWhere(this.labels, { name: name, color: color });     // 134
  },                                                                   //
                                                                       //
  labelIndex: function (labelId) {                                     // 137
    return _.pluck(this.labels, '_id').indexOf(labelId);               // 138
  },                                                                   //
                                                                       //
  memberIndex: function (memberId) {                                   // 141
    return _.pluck(this.members, 'userId').indexOf(memberId);          // 142
  },                                                                   //
                                                                       //
  hasMember: function (memberId) {                                     // 145
    return !!_.findWhere(this.members, { userId: memberId, isActive: true });
  },                                                                   //
                                                                       //
  hasAdmin: function (memberId) {                                      // 149
    return !!_.findWhere(this.members, { userId: memberId, isActive: true, isAdmin: true });
  },                                                                   //
                                                                       //
  absoluteUrl: function () {                                           // 153
    return FlowRouter.path('board', { id: this._id, slug: this.slug });
  },                                                                   //
                                                                       //
  colorClass: function () {                                            // 157
    return 'board-color-' + this.color;                                // 158
  },                                                                   //
                                                                       //
  // XXX currently mutations return no value so we have an issue when using addLabel in import
  // XXX waiting on https://github.com/mquandalle/meteor-collection-mutations/issues/1 to remove...
  pushLabel: function (name, color) {                                  // 163
    var _id = Random.id(6);                                            // 164
    Boards.direct.update(this._id, { $push: { labels: { _id: _id, name: name, color: color } } });
    return _id;                                                        // 166
  }                                                                    //
});                                                                    //
                                                                       //
Boards.mutations({                                                     // 170
  archive: function () {                                               // 171
    return { $set: { archived: true } };                               // 172
  },                                                                   //
                                                                       //
  restore: function () {                                               // 175
    return { $set: { archived: false } };                              // 176
  },                                                                   //
                                                                       //
  rename: function (title) {                                           // 179
    return { $set: { title: title } };                                 // 180
  },                                                                   //
                                                                       //
  setDesciption: function (description) {                              // 183
    return { $set: { description: description } };                     // 184
  },                                                                   //
                                                                       //
  setColor: function (color) {                                         // 187
    return { $set: { color: color } };                                 // 188
  },                                                                   //
                                                                       //
  setVisibility: function (visibility) {                               // 191
    return { $set: { permission: visibility } };                       // 192
  },                                                                   //
                                                                       //
  addLabel: function (name, color) {                                   // 195
    // If label with the same name and color already exists we don't want to
    // create another one because they would be indistinguishable in the UI
    // (they would still have different `_id` but that is not exposed to the
    // user).                                                          //
    if (!this.getLabel(name, color)) {                                 // 200
      var _id = Random.id(6);                                          // 201
      return { $push: { labels: { _id: _id, name: name, color: color } } };
    }                                                                  //
  },                                                                   //
                                                                       //
  editLabel: function (labelId, name, color) {                         // 206
    if (!this.getLabel(name, color)) {                                 // 207
      var _$set;                                                       //
                                                                       //
      var labelIndex = this.labelIndex(labelId);                       // 208
      return {                                                         // 209
        $set: (_$set = {}, _$set['labels.' + labelIndex + '.name'] = name, _$set['labels.' + labelIndex + '.color'] = color, _$set)
      };                                                               //
    }                                                                  //
  },                                                                   //
                                                                       //
  removeLabel: function (labelId) {                                    // 218
    return { $pull: { labels: { _id: labelId } } };                    // 219
  },                                                                   //
                                                                       //
  addMember: function (memberId) {                                     // 222
    var memberIndex = this.memberIndex(memberId);                      // 223
    if (memberIndex >= 0) {                                            // 224
      var _$set2;                                                      //
                                                                       //
      return {                                                         // 225
        $set: (_$set2 = {}, _$set2['members.' + memberIndex + '.isActive'] = true, _$set2)
      };                                                               //
    }                                                                  //
                                                                       //
    return {                                                           // 232
      $push: {                                                         // 233
        members: {                                                     // 234
          userId: memberId,                                            // 235
          isAdmin: false,                                              // 236
          isActive: true                                               // 237
        }                                                              //
      }                                                                //
    };                                                                 //
  },                                                                   //
                                                                       //
  removeMember: function (memberId) {                                  // 243
    var _$set4;                                                        //
                                                                       //
    var memberIndex = this.memberIndex(memberId);                      // 244
                                                                       //
    // we do not allow the only one admin to be removed                //
    var allowRemove = !this.members[memberIndex].isAdmin || this.activeAdmins().length > 1;
    if (!allowRemove) {                                                // 248
      var _$set3;                                                      //
                                                                       //
      return {                                                         // 249
        $set: (_$set3 = {}, _$set3['members.' + memberIndex + '.isActive'] = true, _$set3)
      };                                                               //
    }                                                                  //
                                                                       //
    return {                                                           // 256
      $set: (_$set4 = {}, _$set4['members.' + memberIndex + '.isActive'] = false, _$set4['members.' + memberIndex + '.isAdmin'] = false, _$set4)
    };                                                                 //
  },                                                                   //
                                                                       //
  setMemberPermission: function (memberId, isAdmin) {                  // 264
    var _$set5;                                                        //
                                                                       //
    var memberIndex = this.memberIndex(memberId);                      // 265
                                                                       //
    // do not allow change permission of self                          //
    if (memberId === Meteor.userId()) {                                // 268
      isAdmin = this.members[memberIndex].isAdmin;                     // 269
    }                                                                  //
                                                                       //
    return {                                                           // 272
      $set: (_$set5 = {}, _$set5['members.' + memberIndex + '.isAdmin'] = isAdmin, _$set5)
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 280
  Boards.allow({                                                       // 281
    insert: Meteor.userId,                                             // 282
    update: allowIsBoardAdmin,                                         // 283
    remove: allowIsBoardAdmin,                                         // 284
    fetch: ['members']                                                 // 285
  });                                                                  //
                                                                       //
  // The number of users that have starred this board is managed by trusted code
  // and the user is not allowed to update it                          //
  Boards.deny({                                                        // 290
    update: function (userId, board, fieldNames) {                     // 291
      return _.contains(fieldNames, 'stars');                          // 292
    },                                                                 //
    fetch: []                                                          // 294
  });                                                                  //
                                                                       //
  // We can't remove a member if it is the last administrator          //
  Boards.deny({                                                        // 298
    update: function (userId, doc, fieldNames, modifier) {             // 299
      if (!_.contains(fieldNames, 'members')) return false;            // 300
                                                                       //
      // We only care in case of a $pull operation, ie remove a member
      if (!_.isObject(modifier.$pull && modifier.$pull.members)) return false;
                                                                       //
      // If there is more than one admin, it's ok to remove anyone     //
      var nbAdmins = _.where(doc.members, { isActive: true, isAdmin: true }).length;
      if (nbAdmins > 1) return false;                                  // 309
                                                                       //
      // If all the previous conditions were verified, we can't remove
      // a user if it's an admin                                       //
      var removedMemberId = modifier.$pull.members.userId;             // 314
      return Boolean(_.findWhere(doc.members, {                        // 315
        userId: removedMemberId,                                       // 316
        isAdmin: true                                                  // 317
      }));                                                             //
    },                                                                 //
    fetch: ['members']                                                 // 320
  });                                                                  //
                                                                       //
  Meteor.methods({                                                     // 323
    quitBoard: function (boardId) {                                    // 324
      check(boardId, String);                                          // 325
      var board = Boards.findOne(boardId);                             // 326
      if (board) {                                                     // 327
        var userId = Meteor.userId();                                  // 328
        var index = board.memberIndex(userId);                         // 329
        if (index >= 0) {                                              // 330
          board.removeMember(userId);                                  // 331
          return true;                                                 // 332
        } else throw new Meteor.Error('error-board-notAMember');       //
      } else throw new Meteor.Error('error-board-doesNotExist');       //
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
Boards.before.insert(function (userId, doc) {                          // 339
  // XXX We need to improve slug management. Only the id should be necessary
  // to identify a board in the code.                                  //
  // XXX If the board title is updated, the slug should also be updated.
  // In some cases (Chinese and Japanese for instance) the `getSlug` function
  // return an empty string. This is causes bugs in our application so we set
  // a default slug in this case.                                      //
  doc.slug = doc.slug || getSlug(doc.title) || 'board';                // 346
  doc.createdAt = new Date();                                          // 347
  doc.archived = false;                                                // 348
  doc.members = doc.members || [{                                      // 349
    userId: userId,                                                    // 350
    isAdmin: true,                                                     // 351
    isActive: true                                                     // 352
  }];                                                                  //
  doc.stars = 0;                                                       // 354
  doc.color = Boards.simpleSchema()._schema.color.allowedValues[0];    // 355
                                                                       //
  // Handle labels                                                     //
  var colors = Boards.simpleSchema()._schema['labels.$.color'].allowedValues;
  var defaultLabelsColors = _.clone(colors).splice(0, 6);              // 359
  doc.labels = defaultLabelsColors.map(function (color) {              // 360
    return {                                                           // 361
      color: color,                                                    // 362
      _id: Random.id(6),                                               // 363
      name: ''                                                         // 364
    };                                                                 //
  });                                                                  //
});                                                                    //
                                                                       //
Boards.before.update(function (userId, doc, fieldNames, modifier) {    // 369
  modifier.$set = modifier.$set || {};                                 // 370
  modifier.$set.modifiedAt = new Date();                               // 371
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 374
  // Let MongoDB ensure that a member is not included twice in the same board
  Meteor.startup(function () {                                         // 376
    Boards._collection._ensureIndex({                                  // 377
      _id: 1,                                                          // 378
      'members.userId': 1                                              // 379
    }, { unique: true });                                              //
  });                                                                  //
                                                                       //
  // Genesis: the first activity of the newly created board            //
  Boards.after.insert(function (userId, doc) {                         // 384
    Activities.insert({                                                // 385
      userId: userId,                                                  // 386
      type: 'board',                                                   // 387
      activityTypeId: doc._id,                                         // 388
      activityType: 'createBoard',                                     // 389
      boardId: doc._id                                                 // 390
    });                                                                //
  });                                                                  //
                                                                       //
  // If the user remove one label from a board, we cant to remove reference of
  // this label in any card of this board.                             //
  Boards.after.update(function (userId, doc, fieldNames, modifier) {   // 396
    if (!_.contains(fieldNames, 'labels') || !modifier.$pull || !modifier.$pull.labels || !modifier.$pull.labels._id) return;
                                                                       //
    var removedLabelId = modifier.$pull.labels._id;                    // 403
    Cards.update({ boardId: doc._id }, {                               // 404
      $pull: {                                                         // 407
        labelIds: removedLabelId                                       // 408
      }                                                                //
    }, { multi: true });                                               //
  });                                                                  //
                                                                       //
  // Add a new activity if we add or remove a member to the board      //
  Boards.after.update(function (userId, doc, fieldNames, modifier) {   // 416
    if (!_.contains(fieldNames, 'members')) return;                    // 417
                                                                       //
    var memberId = undefined;                                          // 420
                                                                       //
    // Say hello to the new member                                     //
    if (modifier.$push && modifier.$push.members) {                    // 423
      memberId = modifier.$push.members.userId;                        // 424
      Activities.insert({                                              // 425
        userId: userId,                                                // 426
        memberId: memberId,                                            // 427
        type: 'member',                                                // 428
        activityType: 'addBoardMember',                                // 429
        boardId: doc._id                                               // 430
      });                                                              //
    }                                                                  //
                                                                       //
    // Say goodbye to the former member                                //
    if (modifier.$pull && modifier.$pull.members) {                    // 435
      memberId = modifier.$pull.members.userId;                        // 436
      Activities.insert({                                              // 437
        userId: userId,                                                // 438
        memberId: memberId,                                            // 439
        type: 'member',                                                // 440
        activityType: 'removeBoardMember',                             // 441
        boardId: doc._id                                               // 442
      });                                                              //
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=boards.js.map
