(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/boards.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// This is the publication used to display the board list. We publish all the
// non-archived boards:                                                //
// 1. that the user is a member of                                     //
// 2. the user has starred                                             //
Meteor.publish('boards', function () {                                 // 5
  // Ensure that the user is connected. If it is not, we need to return an empty
  // array to tell the client to remove the previously published docs.
  if (!Match.test(this.userId, String)) return [];                     // 8
                                                                       //
  // Defensive programming to verify that starredBoards has the expected
  // format -- since the field is in the `profile` a user can modify it.
  var _Users$findOne$profile$starredBoards = Users.findOne(this.userId).profile.starredBoards;
  var starredBoards = _Users$findOne$profile$starredBoards === undefined ? [] : _Users$findOne$profile$starredBoards;
                                                                       //
  check(starredBoards, [String]);                                      // 14
                                                                       //
  return Boards.find({                                                 // 16
    archived: false,                                                   // 17
    $or: [{                                                            // 18
      _id: { $in: starredBoards },                                     // 20
      permission: 'public'                                             // 21
    }, { members: { $elemMatch: { userId: this.userId, isActive: true } } }]
  }, {                                                                 //
    fields: {                                                          // 26
      _id: 1,                                                          // 27
      archived: 1,                                                     // 28
      slug: 1,                                                         // 29
      title: 1,                                                        // 30
      description: 1,                                                  // 31
      color: 1,                                                        // 32
      members: 1,                                                      // 33
      permission: 1                                                    // 34
    }                                                                  //
  });                                                                  //
});                                                                    //
                                                                       //
Meteor.publish('archivedBoards', function () {                         // 39
  if (!Match.test(this.userId, String)) return [];                     // 40
                                                                       //
  return Boards.find({                                                 // 43
    archived: true,                                                    // 44
    members: {                                                         // 45
      $elemMatch: {                                                    // 46
        userId: this.userId,                                           // 47
        isAdmin: true                                                  // 48
      }                                                                //
    }                                                                  //
  }, {                                                                 //
    fields: {                                                          // 52
      _id: 1,                                                          // 53
      archived: 1,                                                     // 54
      slug: 1,                                                         // 55
      title: 1                                                         // 56
    }                                                                  //
  });                                                                  //
});                                                                    //
                                                                       //
Meteor.publishRelations('board', function (boardId) {                  // 61
  check(boardId, String);                                              // 62
                                                                       //
  this.cursor(Boards.find({                                            // 64
    _id: boardId,                                                      // 65
    archived: false,                                                   // 66
    // If the board is not public the user has to be a member of it to see
    // it.                                                             //
    $or: [{ permission: 'public' }, { members: { $elemMatch: { userId: this.userId, isActive: true } } }]
  }, { limit: 1 }), function (boardId, board) {                        //
    this.cursor(Lists.find({ boardId: boardId }));                     // 74
                                                                       //
    // Cards and cards comments                                        //
    // XXX Originally we were publishing the card documents as a child of the
    // list publication defined above using the following selector `{ listId:
    // list._id }`. But it was causing a race condition in publish-composite,
    // that I documented here:                                         //
    //                                                                 //
    //   https://github.com/englue/meteor-publish-composite/issues/29  //
    //                                                                 //
    // cottz:publish had a similar problem:                            //
    //                                                                 //
    //   https://github.com/Goluis/cottz-publish/issues/4              //
    //                                                                 //
    // The current state of relational publishing in meteor is a bit sad,
    // there are a lot of various packages, with various APIs, some of them
    // are unmaintained. Fortunately this is something that will be fixed by
    // meteor-core at some point:                                      //
    //                                                                 //
    //   https://trello.com/c/BGvIwkEa/48-easy-joins-in-subscriptions  //
    //                                                                 //
    // And in the meantime our code below works pretty well -- it's not even a
    // hack!                                                           //
    this.cursor(Cards.find({ boardId: boardId }), function (cardId) {  // 97
      this.cursor(CardComments.find({ cardId: cardId }));              // 98
      this.cursor(Attachments.find({ cardId: cardId }));               // 99
    });                                                                //
                                                                       //
    // Board members. This publication also includes former board members that
    // aren't members anymore but may have some activities attached to them in
    // the history.                                                    //
    //                                                                 //
    this.cursor(Users.find({                                           // 106
      _id: { $in: _.pluck(board.members, 'userId') }                   // 107
    }), function (userId) {                                            //
      // Presence indicators                                           //
      this.cursor(presences.find({ userId: userId }));                 // 110
    });                                                                //
  });                                                                  //
                                                                       //
  return this.ready();                                                 // 114
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=boards.js.map
