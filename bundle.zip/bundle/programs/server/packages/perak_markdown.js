(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Markdown;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/perak_markdown/packages/perak_markdown.js                                           //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
(function () {                                                                                  // 1
                                                                                                // 2
//////////////////////////////////////////////////////////////////////////////////////////      // 3
//                                                                                      //      // 4
// packages/perak:markdown/marked/lib/marked.js                                         //      // 5
//                                                                                      //      // 6
//////////////////////////////////////////////////////////////////////////////////////////      // 7
                                                                                        //      // 8
/**                                                                                     // 1    // 9
 * marked - a markdown parser                                                           // 2    // 10
 * Copyright (c) 2011-2014, Christopher Jeffrey. (MIT Licensed)                         // 3    // 11
 * https://github.com/chjj/marked                                                       // 4    // 12
 */                                                                                     // 5    // 13
                                                                                        // 6    // 14
;(function() {                                                                          // 7    // 15
                                                                                        // 8    // 16
/**                                                                                     // 9    // 17
 * Block-Level Grammar                                                                  // 10   // 18
 */                                                                                     // 11   // 19
                                                                                        // 12   // 20
var block = {                                                                           // 13   // 21
  newline: /^\n+/,                                                                      // 14   // 22
  code: /^( {4}[^\n]+\n*)+/,                                                            // 15   // 23
  fences: noop,                                                                         // 16   // 24
  hr: /^( *[-*_]){3,} *(?:\n+|$)/,                                                      // 17   // 25
  heading: /^ *(#{1,6}) *([^\n]+?) *#* *(?:\n+|$)/,                                     // 18   // 26
  nptable: noop,                                                                        // 19   // 27
  lheading: /^([^\n]+)\n *(=|-){2,} *(?:\n+|$)/,                                        // 20   // 28
  blockquote: /^( *>[^\n]+(\n(?!def)[^\n]+)*\n*)+/,                                     // 21   // 29
  list: /^( *)(bull) [\s\S]+?(?:hr|def|\n{2,}(?! )(?!\1bull )\n*|\s*$)/,                // 22   // 30
  html: /^ *(?:comment *(?:\n|\s*$)|closed *(?:\n{2,}|\s*$)|closing *(?:\n{2,}|\s*$))/, // 23   // 31
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +["(]([^\n]+)[")])? *(?:\n+|$)/,             // 24   // 32
  table: noop,                                                                          // 25   // 33
  paragraph: /^((?:[^\n]+\n?(?!hr|heading|lheading|blockquote|tag|def))+)\n*/,          // 26   // 34
  text: /^[^\n]+/                                                                       // 27   // 35
};                                                                                      // 28   // 36
                                                                                        // 29   // 37
block.bullet = /(?:[*+-]|\d+\.)/;                                                       // 30   // 38
block.item = /^( *)(bull) [^\n]*(?:\n(?!\1bull )[^\n]*)*/;                              // 31   // 39
block.item = replace(block.item, 'gm')                                                  // 32   // 40
  (/bull/g, block.bullet)                                                               // 33   // 41
  ();                                                                                   // 34   // 42
                                                                                        // 35   // 43
block.list = replace(block.list)                                                        // 36   // 44
  (/bull/g, block.bullet)                                                               // 37   // 45
  ('hr', '\\n+(?=\\1?(?:[-*_] *){3,}(?:\\n+|$))')                                       // 38   // 46
  ('def', '\\n+(?=' + block.def.source + ')')                                           // 39   // 47
  ();                                                                                   // 40   // 48
                                                                                        // 41   // 49
block.blockquote = replace(block.blockquote)                                            // 42   // 50
  ('def', block.def)                                                                    // 43   // 51
  ();                                                                                   // 44   // 52
                                                                                        // 45   // 53
block._tag = '(?!(?:'                                                                   // 46   // 54
  + 'a|em|strong|small|s|cite|q|dfn|abbr|data|time|code'                                // 47   // 55
  + '|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo'                               // 48   // 56
  + '|span|br|wbr|ins|del|img)\\b)\\w+(?!:/|[^\\w\\s@]*@)\\b';                          // 49   // 57
                                                                                        // 50   // 58
block.html = replace(block.html)                                                        // 51   // 59
  ('comment', /<!--[\s\S]*?-->/)                                                        // 52   // 60
  ('closed', /<(tag)[\s\S]+?<\/\1>/)                                                    // 53   // 61
  ('closing', /<tag(?:"[^"]*"|'[^']*'|[^'">])*?>/)                                      // 54   // 62
  (/tag/g, block._tag)                                                                  // 55   // 63
  ();                                                                                   // 56   // 64
                                                                                        // 57   // 65
block.paragraph = replace(block.paragraph)                                              // 58   // 66
  ('hr', block.hr)                                                                      // 59   // 67
  ('heading', block.heading)                                                            // 60   // 68
  ('lheading', block.lheading)                                                          // 61   // 69
  ('blockquote', block.blockquote)                                                      // 62   // 70
  ('tag', '<' + block._tag)                                                             // 63   // 71
  ('def', block.def)                                                                    // 64   // 72
  ();                                                                                   // 65   // 73
                                                                                        // 66   // 74
/**                                                                                     // 67   // 75
 * Normal Block Grammar                                                                 // 68   // 76
 */                                                                                     // 69   // 77
                                                                                        // 70   // 78
block.normal = merge({}, block);                                                        // 71   // 79
                                                                                        // 72   // 80
/**                                                                                     // 73   // 81
 * GFM Block Grammar                                                                    // 74   // 82
 */                                                                                     // 75   // 83
                                                                                        // 76   // 84
block.gfm = merge({}, block.normal, {                                                   // 77   // 85
  fences: /^ *(`{3,}|~{3,}) *(\S+)? *\n([\s\S]+?)\s*\1 *(?:\n+|$)/,                     // 78   // 86
  paragraph: /^/                                                                        // 79   // 87
});                                                                                     // 80   // 88
                                                                                        // 81   // 89
block.gfm.paragraph = replace(block.paragraph)                                          // 82   // 90
  ('(?!', '(?!'                                                                         // 83   // 91
    + block.gfm.fences.source.replace('\\1', '\\2') + '|'                               // 84   // 92
    + block.list.source.replace('\\1', '\\3') + '|')                                    // 85   // 93
  ();                                                                                   // 86   // 94
                                                                                        // 87   // 95
/**                                                                                     // 88   // 96
 * GFM + Tables Block Grammar                                                           // 89   // 97
 */                                                                                     // 90   // 98
                                                                                        // 91   // 99
block.tables = merge({}, block.gfm, {                                                   // 92   // 100
  nptable: /^ *(\S.*\|.*)\n *([-:]+ *\|[-| :]*)\n((?:.*\|.*(?:\n|$))*)\n*/,             // 93   // 101
  table: /^ *\|(.+)\n *\|( *[-:]+[-| :]*)\n((?: *\|.*(?:\n|$))*)\n*/                    // 94   // 102
});                                                                                     // 95   // 103
                                                                                        // 96   // 104
/**                                                                                     // 97   // 105
 * Block Lexer                                                                          // 98   // 106
 */                                                                                     // 99   // 107
                                                                                        // 100  // 108
function Lexer(options) {                                                               // 101  // 109
  this.tokens = [];                                                                     // 102  // 110
  this.tokens.links = {};                                                               // 103  // 111
  this.options = options || marked.defaults;                                            // 104  // 112
  this.rules = block.normal;                                                            // 105  // 113
                                                                                        // 106  // 114
  if (this.options.gfm) {                                                               // 107  // 115
    if (this.options.tables) {                                                          // 108  // 116
      this.rules = block.tables;                                                        // 109  // 117
    } else {                                                                            // 110  // 118
      this.rules = block.gfm;                                                           // 111  // 119
    }                                                                                   // 112  // 120
  }                                                                                     // 113  // 121
}                                                                                       // 114  // 122
                                                                                        // 115  // 123
/**                                                                                     // 116  // 124
 * Expose Block Rules                                                                   // 117  // 125
 */                                                                                     // 118  // 126
                                                                                        // 119  // 127
Lexer.rules = block;                                                                    // 120  // 128
                                                                                        // 121  // 129
/**                                                                                     // 122  // 130
 * Static Lex Method                                                                    // 123  // 131
 */                                                                                     // 124  // 132
                                                                                        // 125  // 133
Lexer.lex = function(src, options) {                                                    // 126  // 134
  var lexer = new Lexer(options);                                                       // 127  // 135
  return lexer.lex(src);                                                                // 128  // 136
};                                                                                      // 129  // 137
                                                                                        // 130  // 138
/**                                                                                     // 131  // 139
 * Preprocessing                                                                        // 132  // 140
 */                                                                                     // 133  // 141
                                                                                        // 134  // 142
Lexer.prototype.lex = function(src) {                                                   // 135  // 143
  src = src                                                                             // 136  // 144
    .replace(/\r\n|\r/g, '\n')                                                          // 137  // 145
    .replace(/\t/g, '    ')                                                             // 138  // 146
    .replace(/\u00a0/g, ' ')                                                            // 139  // 147
    .replace(/\u2424/g, '\n');                                                          // 140  // 148
                                                                                        // 141  // 149
  return this.token(src, true);                                                         // 142  // 150
};                                                                                      // 143  // 151
                                                                                        // 144  // 152
/**                                                                                     // 145  // 153
 * Lexing                                                                               // 146  // 154
 */                                                                                     // 147  // 155
                                                                                        // 148  // 156
Lexer.prototype.token = function(src, top, bq) {                                        // 149  // 157
  var src = src.replace(/^ +$/gm, '')                                                   // 150  // 158
    , next                                                                              // 151  // 159
    , loose                                                                             // 152  // 160
    , cap                                                                               // 153  // 161
    , bull                                                                              // 154  // 162
    , b                                                                                 // 155  // 163
    , item                                                                              // 156  // 164
    , space                                                                             // 157  // 165
    , i                                                                                 // 158  // 166
    , l;                                                                                // 159  // 167
                                                                                        // 160  // 168
  while (src) {                                                                         // 161  // 169
    // newline                                                                          // 162  // 170
    if (cap = this.rules.newline.exec(src)) {                                           // 163  // 171
      src = src.substring(cap[0].length);                                               // 164  // 172
      if (cap[0].length > 1) {                                                          // 165  // 173
        this.tokens.push({                                                              // 166  // 174
          type: 'space'                                                                 // 167  // 175
        });                                                                             // 168  // 176
      }                                                                                 // 169  // 177
    }                                                                                   // 170  // 178
                                                                                        // 171  // 179
    // code                                                                             // 172  // 180
    if (cap = this.rules.code.exec(src)) {                                              // 173  // 181
      src = src.substring(cap[0].length);                                               // 174  // 182
      cap = cap[0].replace(/^ {4}/gm, '');                                              // 175  // 183
      this.tokens.push({                                                                // 176  // 184
        type: 'code',                                                                   // 177  // 185
        text: !this.options.pedantic                                                    // 178  // 186
          ? cap.replace(/\n+$/, '')                                                     // 179  // 187
          : cap                                                                         // 180  // 188
      });                                                                               // 181  // 189
      continue;                                                                         // 182  // 190
    }                                                                                   // 183  // 191
                                                                                        // 184  // 192
    // fences (gfm)                                                                     // 185  // 193
    if (cap = this.rules.fences.exec(src)) {                                            // 186  // 194
      src = src.substring(cap[0].length);                                               // 187  // 195
      this.tokens.push({                                                                // 188  // 196
        type: 'code',                                                                   // 189  // 197
        lang: cap[2],                                                                   // 190  // 198
        text: cap[3]                                                                    // 191  // 199
      });                                                                               // 192  // 200
      continue;                                                                         // 193  // 201
    }                                                                                   // 194  // 202
                                                                                        // 195  // 203
    // heading                                                                          // 196  // 204
    if (cap = this.rules.heading.exec(src)) {                                           // 197  // 205
      src = src.substring(cap[0].length);                                               // 198  // 206
      this.tokens.push({                                                                // 199  // 207
        type: 'heading',                                                                // 200  // 208
        depth: cap[1].length,                                                           // 201  // 209
        text: cap[2]                                                                    // 202  // 210
      });                                                                               // 203  // 211
      continue;                                                                         // 204  // 212
    }                                                                                   // 205  // 213
                                                                                        // 206  // 214
    // table no leading pipe (gfm)                                                      // 207  // 215
    if (top && (cap = this.rules.nptable.exec(src))) {                                  // 208  // 216
      src = src.substring(cap[0].length);                                               // 209  // 217
                                                                                        // 210  // 218
      item = {                                                                          // 211  // 219
        type: 'table',                                                                  // 212  // 220
        header: cap[1].replace(/^ *| *\| *$/g, '').split(/ *\| */),                     // 213  // 221
        align: cap[2].replace(/^ *|\| *$/g, '').split(/ *\| */),                        // 214  // 222
        cells: cap[3].replace(/\n$/, '').split('\n')                                    // 215  // 223
      };                                                                                // 216  // 224
                                                                                        // 217  // 225
      for (i = 0; i < item.align.length; i++) {                                         // 218  // 226
        if (/^ *-+: *$/.test(item.align[i])) {                                          // 219  // 227
          item.align[i] = 'right';                                                      // 220  // 228
        } else if (/^ *:-+: *$/.test(item.align[i])) {                                  // 221  // 229
          item.align[i] = 'center';                                                     // 222  // 230
        } else if (/^ *:-+ *$/.test(item.align[i])) {                                   // 223  // 231
          item.align[i] = 'left';                                                       // 224  // 232
        } else {                                                                        // 225  // 233
          item.align[i] = null;                                                         // 226  // 234
        }                                                                               // 227  // 235
      }                                                                                 // 228  // 236
                                                                                        // 229  // 237
      for (i = 0; i < item.cells.length; i++) {                                         // 230  // 238
        item.cells[i] = item.cells[i].split(/ *\| */);                                  // 231  // 239
      }                                                                                 // 232  // 240
                                                                                        // 233  // 241
      this.tokens.push(item);                                                           // 234  // 242
                                                                                        // 235  // 243
      continue;                                                                         // 236  // 244
    }                                                                                   // 237  // 245
                                                                                        // 238  // 246
    // lheading                                                                         // 239  // 247
    if (cap = this.rules.lheading.exec(src)) {                                          // 240  // 248
      src = src.substring(cap[0].length);                                               // 241  // 249
      this.tokens.push({                                                                // 242  // 250
        type: 'heading',                                                                // 243  // 251
        depth: cap[2] === '=' ? 1 : 2,                                                  // 244  // 252
        text: cap[1]                                                                    // 245  // 253
      });                                                                               // 246  // 254
      continue;                                                                         // 247  // 255
    }                                                                                   // 248  // 256
                                                                                        // 249  // 257
    // hr                                                                               // 250  // 258
    if (cap = this.rules.hr.exec(src)) {                                                // 251  // 259
      src = src.substring(cap[0].length);                                               // 252  // 260
      this.tokens.push({                                                                // 253  // 261
        type: 'hr'                                                                      // 254  // 262
      });                                                                               // 255  // 263
      continue;                                                                         // 256  // 264
    }                                                                                   // 257  // 265
                                                                                        // 258  // 266
    // blockquote                                                                       // 259  // 267
    if (cap = this.rules.blockquote.exec(src)) {                                        // 260  // 268
      src = src.substring(cap[0].length);                                               // 261  // 269
                                                                                        // 262  // 270
      this.tokens.push({                                                                // 263  // 271
        type: 'blockquote_start'                                                        // 264  // 272
      });                                                                               // 265  // 273
                                                                                        // 266  // 274
      cap = cap[0].replace(/^ *> ?/gm, '');                                             // 267  // 275
                                                                                        // 268  // 276
      // Pass `top` to keep the current                                                 // 269  // 277
      // "toplevel" state. This is exactly                                              // 270  // 278
      // how markdown.pl works.                                                         // 271  // 279
      this.token(cap, top, true);                                                       // 272  // 280
                                                                                        // 273  // 281
      this.tokens.push({                                                                // 274  // 282
        type: 'blockquote_end'                                                          // 275  // 283
      });                                                                               // 276  // 284
                                                                                        // 277  // 285
      continue;                                                                         // 278  // 286
    }                                                                                   // 279  // 287
                                                                                        // 280  // 288
    // list                                                                             // 281  // 289
    if (cap = this.rules.list.exec(src)) {                                              // 282  // 290
      src = src.substring(cap[0].length);                                               // 283  // 291
      bull = cap[2];                                                                    // 284  // 292
                                                                                        // 285  // 293
      this.tokens.push({                                                                // 286  // 294
        type: 'list_start',                                                             // 287  // 295
        ordered: bull.length > 1                                                        // 288  // 296
      });                                                                               // 289  // 297
                                                                                        // 290  // 298
      // Get each top-level item.                                                       // 291  // 299
      cap = cap[0].match(this.rules.item);                                              // 292  // 300
                                                                                        // 293  // 301
      next = false;                                                                     // 294  // 302
      l = cap.length;                                                                   // 295  // 303
      i = 0;                                                                            // 296  // 304
                                                                                        // 297  // 305
      for (; i < l; i++) {                                                              // 298  // 306
        item = cap[i];                                                                  // 299  // 307
                                                                                        // 300  // 308
        // Remove the list item's bullet                                                // 301  // 309
        // so it is seen as the next token.                                             // 302  // 310
        space = item.length;                                                            // 303  // 311
        item = item.replace(/^ *([*+-]|\d+\.) +/, '');                                  // 304  // 312
                                                                                        // 305  // 313
        // Outdent whatever the                                                         // 306  // 314
        // list item contains. Hacky.                                                   // 307  // 315
        if (~item.indexOf('\n ')) {                                                     // 308  // 316
          space -= item.length;                                                         // 309  // 317
          item = !this.options.pedantic                                                 // 310  // 318
            ? item.replace(new RegExp('^ {1,' + space + '}', 'gm'), '')                 // 311  // 319
            : item.replace(/^ {1,4}/gm, '');                                            // 312  // 320
        }                                                                               // 313  // 321
                                                                                        // 314  // 322
        // Determine whether the next list item belongs here.                           // 315  // 323
        // Backpedal if it does not belong in this list.                                // 316  // 324
        if (this.options.smartLists && i !== l - 1) {                                   // 317  // 325
          b = block.bullet.exec(cap[i + 1])[0];                                         // 318  // 326
          if (bull !== b && !(bull.length > 1 && b.length > 1)) {                       // 319  // 327
            src = cap.slice(i + 1).join('\n') + src;                                    // 320  // 328
            i = l - 1;                                                                  // 321  // 329
          }                                                                             // 322  // 330
        }                                                                               // 323  // 331
                                                                                        // 324  // 332
        // Determine whether item is loose or not.                                      // 325  // 333
        // Use: /(^|\n)(?! )[^\n]+\n\n(?!\s*$)/                                         // 326  // 334
        // for discount behavior.                                                       // 327  // 335
        loose = next || /\n\n(?!\s*$)/.test(item);                                      // 328  // 336
        if (i !== l - 1) {                                                              // 329  // 337
          next = item.charAt(item.length - 1) === '\n';                                 // 330  // 338
          if (!loose) loose = next;                                                     // 331  // 339
        }                                                                               // 332  // 340
                                                                                        // 333  // 341
        this.tokens.push({                                                              // 334  // 342
          type: loose                                                                   // 335  // 343
            ? 'loose_item_start'                                                        // 336  // 344
            : 'list_item_start'                                                         // 337  // 345
        });                                                                             // 338  // 346
                                                                                        // 339  // 347
        // Recurse.                                                                     // 340  // 348
        this.token(item, false, bq);                                                    // 341  // 349
                                                                                        // 342  // 350
        this.tokens.push({                                                              // 343  // 351
          type: 'list_item_end'                                                         // 344  // 352
        });                                                                             // 345  // 353
      }                                                                                 // 346  // 354
                                                                                        // 347  // 355
      this.tokens.push({                                                                // 348  // 356
        type: 'list_end'                                                                // 349  // 357
      });                                                                               // 350  // 358
                                                                                        // 351  // 359
      continue;                                                                         // 352  // 360
    }                                                                                   // 353  // 361
                                                                                        // 354  // 362
    // html                                                                             // 355  // 363
    if (cap = this.rules.html.exec(src)) {                                              // 356  // 364
      src = src.substring(cap[0].length);                                               // 357  // 365
      this.tokens.push({                                                                // 358  // 366
        type: this.options.sanitize                                                     // 359  // 367
          ? 'paragraph'                                                                 // 360  // 368
          : 'html',                                                                     // 361  // 369
        pre: cap[1] === 'pre' || cap[1] === 'script' || cap[1] === 'style',             // 362  // 370
        text: cap[0]                                                                    // 363  // 371
      });                                                                               // 364  // 372
      continue;                                                                         // 365  // 373
    }                                                                                   // 366  // 374
                                                                                        // 367  // 375
    // def                                                                              // 368  // 376
    if ((!bq && top) && (cap = this.rules.def.exec(src))) {                             // 369  // 377
      src = src.substring(cap[0].length);                                               // 370  // 378
      this.tokens.links[cap[1].toLowerCase()] = {                                       // 371  // 379
        href: cap[2],                                                                   // 372  // 380
        title: cap[3]                                                                   // 373  // 381
      };                                                                                // 374  // 382
      continue;                                                                         // 375  // 383
    }                                                                                   // 376  // 384
                                                                                        // 377  // 385
    // table (gfm)                                                                      // 378  // 386
    if (top && (cap = this.rules.table.exec(src))) {                                    // 379  // 387
      src = src.substring(cap[0].length);                                               // 380  // 388
                                                                                        // 381  // 389
      item = {                                                                          // 382  // 390
        type: 'table',                                                                  // 383  // 391
        header: cap[1].replace(/^ *| *\| *$/g, '').split(/ *\| */),                     // 384  // 392
        align: cap[2].replace(/^ *|\| *$/g, '').split(/ *\| */),                        // 385  // 393
        cells: cap[3].replace(/(?: *\| *)?\n$/, '').split('\n')                         // 386  // 394
      };                                                                                // 387  // 395
                                                                                        // 388  // 396
      for (i = 0; i < item.align.length; i++) {                                         // 389  // 397
        if (/^ *-+: *$/.test(item.align[i])) {                                          // 390  // 398
          item.align[i] = 'right';                                                      // 391  // 399
        } else if (/^ *:-+: *$/.test(item.align[i])) {                                  // 392  // 400
          item.align[i] = 'center';                                                     // 393  // 401
        } else if (/^ *:-+ *$/.test(item.align[i])) {                                   // 394  // 402
          item.align[i] = 'left';                                                       // 395  // 403
        } else {                                                                        // 396  // 404
          item.align[i] = null;                                                         // 397  // 405
        }                                                                               // 398  // 406
      }                                                                                 // 399  // 407
                                                                                        // 400  // 408
      for (i = 0; i < item.cells.length; i++) {                                         // 401  // 409
        item.cells[i] = item.cells[i]                                                   // 402  // 410
          .replace(/^ *\| *| *\| *$/g, '')                                              // 403  // 411
          .split(/ *\| */);                                                             // 404  // 412
      }                                                                                 // 405  // 413
                                                                                        // 406  // 414
      this.tokens.push(item);                                                           // 407  // 415
                                                                                        // 408  // 416
      continue;                                                                         // 409  // 417
    }                                                                                   // 410  // 418
                                                                                        // 411  // 419
    // top-level paragraph                                                              // 412  // 420
    if (top && (cap = this.rules.paragraph.exec(src))) {                                // 413  // 421
      src = src.substring(cap[0].length);                                               // 414  // 422
      this.tokens.push({                                                                // 415  // 423
        type: 'paragraph',                                                              // 416  // 424
        text: cap[1].charAt(cap[1].length - 1) === '\n'                                 // 417  // 425
          ? cap[1].slice(0, -1)                                                         // 418  // 426
          : cap[1]                                                                      // 419  // 427
      });                                                                               // 420  // 428
      continue;                                                                         // 421  // 429
    }                                                                                   // 422  // 430
                                                                                        // 423  // 431
    // text                                                                             // 424  // 432
    if (cap = this.rules.text.exec(src)) {                                              // 425  // 433
      // Top-level should never reach here.                                             // 426  // 434
      src = src.substring(cap[0].length);                                               // 427  // 435
      this.tokens.push({                                                                // 428  // 436
        type: 'text',                                                                   // 429  // 437
        text: cap[0]                                                                    // 430  // 438
      });                                                                               // 431  // 439
      continue;                                                                         // 432  // 440
    }                                                                                   // 433  // 441
                                                                                        // 434  // 442
    if (src) {                                                                          // 435  // 443
      throw new                                                                         // 436  // 444
        Error('Infinite loop on byte: ' + src.charCodeAt(0));                           // 437  // 445
    }                                                                                   // 438  // 446
  }                                                                                     // 439  // 447
                                                                                        // 440  // 448
  return this.tokens;                                                                   // 441  // 449
};                                                                                      // 442  // 450
                                                                                        // 443  // 451
/**                                                                                     // 444  // 452
 * Inline-Level Grammar                                                                 // 445  // 453
 */                                                                                     // 446  // 454
                                                                                        // 447  // 455
var inline = {                                                                          // 448  // 456
  escape: /^\\([\\`*{}\[\]()#+\-.!_>])/,                                                // 449  // 457
  autolink: /^<([^ >]+(@|:\/)[^ >]+)>/,                                                 // 450  // 458
  url: noop,                                                                            // 451  // 459
  tag: /^<!--[\s\S]*?-->|^<\/?\w+(?:"[^"]*"|'[^']*'|[^'">])*?>/,                        // 452  // 460
  link: /^!?\[(inside)\]\(href\)/,                                                      // 453  // 461
  reflink: /^!?\[(inside)\]\s*\[([^\]]*)\]/,                                            // 454  // 462
  nolink: /^!?\[((?:\[[^\]]*\]|[^\[\]])*)\]/,                                           // 455  // 463
  strong: /^__([\s\S]+?)__(?!_)|^\*\*([\s\S]+?)\*\*(?!\*)/,                             // 456  // 464
  em: /^\b_((?:__|[\s\S])+?)_\b|^\*((?:\*\*|[\s\S])+?)\*(?!\*)/,                        // 457  // 465
  code: /^(`+)\s*([\s\S]*?[^`])\s*\1(?!`)/,                                             // 458  // 466
  br: /^ {2,}\n(?!\s*$)/,                                                               // 459  // 467
  del: noop,                                                                            // 460  // 468
  text: /^[\s\S]+?(?=[\\<!\[_*`]| {2,}\n|$)/                                            // 461  // 469
};                                                                                      // 462  // 470
                                                                                        // 463  // 471
inline._inside = /(?:\[[^\]]*\]|[^\[\]]|\](?=[^\[]*\]))*/;                              // 464  // 472
inline._href = /\s*<?([\s\S]*?)>?(?:\s+['"]([\s\S]*?)['"])?\s*/;                        // 465  // 473
                                                                                        // 466  // 474
inline.link = replace(inline.link)                                                      // 467  // 475
  ('inside', inline._inside)                                                            // 468  // 476
  ('href', inline._href)                                                                // 469  // 477
  ();                                                                                   // 470  // 478
                                                                                        // 471  // 479
inline.reflink = replace(inline.reflink)                                                // 472  // 480
  ('inside', inline._inside)                                                            // 473  // 481
  ();                                                                                   // 474  // 482
                                                                                        // 475  // 483
/**                                                                                     // 476  // 484
 * Normal Inline Grammar                                                                // 477  // 485
 */                                                                                     // 478  // 486
                                                                                        // 479  // 487
inline.normal = merge({}, inline);                                                      // 480  // 488
                                                                                        // 481  // 489
/**                                                                                     // 482  // 490
 * Pedantic Inline Grammar                                                              // 483  // 491
 */                                                                                     // 484  // 492
                                                                                        // 485  // 493
inline.pedantic = merge({}, inline.normal, {                                            // 486  // 494
  strong: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,             // 487  // 495
  em: /^_(?=\S)([\s\S]*?\S)_(?!_)|^\*(?=\S)([\s\S]*?\S)\*(?!\*)/                        // 488  // 496
});                                                                                     // 489  // 497
                                                                                        // 490  // 498
/**                                                                                     // 491  // 499
 * GFM Inline Grammar                                                                   // 492  // 500
 */                                                                                     // 493  // 501
                                                                                        // 494  // 502
inline.gfm = merge({}, inline.normal, {                                                 // 495  // 503
  escape: replace(inline.escape)('])', '~|])')(),                                       // 496  // 504
  url: /^(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/,                                          // 497  // 505
  del: /^~~(?=\S)([\s\S]*?\S)~~/,                                                       // 498  // 506
  text: replace(inline.text)                                                            // 499  // 507
    (']|', '~]|')                                                                       // 500  // 508
    ('|', '|https?://|')                                                                // 501  // 509
    ()                                                                                  // 502  // 510
});                                                                                     // 503  // 511
                                                                                        // 504  // 512
/**                                                                                     // 505  // 513
 * GFM + Line Breaks Inline Grammar                                                     // 506  // 514
 */                                                                                     // 507  // 515
                                                                                        // 508  // 516
inline.breaks = merge({}, inline.gfm, {                                                 // 509  // 517
  br: replace(inline.br)('{2,}', '*')(),                                                // 510  // 518
  text: replace(inline.gfm.text)('{2,}', '*')()                                         // 511  // 519
});                                                                                     // 512  // 520
                                                                                        // 513  // 521
/**                                                                                     // 514  // 522
 * Inline Lexer & Compiler                                                              // 515  // 523
 */                                                                                     // 516  // 524
                                                                                        // 517  // 525
function InlineLexer(links, options) {                                                  // 518  // 526
  this.options = options || marked.defaults;                                            // 519  // 527
  this.links = links;                                                                   // 520  // 528
  this.rules = inline.normal;                                                           // 521  // 529
  this.renderer = this.options.renderer || new Renderer;                                // 522  // 530
  this.renderer.options = this.options;                                                 // 523  // 531
                                                                                        // 524  // 532
  if (!this.links) {                                                                    // 525  // 533
    throw new                                                                           // 526  // 534
      Error('Tokens array requires a `links` property.');                               // 527  // 535
  }                                                                                     // 528  // 536
                                                                                        // 529  // 537
  if (this.options.gfm) {                                                               // 530  // 538
    if (this.options.breaks) {                                                          // 531  // 539
      this.rules = inline.breaks;                                                       // 532  // 540
    } else {                                                                            // 533  // 541
      this.rules = inline.gfm;                                                          // 534  // 542
    }                                                                                   // 535  // 543
  } else if (this.options.pedantic) {                                                   // 536  // 544
    this.rules = inline.pedantic;                                                       // 537  // 545
  }                                                                                     // 538  // 546
}                                                                                       // 539  // 547
                                                                                        // 540  // 548
/**                                                                                     // 541  // 549
 * Expose Inline Rules                                                                  // 542  // 550
 */                                                                                     // 543  // 551
                                                                                        // 544  // 552
InlineLexer.rules = inline;                                                             // 545  // 553
                                                                                        // 546  // 554
/**                                                                                     // 547  // 555
 * Static Lexing/Compiling Method                                                       // 548  // 556
 */                                                                                     // 549  // 557
                                                                                        // 550  // 558
InlineLexer.output = function(src, links, options) {                                    // 551  // 559
  var inline = new InlineLexer(links, options);                                         // 552  // 560
  return inline.output(src);                                                            // 553  // 561
};                                                                                      // 554  // 562
                                                                                        // 555  // 563
/**                                                                                     // 556  // 564
 * Lexing/Compiling                                                                     // 557  // 565
 */                                                                                     // 558  // 566
                                                                                        // 559  // 567
InlineLexer.prototype.output = function(src) {                                          // 560  // 568
  var out = ''                                                                          // 561  // 569
    , link                                                                              // 562  // 570
    , text                                                                              // 563  // 571
    , href                                                                              // 564  // 572
    , cap;                                                                              // 565  // 573
                                                                                        // 566  // 574
  while (src) {                                                                         // 567  // 575
    // escape                                                                           // 568  // 576
    if (cap = this.rules.escape.exec(src)) {                                            // 569  // 577
      src = src.substring(cap[0].length);                                               // 570  // 578
      out += cap[1];                                                                    // 571  // 579
      continue;                                                                         // 572  // 580
    }                                                                                   // 573  // 581
                                                                                        // 574  // 582
    // autolink                                                                         // 575  // 583
    if (cap = this.rules.autolink.exec(src)) {                                          // 576  // 584
      src = src.substring(cap[0].length);                                               // 577  // 585
      if (cap[2] === '@') {                                                             // 578  // 586
        text = cap[1].charAt(6) === ':'                                                 // 579  // 587
          ? this.mangle(cap[1].substring(7))                                            // 580  // 588
          : this.mangle(cap[1]);                                                        // 581  // 589
        href = this.mangle('mailto:') + text;                                           // 582  // 590
      } else {                                                                          // 583  // 591
        text = escape(cap[1]);                                                          // 584  // 592
        href = text;                                                                    // 585  // 593
      }                                                                                 // 586  // 594
      out += this.renderer.link(href, null, text);                                      // 587  // 595
      continue;                                                                         // 588  // 596
    }                                                                                   // 589  // 597
                                                                                        // 590  // 598
    // url (gfm)                                                                        // 591  // 599
    if (!this.inLink && (cap = this.rules.url.exec(src))) {                             // 592  // 600
      src = src.substring(cap[0].length);                                               // 593  // 601
      text = escape(cap[1]);                                                            // 594  // 602
      href = text;                                                                      // 595  // 603
      out += this.renderer.link(href, null, text);                                      // 596  // 604
      continue;                                                                         // 597  // 605
    }                                                                                   // 598  // 606
                                                                                        // 599  // 607
    // tag                                                                              // 600  // 608
    if (cap = this.rules.tag.exec(src)) {                                               // 601  // 609
      if (!this.inLink && /^<a /i.test(cap[0])) {                                       // 602  // 610
        this.inLink = true;                                                             // 603  // 611
      } else if (this.inLink && /^<\/a>/i.test(cap[0])) {                               // 604  // 612
        this.inLink = false;                                                            // 605  // 613
      }                                                                                 // 606  // 614
      src = src.substring(cap[0].length);                                               // 607  // 615
      out += this.options.sanitize                                                      // 608  // 616
        ? escape(cap[0])                                                                // 609  // 617
        : cap[0];                                                                       // 610  // 618
      continue;                                                                         // 611  // 619
    }                                                                                   // 612  // 620
                                                                                        // 613  // 621
    // link                                                                             // 614  // 622
    if (cap = this.rules.link.exec(src)) {                                              // 615  // 623
      src = src.substring(cap[0].length);                                               // 616  // 624
      this.inLink = true;                                                               // 617  // 625
      out += this.outputLink(cap, {                                                     // 618  // 626
        href: cap[2],                                                                   // 619  // 627
        title: cap[3]                                                                   // 620  // 628
      });                                                                               // 621  // 629
      this.inLink = false;                                                              // 622  // 630
      continue;                                                                         // 623  // 631
    }                                                                                   // 624  // 632
                                                                                        // 625  // 633
    // reflink, nolink                                                                  // 626  // 634
    if ((cap = this.rules.reflink.exec(src))                                            // 627  // 635
        || (cap = this.rules.nolink.exec(src))) {                                       // 628  // 636
      src = src.substring(cap[0].length);                                               // 629  // 637
      link = (cap[2] || cap[1]).replace(/\s+/g, ' ');                                   // 630  // 638
      link = this.links[link.toLowerCase()];                                            // 631  // 639
      if (!link || !link.href) {                                                        // 632  // 640
        out += cap[0].charAt(0);                                                        // 633  // 641
        src = cap[0].substring(1) + src;                                                // 634  // 642
        continue;                                                                       // 635  // 643
      }                                                                                 // 636  // 644
      this.inLink = true;                                                               // 637  // 645
      out += this.outputLink(cap, link);                                                // 638  // 646
      this.inLink = false;                                                              // 639  // 647
      continue;                                                                         // 640  // 648
    }                                                                                   // 641  // 649
                                                                                        // 642  // 650
    // strong                                                                           // 643  // 651
    if (cap = this.rules.strong.exec(src)) {                                            // 644  // 652
      src = src.substring(cap[0].length);                                               // 645  // 653
      out += this.renderer.strong(this.output(cap[2] || cap[1]));                       // 646  // 654
      continue;                                                                         // 647  // 655
    }                                                                                   // 648  // 656
                                                                                        // 649  // 657
    // em                                                                               // 650  // 658
    if (cap = this.rules.em.exec(src)) {                                                // 651  // 659
      src = src.substring(cap[0].length);                                               // 652  // 660
      out += this.renderer.em(this.output(cap[2] || cap[1]));                           // 653  // 661
      continue;                                                                         // 654  // 662
    }                                                                                   // 655  // 663
                                                                                        // 656  // 664
    // code                                                                             // 657  // 665
    if (cap = this.rules.code.exec(src)) {                                              // 658  // 666
      src = src.substring(cap[0].length);                                               // 659  // 667
      out += this.renderer.codespan(escape(cap[2], true));                              // 660  // 668
      continue;                                                                         // 661  // 669
    }                                                                                   // 662  // 670
                                                                                        // 663  // 671
    // br                                                                               // 664  // 672
    if (cap = this.rules.br.exec(src)) {                                                // 665  // 673
      src = src.substring(cap[0].length);                                               // 666  // 674
      out += this.renderer.br();                                                        // 667  // 675
      continue;                                                                         // 668  // 676
    }                                                                                   // 669  // 677
                                                                                        // 670  // 678
    // del (gfm)                                                                        // 671  // 679
    if (cap = this.rules.del.exec(src)) {                                               // 672  // 680
      src = src.substring(cap[0].length);                                               // 673  // 681
      out += this.renderer.del(this.output(cap[1]));                                    // 674  // 682
      continue;                                                                         // 675  // 683
    }                                                                                   // 676  // 684
                                                                                        // 677  // 685
    // text                                                                             // 678  // 686
    if (cap = this.rules.text.exec(src)) {                                              // 679  // 687
      src = src.substring(cap[0].length);                                               // 680  // 688
      out += escape(this.smartypants(cap[0]));                                          // 681  // 689
      continue;                                                                         // 682  // 690
    }                                                                                   // 683  // 691
                                                                                        // 684  // 692
    if (src) {                                                                          // 685  // 693
      throw new                                                                         // 686  // 694
        Error('Infinite loop on byte: ' + src.charCodeAt(0));                           // 687  // 695
    }                                                                                   // 688  // 696
  }                                                                                     // 689  // 697
                                                                                        // 690  // 698
  return out;                                                                           // 691  // 699
};                                                                                      // 692  // 700
                                                                                        // 693  // 701
/**                                                                                     // 694  // 702
 * Compile Link                                                                         // 695  // 703
 */                                                                                     // 696  // 704
                                                                                        // 697  // 705
InlineLexer.prototype.outputLink = function(cap, link) {                                // 698  // 706
  var href = escape(link.href)                                                          // 699  // 707
    , title = link.title ? escape(link.title) : null;                                   // 700  // 708
                                                                                        // 701  // 709
  return cap[0].charAt(0) !== '!'                                                       // 702  // 710
    ? this.renderer.link(href, title, this.output(cap[1]))                              // 703  // 711
    : this.renderer.image(href, title, escape(cap[1]));                                 // 704  // 712
};                                                                                      // 705  // 713
                                                                                        // 706  // 714
/**                                                                                     // 707  // 715
 * Smartypants Transformations                                                          // 708  // 716
 */                                                                                     // 709  // 717
                                                                                        // 710  // 718
InlineLexer.prototype.smartypants = function(text) {                                    // 711  // 719
  if (!this.options.smartypants) return text;                                           // 712  // 720
  return text                                                                           // 713  // 721
    // em-dashes                                                                        // 714  // 722
    .replace(/--/g, '\u2014')                                                           // 715  // 723
    // opening singles                                                                  // 716  // 724
    .replace(/(^|[-\u2014/(\[{"\s])'/g, '$1\u2018')                                     // 717  // 725
    // closing singles & apostrophes                                                    // 718  // 726
    .replace(/'/g, '\u2019')                                                            // 719  // 727
    // opening doubles                                                                  // 720  // 728
    .replace(/(^|[-\u2014/(\[{\u2018\s])"/g, '$1\u201c')                                // 721  // 729
    // closing doubles                                                                  // 722  // 730
    .replace(/"/g, '\u201d')                                                            // 723  // 731
    // ellipses                                                                         // 724  // 732
    .replace(/\.{3}/g, '\u2026');                                                       // 725  // 733
};                                                                                      // 726  // 734
                                                                                        // 727  // 735
/**                                                                                     // 728  // 736
 * Mangle Links                                                                         // 729  // 737
 */                                                                                     // 730  // 738
                                                                                        // 731  // 739
InlineLexer.prototype.mangle = function(text) {                                         // 732  // 740
  var out = ''                                                                          // 733  // 741
    , l = text.length                                                                   // 734  // 742
    , i = 0                                                                             // 735  // 743
    , ch;                                                                               // 736  // 744
                                                                                        // 737  // 745
  for (; i < l; i++) {                                                                  // 738  // 746
    ch = text.charCodeAt(i);                                                            // 739  // 747
    if (Math.random() > 0.5) {                                                          // 740  // 748
      ch = 'x' + ch.toString(16);                                                       // 741  // 749
    }                                                                                   // 742  // 750
    out += '&#' + ch + ';';                                                             // 743  // 751
  }                                                                                     // 744  // 752
                                                                                        // 745  // 753
  return out;                                                                           // 746  // 754
};                                                                                      // 747  // 755
                                                                                        // 748  // 756
/**                                                                                     // 749  // 757
 * Renderer                                                                             // 750  // 758
 */                                                                                     // 751  // 759
                                                                                        // 752  // 760
function Renderer(options) {                                                            // 753  // 761
  this.options = options || {};                                                         // 754  // 762
}                                                                                       // 755  // 763
                                                                                        // 756  // 764
Renderer.prototype.code = function(code, lang, escaped) {                               // 757  // 765
  if (this.options.highlight) {                                                         // 758  // 766
    var out = this.options.highlight(code, lang);                                       // 759  // 767
    if (out != null && out !== code) {                                                  // 760  // 768
      escaped = true;                                                                   // 761  // 769
      code = out;                                                                       // 762  // 770
    }                                                                                   // 763  // 771
  }                                                                                     // 764  // 772
                                                                                        // 765  // 773
  if (!lang) {                                                                          // 766  // 774
    return '<pre><code>'                                                                // 767  // 775
      + (escaped ? code : escape(code, true))                                           // 768  // 776
      + '\n</code></pre>';                                                              // 769  // 777
  }                                                                                     // 770  // 778
                                                                                        // 771  // 779
  return '<pre><code class="'                                                           // 772  // 780
    + this.options.langPrefix                                                           // 773  // 781
    + escape(lang, true)                                                                // 774  // 782
    + '">'                                                                              // 775  // 783
    + (escaped ? code : escape(code, true))                                             // 776  // 784
    + '\n</code></pre>\n';                                                              // 777  // 785
};                                                                                      // 778  // 786
                                                                                        // 779  // 787
Renderer.prototype.blockquote = function(quote) {                                       // 780  // 788
  return '<blockquote>\n' + quote + '</blockquote>\n';                                  // 781  // 789
};                                                                                      // 782  // 790
                                                                                        // 783  // 791
Renderer.prototype.html = function(html) {                                              // 784  // 792
  return html;                                                                          // 785  // 793
};                                                                                      // 786  // 794
                                                                                        // 787  // 795
Renderer.prototype.heading = function(text, level, raw) {                               // 788  // 796
  return '<h'                                                                           // 789  // 797
    + level                                                                             // 790  // 798
    + ' id="'                                                                           // 791  // 799
    + this.options.headerPrefix                                                         // 792  // 800
    + raw.toLowerCase().replace(/[^\w]+/g, '-')                                         // 793  // 801
    + '">'                                                                              // 794  // 802
    + text                                                                              // 795  // 803
    + '</h'                                                                             // 796  // 804
    + level                                                                             // 797  // 805
    + '>\n';                                                                            // 798  // 806
};                                                                                      // 799  // 807
                                                                                        // 800  // 808
Renderer.prototype.hr = function() {                                                    // 801  // 809
  return this.options.xhtml ? '<hr/>\n' : '<hr>\n';                                     // 802  // 810
};                                                                                      // 803  // 811
                                                                                        // 804  // 812
Renderer.prototype.list = function(body, ordered) {                                     // 805  // 813
  var type = ordered ? 'ol' : 'ul';                                                     // 806  // 814
  return '<' + type + '>\n' + body + '</' + type + '>\n';                               // 807  // 815
};                                                                                      // 808  // 816
                                                                                        // 809  // 817
Renderer.prototype.listitem = function(text) {                                          // 810  // 818
  return '<li>' + text + '</li>\n';                                                     // 811  // 819
};                                                                                      // 812  // 820
                                                                                        // 813  // 821
Renderer.prototype.paragraph = function(text) {                                         // 814  // 822
  return '<p>' + text + '</p>\n';                                                       // 815  // 823
};                                                                                      // 816  // 824
                                                                                        // 817  // 825
Renderer.prototype.table = function(header, body) {                                     // 818  // 826
  return '<table>\n'                                                                    // 819  // 827
    + '<thead>\n'                                                                       // 820  // 828
    + header                                                                            // 821  // 829
    + '</thead>\n'                                                                      // 822  // 830
    + '<tbody>\n'                                                                       // 823  // 831
    + body                                                                              // 824  // 832
    + '</tbody>\n'                                                                      // 825  // 833
    + '</table>\n';                                                                     // 826  // 834
};                                                                                      // 827  // 835
                                                                                        // 828  // 836
Renderer.prototype.tablerow = function(content) {                                       // 829  // 837
  return '<tr>\n' + content + '</tr>\n';                                                // 830  // 838
};                                                                                      // 831  // 839
                                                                                        // 832  // 840
Renderer.prototype.tablecell = function(content, flags) {                               // 833  // 841
  var type = flags.header ? 'th' : 'td';                                                // 834  // 842
  var tag = flags.align                                                                 // 835  // 843
    ? '<' + type + ' style="text-align:' + flags.align + '">'                           // 836  // 844
    : '<' + type + '>';                                                                 // 837  // 845
  return tag + content + '</' + type + '>\n';                                           // 838  // 846
};                                                                                      // 839  // 847
                                                                                        // 840  // 848
// span level renderer                                                                  // 841  // 849
Renderer.prototype.strong = function(text) {                                            // 842  // 850
  return '<strong>' + text + '</strong>';                                               // 843  // 851
};                                                                                      // 844  // 852
                                                                                        // 845  // 853
Renderer.prototype.em = function(text) {                                                // 846  // 854
  return '<em>' + text + '</em>';                                                       // 847  // 855
};                                                                                      // 848  // 856
                                                                                        // 849  // 857
Renderer.prototype.codespan = function(text) {                                          // 850  // 858
  return '<code>' + text + '</code>';                                                   // 851  // 859
};                                                                                      // 852  // 860
                                                                                        // 853  // 861
Renderer.prototype.br = function() {                                                    // 854  // 862
  return this.options.xhtml ? '<br/>' : '<br>';                                         // 855  // 863
};                                                                                      // 856  // 864
                                                                                        // 857  // 865
Renderer.prototype.del = function(text) {                                               // 858  // 866
  return '<del>' + text + '</del>';                                                     // 859  // 867
};                                                                                      // 860  // 868
                                                                                        // 861  // 869
Renderer.prototype.link = function(href, title, text) {                                 // 862  // 870
  if (this.options.sanitize) {                                                          // 863  // 871
    try {                                                                               // 864  // 872
      var prot = decodeURIComponent(unescape(href))                                     // 865  // 873
        .replace(/[^\w:]/g, '')                                                         // 866  // 874
        .toLowerCase();                                                                 // 867  // 875
    } catch (e) {                                                                       // 868  // 876
      return '';                                                                        // 869  // 877
    }                                                                                   // 870  // 878
    if (prot.indexOf('javascript:') === 0 || prot.indexOf('vbscript:') === 0) {         // 871  // 879
      return '';                                                                        // 872  // 880
    }                                                                                   // 873  // 881
  }                                                                                     // 874  // 882
  var out = '<a href="' + href + '"';                                                   // 875  // 883
  if (title) {                                                                          // 876  // 884
    out += ' title="' + title + '"';                                                    // 877  // 885
  }                                                                                     // 878  // 886
  out += '>' + text + '</a>';                                                           // 879  // 887
  return out;                                                                           // 880  // 888
};                                                                                      // 881  // 889
                                                                                        // 882  // 890
Renderer.prototype.image = function(href, title, text) {                                // 883  // 891
  var out = '<img src="' + href + '" alt="' + text + '"';                               // 884  // 892
  if (title) {                                                                          // 885  // 893
    out += ' title="' + title + '"';                                                    // 886  // 894
  }                                                                                     // 887  // 895
  out += this.options.xhtml ? '/>' : '>';                                               // 888  // 896
  return out;                                                                           // 889  // 897
};                                                                                      // 890  // 898
                                                                                        // 891  // 899
/**                                                                                     // 892  // 900
 * Parsing & Compiling                                                                  // 893  // 901
 */                                                                                     // 894  // 902
                                                                                        // 895  // 903
function Parser(options) {                                                              // 896  // 904
  this.tokens = [];                                                                     // 897  // 905
  this.token = null;                                                                    // 898  // 906
  this.options = options || marked.defaults;                                            // 899  // 907
  this.options.renderer = this.options.renderer || new Renderer;                        // 900  // 908
  this.renderer = this.options.renderer;                                                // 901  // 909
  this.renderer.options = this.options;                                                 // 902  // 910
}                                                                                       // 903  // 911
                                                                                        // 904  // 912
/**                                                                                     // 905  // 913
 * Static Parse Method                                                                  // 906  // 914
 */                                                                                     // 907  // 915
                                                                                        // 908  // 916
Parser.parse = function(src, options, renderer) {                                       // 909  // 917
  var parser = new Parser(options, renderer);                                           // 910  // 918
  return parser.parse(src);                                                             // 911  // 919
};                                                                                      // 912  // 920
                                                                                        // 913  // 921
/**                                                                                     // 914  // 922
 * Parse Loop                                                                           // 915  // 923
 */                                                                                     // 916  // 924
                                                                                        // 917  // 925
Parser.prototype.parse = function(src) {                                                // 918  // 926
  this.inline = new InlineLexer(src.links, this.options, this.renderer);                // 919  // 927
  this.tokens = src.reverse();                                                          // 920  // 928
                                                                                        // 921  // 929
  var out = '';                                                                         // 922  // 930
  while (this.next()) {                                                                 // 923  // 931
    out += this.tok();                                                                  // 924  // 932
  }                                                                                     // 925  // 933
                                                                                        // 926  // 934
  return out;                                                                           // 927  // 935
};                                                                                      // 928  // 936
                                                                                        // 929  // 937
/**                                                                                     // 930  // 938
 * Next Token                                                                           // 931  // 939
 */                                                                                     // 932  // 940
                                                                                        // 933  // 941
Parser.prototype.next = function() {                                                    // 934  // 942
  return this.token = this.tokens.pop();                                                // 935  // 943
};                                                                                      // 936  // 944
                                                                                        // 937  // 945
/**                                                                                     // 938  // 946
 * Preview Next Token                                                                   // 939  // 947
 */                                                                                     // 940  // 948
                                                                                        // 941  // 949
Parser.prototype.peek = function() {                                                    // 942  // 950
  return this.tokens[this.tokens.length - 1] || 0;                                      // 943  // 951
};                                                                                      // 944  // 952
                                                                                        // 945  // 953
/**                                                                                     // 946  // 954
 * Parse Text Tokens                                                                    // 947  // 955
 */                                                                                     // 948  // 956
                                                                                        // 949  // 957
Parser.prototype.parseText = function() {                                               // 950  // 958
  var body = this.token.text;                                                           // 951  // 959
                                                                                        // 952  // 960
  while (this.peek().type === 'text') {                                                 // 953  // 961
    body += '\n' + this.next().text;                                                    // 954  // 962
  }                                                                                     // 955  // 963
                                                                                        // 956  // 964
  return this.inline.output(body);                                                      // 957  // 965
};                                                                                      // 958  // 966
                                                                                        // 959  // 967
/**                                                                                     // 960  // 968
 * Parse Current Token                                                                  // 961  // 969
 */                                                                                     // 962  // 970
                                                                                        // 963  // 971
Parser.prototype.tok = function() {                                                     // 964  // 972
  switch (this.token.type) {                                                            // 965  // 973
    case 'space': {                                                                     // 966  // 974
      return '';                                                                        // 967  // 975
    }                                                                                   // 968  // 976
    case 'hr': {                                                                        // 969  // 977
      return this.renderer.hr();                                                        // 970  // 978
    }                                                                                   // 971  // 979
    case 'heading': {                                                                   // 972  // 980
      return this.renderer.heading(                                                     // 973  // 981
        this.inline.output(this.token.text),                                            // 974  // 982
        this.token.depth,                                                               // 975  // 983
        this.token.text);                                                               // 976  // 984
    }                                                                                   // 977  // 985
    case 'code': {                                                                      // 978  // 986
      return this.renderer.code(this.token.text,                                        // 979  // 987
        this.token.lang,                                                                // 980  // 988
        this.token.escaped);                                                            // 981  // 989
    }                                                                                   // 982  // 990
    case 'table': {                                                                     // 983  // 991
      var header = ''                                                                   // 984  // 992
        , body = ''                                                                     // 985  // 993
        , i                                                                             // 986  // 994
        , row                                                                           // 987  // 995
        , cell                                                                          // 988  // 996
        , flags                                                                         // 989  // 997
        , j;                                                                            // 990  // 998
                                                                                        // 991  // 999
      // header                                                                         // 992  // 1000
      cell = '';                                                                        // 993  // 1001
      for (i = 0; i < this.token.header.length; i++) {                                  // 994  // 1002
        flags = { header: true, align: this.token.align[i] };                           // 995  // 1003
        cell += this.renderer.tablecell(                                                // 996  // 1004
          this.inline.output(this.token.header[i]),                                     // 997  // 1005
          { header: true, align: this.token.align[i] }                                  // 998  // 1006
        );                                                                              // 999  // 1007
      }                                                                                 // 1000
      header += this.renderer.tablerow(cell);                                           // 1001
                                                                                        // 1002
      for (i = 0; i < this.token.cells.length; i++) {                                   // 1003
        row = this.token.cells[i];                                                      // 1004
                                                                                        // 1005
        cell = '';                                                                      // 1006
        for (j = 0; j < row.length; j++) {                                              // 1007
          cell += this.renderer.tablecell(                                              // 1008
            this.inline.output(row[j]),                                                 // 1009
            { header: false, align: this.token.align[j] }                               // 1010
          );                                                                            // 1011
        }                                                                               // 1012
                                                                                        // 1013
        body += this.renderer.tablerow(cell);                                           // 1014
      }                                                                                 // 1015
      return this.renderer.table(header, body);                                         // 1016
    }                                                                                   // 1017
    case 'blockquote_start': {                                                          // 1018
      var body = '';                                                                    // 1019
                                                                                        // 1020
      while (this.next().type !== 'blockquote_end') {                                   // 1021
        body += this.tok();                                                             // 1022
      }                                                                                 // 1023
                                                                                        // 1024
      return this.renderer.blockquote(body);                                            // 1025
    }                                                                                   // 1026
    case 'list_start': {                                                                // 1027
      var body = ''                                                                     // 1028
        , ordered = this.token.ordered;                                                 // 1029
                                                                                        // 1030
      while (this.next().type !== 'list_end') {                                         // 1031
        body += this.tok();                                                             // 1032
      }                                                                                 // 1033
                                                                                        // 1034
      return this.renderer.list(body, ordered);                                         // 1035
    }                                                                                   // 1036
    case 'list_item_start': {                                                           // 1037
      var body = '';                                                                    // 1038
                                                                                        // 1039
      while (this.next().type !== 'list_item_end') {                                    // 1040
        body += this.token.type === 'text'                                              // 1041
          ? this.parseText()                                                            // 1042
          : this.tok();                                                                 // 1043
      }                                                                                 // 1044
                                                                                        // 1045
      return this.renderer.listitem(body);                                              // 1046
    }                                                                                   // 1047
    case 'loose_item_start': {                                                          // 1048
      var body = '';                                                                    // 1049
                                                                                        // 1050
      while (this.next().type !== 'list_item_end') {                                    // 1051
        body += this.tok();                                                             // 1052
      }                                                                                 // 1053
                                                                                        // 1054
      return this.renderer.listitem(body);                                              // 1055
    }                                                                                   // 1056
    case 'html': {                                                                      // 1057
      var html = !this.token.pre && !this.options.pedantic                              // 1058
        ? this.inline.output(this.token.text)                                           // 1059
        : this.token.text;                                                              // 1060
      return this.renderer.html(html);                                                  // 1061
    }                                                                                   // 1062
    case 'paragraph': {                                                                 // 1063
      return this.renderer.paragraph(this.inline.output(this.token.text));              // 1064
    }                                                                                   // 1065
    case 'text': {                                                                      // 1066
      return this.renderer.paragraph(this.parseText());                                 // 1067
    }                                                                                   // 1068
  }                                                                                     // 1069
};                                                                                      // 1070
                                                                                        // 1071
/**                                                                                     // 1072
 * Helpers                                                                              // 1073
 */                                                                                     // 1074
                                                                                        // 1075
function escape(html, encode) {                                                         // 1076
  return html                                                                           // 1077
    .replace(!encode ? /&(?!#?\w+;)/g : /&/g, '&amp;')                                  // 1078
    .replace(/</g, '&lt;')                                                              // 1079
    .replace(/>/g, '&gt;')                                                              // 1080
    .replace(/"/g, '&quot;')                                                            // 1081
    .replace(/'/g, '&#39;');                                                            // 1082
}                                                                                       // 1083
                                                                                        // 1084
function unescape(html) {                                                               // 1085
  return html.replace(/&([#\w]+);/g, function(_, n) {                                   // 1086
    n = n.toLowerCase();                                                                // 1087
    if (n === 'colon') return ':';                                                      // 1088
    if (n.charAt(0) === '#') {                                                          // 1089
      return n.charAt(1) === 'x'                                                        // 1090
        ? String.fromCharCode(parseInt(n.substring(2), 16))                             // 1091
        : String.fromCharCode(+n.substring(1));                                         // 1092
    }                                                                                   // 1093
    return '';                                                                          // 1094
  });                                                                                   // 1095
}                                                                                       // 1096
                                                                                        // 1097
function replace(regex, opt) {                                                          // 1098
  regex = regex.source;                                                                 // 1099
  opt = opt || '';                                                                      // 1100
  return function self(name, val) {                                                     // 1101
    if (!name) return new RegExp(regex, opt);                                           // 1102
    val = val.source || val;                                                            // 1103
    val = val.replace(/(^|[^\[])\^/g, '$1');                                            // 1104
    regex = regex.replace(name, val);                                                   // 1105
    return self;                                                                        // 1106
  };                                                                                    // 1107
}                                                                                       // 1108
                                                                                        // 1109
function noop() {}                                                                      // 1110
noop.exec = noop;                                                                       // 1111
                                                                                        // 1112
function merge(obj) {                                                                   // 1113
  var i = 1                                                                             // 1114
    , target                                                                            // 1115
    , key;                                                                              // 1116
                                                                                        // 1117
  for (; i < arguments.length; i++) {                                                   // 1118
    target = arguments[i];                                                              // 1119
    for (key in target) {                                                               // 1120
      if (Object.prototype.hasOwnProperty.call(target, key)) {                          // 1121
        obj[key] = target[key];                                                         // 1122
      }                                                                                 // 1123
    }                                                                                   // 1124
  }                                                                                     // 1125
                                                                                        // 1126
  return obj;                                                                           // 1127
}                                                                                       // 1128
                                                                                        // 1129
                                                                                        // 1130
/**                                                                                     // 1131
 * Marked                                                                               // 1132
 */                                                                                     // 1133
                                                                                        // 1134
function marked(src, opt, callback) {                                                   // 1135
  if (callback || typeof opt === 'function') {                                          // 1136
    if (!callback) {                                                                    // 1137
      callback = opt;                                                                   // 1138
      opt = null;                                                                       // 1139
    }                                                                                   // 1140
                                                                                        // 1141
    opt = merge({}, marked.defaults, opt || {});                                        // 1142
                                                                                        // 1143
    var highlight = opt.highlight                                                       // 1144
      , tokens                                                                          // 1145
      , pending                                                                         // 1146
      , i = 0;                                                                          // 1147
                                                                                        // 1148
    try {                                                                               // 1149
      tokens = Lexer.lex(src, opt)                                                      // 1150
    } catch (e) {                                                                       // 1151
      return callback(e);                                                               // 1152
    }                                                                                   // 1153
                                                                                        // 1154
    pending = tokens.length;                                                            // 1155
                                                                                        // 1156
    var done = function(err) {                                                          // 1157
      if (err) {                                                                        // 1158
        opt.highlight = highlight;                                                      // 1159
        return callback(err);                                                           // 1160
      }                                                                                 // 1161
                                                                                        // 1162
      var out;                                                                          // 1163
                                                                                        // 1164
      try {                                                                             // 1165
        out = Parser.parse(tokens, opt);                                                // 1166
      } catch (e) {                                                                     // 1167
        err = e;                                                                        // 1168
      }                                                                                 // 1169
                                                                                        // 1170
      opt.highlight = highlight;                                                        // 1171
                                                                                        // 1172
      return err                                                                        // 1173
        ? callback(err)                                                                 // 1174
        : callback(null, out);                                                          // 1175
    };                                                                                  // 1176
                                                                                        // 1177
    if (!highlight || highlight.length < 3) {                                           // 1178
      return done();                                                                    // 1179
    }                                                                                   // 1180
                                                                                        // 1181
    delete opt.highlight;                                                               // 1182
                                                                                        // 1183
    if (!pending) return done();                                                        // 1184
                                                                                        // 1185
    for (; i < tokens.length; i++) {                                                    // 1186
      (function(token) {                                                                // 1187
        if (token.type !== 'code') {                                                    // 1188
          return --pending || done();                                                   // 1189
        }                                                                               // 1190
        return highlight(token.text, token.lang, function(err, code) {                  // 1191
          if (err) return done(err);                                                    // 1192
          if (code == null || code === token.text) {                                    // 1193
            return --pending || done();                                                 // 1194
          }                                                                             // 1195
          token.text = code;                                                            // 1196
          token.escaped = true;                                                         // 1197
          --pending || done();                                                          // 1198
        });                                                                             // 1199
      })(tokens[i]);                                                                    // 1200
    }                                                                                   // 1201
                                                                                        // 1202
    return;                                                                             // 1203
  }                                                                                     // 1204
  try {                                                                                 // 1205
    if (opt) opt = merge({}, marked.defaults, opt);                                     // 1206
    return Parser.parse(Lexer.lex(src, opt), opt);                                      // 1207
  } catch (e) {                                                                         // 1208
    e.message += '\nPlease report this to https://github.com/chjj/marked.';             // 1209
    if ((opt || marked.defaults).silent) {                                              // 1210
      return '<p>An error occured:</p><pre>'                                            // 1211
        + escape(e.message + '', true)                                                  // 1212
        + '</pre>';                                                                     // 1213
    }                                                                                   // 1214
    throw e;                                                                            // 1215
  }                                                                                     // 1216
}                                                                                       // 1217
                                                                                        // 1218
/**                                                                                     // 1219
 * Options                                                                              // 1220
 */                                                                                     // 1221
                                                                                        // 1222
marked.options =                                                                        // 1223
marked.setOptions = function(opt) {                                                     // 1224
  merge(marked.defaults, opt);                                                          // 1225
  return marked;                                                                        // 1226
};                                                                                      // 1227
                                                                                        // 1228
marked.defaults = {                                                                     // 1229
  gfm: true,                                                                            // 1230
  tables: true,                                                                         // 1231
  breaks: false,                                                                        // 1232
  pedantic: false,                                                                      // 1233
  sanitize: false,                                                                      // 1234
  smartLists: false,                                                                    // 1235
  silent: false,                                                                        // 1236
  highlight: null,                                                                      // 1237
  langPrefix: 'lang-',                                                                  // 1238
  smartypants: false,                                                                   // 1239
  headerPrefix: '',                                                                     // 1240
  renderer: new Renderer,                                                               // 1241
  xhtml: false                                                                          // 1242
};                                                                                      // 1243
                                                                                        // 1244
/**                                                                                     // 1245
 * Expose                                                                               // 1246
 */                                                                                     // 1247
                                                                                        // 1248
marked.Parser = Parser;                                                                 // 1249
marked.parser = Parser.parse;                                                           // 1250
                                                                                        // 1251
marked.Renderer = Renderer;                                                             // 1252
                                                                                        // 1253
marked.Lexer = Lexer;                                                                   // 1254
marked.lexer = Lexer.lex;                                                               // 1255
                                                                                        // 1256
marked.InlineLexer = InlineLexer;                                                       // 1257
marked.inlineLexer = InlineLexer.output;                                                // 1258
                                                                                        // 1259
marked.parse = marked;                                                                  // 1260
                                                                                        // 1261
if (typeof module !== 'undefined' && typeof exports === 'object') {                     // 1262
  module.exports = marked;                                                              // 1263
} else if (typeof define === 'function' && define.amd) {                                // 1264
  define(function() { return marked; });                                                // 1265
} else {                                                                                // 1266
  this.marked = marked;                                                                 // 1267
}                                                                                       // 1268
                                                                                        // 1269
}).call(function() {                                                                    // 1270
  return this || (typeof window !== 'undefined' ? window : global);                     // 1271
}());                                                                                   // 1272
                                                                                        // 1273
//////////////////////////////////////////////////////////////////////////////////////////      // 1282
                                                                                                // 1283
}).call(this);                                                                                  // 1284
                                                                                                // 1285
                                                                                                // 1286
                                                                                                // 1287
                                                                                                // 1288
                                                                                                // 1289
                                                                                                // 1290
(function () {                                                                                  // 1291
                                                                                                // 1292
//////////////////////////////////////////////////////////////////////////////////////////      // 1293
//                                                                                      //      // 1294
// packages/perak:markdown/markdown.js                                                  //      // 1295
//                                                                                      //      // 1296
//////////////////////////////////////////////////////////////////////////////////////////      // 1297
                                                                                        //      // 1298
var mark = marked;                                                                      // 1    // 1299
                                                                                        // 2    // 1300
mark.setOptions({                                                                       // 3    // 1301
  gfm: true,                                                                            // 4    // 1302
  tables: true,                                                                         // 5    // 1303
  breaks: true                                                                          // 6    // 1304
});                                                                                     // 7    // 1305
                                                                                        // 8    // 1306
Markdown = mark;                                                                        // 9    // 1307
                                                                                        // 10   // 1308
//////////////////////////////////////////////////////////////////////////////////////////      // 1309
                                                                                                // 1310
}).call(this);                                                                                  // 1311
                                                                                                // 1312
//////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['perak:markdown'] = {
  Markdown: Markdown
};

})();

//# sourceMappingURL=perak_markdown.js.map
