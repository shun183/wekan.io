(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/activities.js                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// We use activities fields at two different places:                   //
// 1. The board sidebar                                                //
// 2. The card activity tab                                            //
// We use this publication to paginate for these two publications.     //
                                                                       //
Meteor.publish('activities', function (kind, id, limit) {              // 6
  var _Activities$find;                                                //
                                                                       //
  check(kind, Match.Where(function (x) {                               // 7
    return ['board', 'card'].indexOf(x) !== -1;                        // 8
  }));                                                                 //
  check(id, String);                                                   // 10
  check(limit, Number);                                                // 11
                                                                       //
  return Activities.find((_Activities$find = {}, _Activities$find[kind + 'Id'] = id, _Activities$find), {
    limit: limit,                                                      // 16
    sort: { createdAt: -1 }                                            // 17
  });                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=activities.js.map
