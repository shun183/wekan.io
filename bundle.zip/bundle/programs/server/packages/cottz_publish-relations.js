(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var _ = Package.underscore._;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Crossbar, HandlerController, CursorMethodsNR, CursorMethods;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/publish_relations.js                                         //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
Meteor.publishRelations = function (name, callback) {                                                       // 1
	return Meteor.publish(name, function () {                                                                  // 2
		var handler = new HandlerController(),                                                                    // 3
		    cursors = new CursorMethods(this, handler);                                                           //
                                                                                                            //
		this._publicationName = name;                                                                             // 6
		this.onStop(function () {                                                                                 // 7
			return handler.stop();                                                                                   //
		});                                                                                                       //
                                                                                                            //
		for (var _len = arguments.length, params = Array(_len), _key = 0; _key < _len; _key++) {                  //
			params[_key] = arguments[_key];                                                                          // 2
		}                                                                                                         //
                                                                                                            //
		var cb = callback.apply(_.extend(cursors, this), params);                                                 // 9
		// kadira show me alerts when I use this return (but works well)                                          //
		// return cb || (!this._ready && this.ready());                                                           //
		return cb;                                                                                                // 12
	});                                                                                                        //
};                                                                                                          //
                                                                                                            //
Crossbar = DDPServer._InvalidationCrossbar;                                                                 // 16
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/handler_controller.js                                        //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
// The aim of handler Controller is to keep all observers that can be created within methods                //
// its structure is very simple, has a 'handlers' object containing all observers children and              //
// the observer father is stored within 'handler'                                                           //
HandlerController = (function () {                                                                          // 4
	function _class() {                                                                                        // 5
		babelHelpers.classCallCheck(this, _class);                                                                //
                                                                                                            //
		this.handlers = {};                                                                                       // 6
	}                                                                                                          //
                                                                                                            //
	_class.prototype.set = (function () {                                                                      //
		function set(handler) {                                                                                   // 8
			return this.handler = handler;                                                                           // 9
		}                                                                                                         //
                                                                                                            //
		return set;                                                                                               //
	})();                                                                                                      //
                                                                                                            //
	_class.prototype.addBasic = (function () {                                                                 //
		function addBasic(collection, handler) {                                                                  // 11
			var oldHandler = this.handlers[collection];                                                              // 12
			return oldHandler || (this.handlers[collection] = handler || new HandlerController());                   // 13
		}                                                                                                         //
                                                                                                            //
		return addBasic;                                                                                          //
	})();                                                                                                      //
                                                                                                            //
	_class.prototype.add = (function () {                                                                      //
		function add(cursor, options) {                                                                           // 15
			if (!cursor) throw new Error("you're not sending the cursor");                                           // 16
                                                                                                            //
			var description = cursor._cursorDescription,                                                             // 19
			    collection = options.collection || description.collectionName,                                       //
			    selector = description.selector;                                                                     //
                                                                                                            //
			var oldHandler = this.handlers[collection];                                                              // 23
			if (oldHandler) {                                                                                        // 24
				// when the selector equals method stops running, no change occurs and everything                       //
				// will still work properly without running the same observer again                                     //
				oldHandler.equalSelector = _.isEqual(oldHandler.selector, selector);                                    // 27
				if (oldHandler.equalSelector) return oldHandler;                                                        // 28
                                                                                                            //
				oldHandler.stop();                                                                                      // 31
			}                                                                                                        //
                                                                                                            //
			var newHandler = options.handler ? cursor[options.handler](options.callbacks) : new HandlerController();
                                                                                                            //
			newHandler.selector = selector;                                                                          // 38
                                                                                                            //
			return this.handlers[collection] = newHandler;                                                           // 40
		}                                                                                                         //
                                                                                                            //
		return add;                                                                                               //
	})();                                                                                                      //
                                                                                                            //
	_class.prototype.stop = (function () {                                                                     //
		function stop() {                                                                                         // 42
			var handlers = this.handlers;                                                                            // 43
                                                                                                            //
			this.handler && this.handler.stop();                                                                     // 45
                                                                                                            //
			for (var key in babelHelpers.sanitizeForInObject(handlers)) {                                            // 47
				handlers[key].stop();                                                                                   // 48
			};                                                                                                       //
                                                                                                            //
			this.handlers = [];                                                                                      // 51
		}                                                                                                         //
                                                                                                            //
		return stop;                                                                                              //
	})();                                                                                                      //
                                                                                                            //
	_class.prototype.remove = (function () {                                                                   //
		function remove(_id) {                                                                                    // 53
			var handler = this.handlers[_id];                                                                        // 54
			if (handler) {                                                                                           // 55
				handler.stop();                                                                                         // 56
				delete this.handlers[_id];                                                                              // 57
			}                                                                                                        //
		}                                                                                                         //
                                                                                                            //
		return remove;                                                                                            //
	})();                                                                                                      //
                                                                                                            //
	return _class;                                                                                             //
})();                                                                                                       //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/methods.js                                                   //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
Meteor.methods({                                                                                            // 1
	'PR.changePagination': function (data) {                                                                   // 2
		check(data, {                                                                                             // 3
			_id: String,                                                                                             // 4
			field: String,                                                                                           // 5
			skip: Match.Integer                                                                                      // 6
		});                                                                                                       //
                                                                                                            //
		Crossbar.fire(_.extend({                                                                                  // 9
			collection: 'paginations',                                                                               // 10
			id: this.connection.id                                                                                   // 11
		}, data));                                                                                                //
	},                                                                                                         //
	'PR.fireListener': function (collection, options) {                                                        // 14
		check(collection, String);                                                                                // 15
                                                                                                            //
		Crossbar.fire(_.extend({                                                                                  // 17
			collection: 'listen-' + collection,                                                                      // 18
			id: this.connection.id                                                                                   // 19
		}, options));                                                                                             //
	}                                                                                                          //
});                                                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/nonreactive/cursor.js                                 //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
CursorMethodsNR = (function () {                                                                            // 1
	function _class(sub) {                                                                                     // 2
		babelHelpers.classCallCheck(this, _class);                                                                //
                                                                                                            //
		this.sub = sub;                                                                                           // 3
	}                                                                                                          //
                                                                                                            //
	_class.prototype.cursorNonreactive = (function () {                                                        //
		function cursorNonreactive(cursor, collection, onAdded) {                                                 // 5
			var sub = this.sub;                                                                                      // 6
                                                                                                            //
			if (!_.isString(collection)) {                                                                           // 8
				onAdded = collection;                                                                                   // 9
				console.log('hola ? ');                                                                                 // 10
				collection = cursor._getCollectionName();                                                               // 11
			}                                                                                                        //
			if (!_.isFunction(onAdded)) onAdded = function () {};                                                    // 13
                                                                                                            //
			cursor.forEach(function (doc) {                                                                          // 16
				var _id = doc._id;                                                                                      // 17
				sub.added(collection, onAdded.call(new CursorMethodsNR(sub), _id, doc) || doc);                         // 18
			});                                                                                                      //
		}                                                                                                         //
                                                                                                            //
		return cursorNonreactive;                                                                                 //
	})();                                                                                                      //
                                                                                                            //
	return _class;                                                                                             //
})();                                                                                                       //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/nonreactive/join.js                                   //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
CursorMethodsNR.prototype.joinNonreactive = function () {                                                   // 1
	for (var _len = arguments.length, params = Array(_len), _key = 0; _key < _len; _key++) {                   //
		params[_key] = arguments[_key];                                                                           // 1
	}                                                                                                          //
                                                                                                            //
	return new (babelHelpers.bind.apply(CursorJoinNonreactive, [null].concat([this.sub], params)))();          // 2
};                                                                                                          //
                                                                                                            //
var CursorJoinNonreactive = (function () {                                                                  //
	function CursorJoinNonreactive(sub, collection, options, name) {                                           // 6
		babelHelpers.classCallCheck(this, CursorJoinNonreactive);                                                 //
                                                                                                            //
		this.sub = sub;                                                                                           // 7
		this.collection = collection;                                                                             // 8
		this.options = options;                                                                                   // 9
		this.name = name || collection._name;                                                                     // 10
                                                                                                            //
		this.data = [];                                                                                           // 12
		this.sent = false;                                                                                        // 13
	}                                                                                                          //
                                                                                                            //
	CursorJoinNonreactive.prototype._selector = (function () {                                                 // 5
		function _selector() {                                                                                    // 15
			var _id = arguments.length <= 0 || arguments[0] === undefined ? { $in: this.data } : arguments[0];       //
                                                                                                            //
			return _.isFunction(this.selector) ? this.selector(_id) : { _id: _id };                                  // 16
		}                                                                                                         //
                                                                                                            //
		return _selector;                                                                                         //
	})();                                                                                                      //
                                                                                                            //
	CursorJoinNonreactive.prototype.push = (function () {                                                      // 5
		function push(_id) {                                                                                      // 18
			if (!_id || _.contains(this.data, _id)) return;                                                          // 19
                                                                                                            //
			this.data.push(_id);                                                                                     // 22
			if (this.sent) return this.added(_id);                                                                   // 23
		}                                                                                                         //
                                                                                                            //
		return push;                                                                                              //
	})();                                                                                                      //
                                                                                                            //
	CursorJoinNonreactive.prototype.send = (function () {                                                      // 5
		function send() {                                                                                         // 26
			this.sent = true;                                                                                        // 27
			if (!this.data.length) return;                                                                           // 28
                                                                                                            //
			return this.added();                                                                                     // 30
		}                                                                                                         //
                                                                                                            //
		return send;                                                                                              //
	})();                                                                                                      //
                                                                                                            //
	CursorJoinNonreactive.prototype.added = (function () {                                                     // 5
		function added(_id) {                                                                                     // 32
			var _this = this;                                                                                        //
                                                                                                            //
			this.collection.find(this._selector(_id), this.options).forEach(function (doc) {                         // 33
				_this.sub.added(_this.name, doc._id, _.omit(doc, '_id'));                                               // 34
			});                                                                                                      //
		}                                                                                                         //
                                                                                                            //
		return added;                                                                                             //
	})();                                                                                                      //
                                                                                                            //
	return CursorJoinNonreactive;                                                                              //
})();                                                                                                       //
                                                                                                            //
;                                                                                                           // 37
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/cursor.js                                             //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
CursorMethods = (function (_CursorMethodsNR) {                                                              // 1
	babelHelpers.inherits(_class, _CursorMethodsNR);                                                           //
                                                                                                            //
	function _class(sub, handler, _id, collection) {                                                           // 2
		babelHelpers.classCallCheck(this, _class);                                                                //
                                                                                                            //
		_CursorMethodsNR.call(this, sub);                                                                         // 3
                                                                                                            //
		this.handler = handler;                                                                                   // 5
		this._id = _id;                                                                                           // 6
		this.collection = collection;                                                                             // 7
	}                                                                                                          //
                                                                                                            //
	_class.prototype.cursor = (function () {                                                                   //
		function cursor(_cursor, collection, callbacks) {                                                         // 9
			var sub = this.sub;                                                                                      // 10
                                                                                                            //
			if (!_.isString(collection)) {                                                                           // 12
				callbacks = collection;                                                                                 // 13
				collection = _cursor._getCollectionName();                                                              // 14
			}                                                                                                        //
                                                                                                            //
			var handler = this.handler.add(_cursor, { collection: collection });                                     // 17
			if (handler.equalSelector) return handler;                                                               // 18
                                                                                                            //
			if (callbacks) callbacks = this._getCallbacks(callbacks);                                                // 21
                                                                                                            //
			function applyCallback(id, doc, method) {                                                                // 24
				var cb = callbacks && callbacks[method];                                                                // 25
                                                                                                            //
				if (cb) {                                                                                               // 27
					var methods = new CursorMethods(sub, handler.addBasic(id), id, collection),                            // 28
					    isChanged = method === 'changed';                                                                  //
                                                                                                            //
					return cb.call(methods, id, doc, isChanged) || doc;                                                    // 31
				} else return doc;                                                                                      //
			};                                                                                                       //
                                                                                                            //
			var observeChanges = _cursor.observeChanges({                                                            // 36
				added: function (id, doc) {                                                                             // 37
					sub.added(collection, id, applyCallback(id, doc, 'added'));                                            // 38
				},                                                                                                      //
				changed: function (id, doc) {                                                                           // 40
					sub.changed(collection, id, applyCallback(id, doc, 'changed'));                                        // 41
				},                                                                                                      //
				removed: function (id) {                                                                                // 43
					if (callbacks) {                                                                                       // 44
						callbacks.removed(id);                                                                                // 45
						handler.remove(id);                                                                                   // 46
					}                                                                                                      //
                                                                                                            //
					sub.removed(collection, id);                                                                           // 49
				}                                                                                                       //
			});                                                                                                      //
                                                                                                            //
			return handler.set(observeChanges);                                                                      // 53
		}                                                                                                         //
                                                                                                            //
		return cursor;                                                                                            //
	})();                                                                                                      //
                                                                                                            //
	return _class;                                                                                             //
})(CursorMethodsNR);                                                                                        //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/utils.js                                              //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
function getCB(cb, method) {                                                                                // 1
	var callback = cb[method];                                                                                 // 2
	if (callback && !_.isFunction(callback)) throw new Error(method + ' should be a function or undefined');   // 3
                                                                                                            //
	return callback || function () {};                                                                         // 6
};                                                                                                          //
                                                                                                            //
CursorMethods.prototype._getCallbacks = function (cb, onRemoved) {                                          // 9
	if (_.isFunction(cb)) {                                                                                    // 10
		return {                                                                                                  // 11
			added: cb,                                                                                               // 12
			changed: cb,                                                                                             // 13
			removed: getCB({ onRemoved: onRemoved }, 'onRemoved')                                                    // 14
		};                                                                                                        //
	}                                                                                                          //
                                                                                                            //
	return {                                                                                                   // 18
		added: getCB(cb, 'added'),                                                                                // 19
		changed: getCB(cb, 'changed'),                                                                            // 20
		removed: getCB(cb, 'removed')                                                                             // 21
	};                                                                                                         //
};                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/observe.js                                            //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
CursorMethods.prototype.observe = function (cursor, callbacks) {                                            // 1
	this.handler.add(cursor, {                                                                                 // 2
		handler: 'observe',                                                                                       // 3
		callbacks: callbacks                                                                                      // 4
	});                                                                                                        //
};                                                                                                          //
                                                                                                            //
CursorMethods.prototype.observeChanges = function (cursor, callbacks) {                                     // 8
	this.handler.add(cursor, {                                                                                 // 9
		handler: 'observeChanges',                                                                                // 10
		callbacks: callbacks                                                                                      // 11
	});                                                                                                        //
};                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/join.js                                               //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
CursorMethods.prototype.join = function () {                                                                // 1
	for (var _len = arguments.length, params = Array(_len), _key = 0; _key < _len; _key++) {                   //
		params[_key] = arguments[_key];                                                                           // 1
	}                                                                                                          //
                                                                                                            //
	return new (babelHelpers.bind.apply(CursorJoin, [null].concat(params)))();                                 // 2
};                                                                                                          //
                                                                                                            //
var CursorJoin = (function () {                                                                             //
	function CursorJoin(collection, options, name) {                                                           // 6
		babelHelpers.classCallCheck(this, CursorJoin);                                                            //
                                                                                                            //
		this.collection = collection;                                                                             // 7
		this.options = options;                                                                                   // 8
		this.name = name;                                                                                         // 9
                                                                                                            //
		this.data = [];                                                                                           // 11
		this.sent = false;                                                                                        // 12
	}                                                                                                          //
                                                                                                            //
	CursorJoin.prototype.push = (function () {                                                                 // 5
		function push(sub, _id) {                                                                                 // 14
			if (!_id || _.contains(this.data, _id)) return;                                                          // 15
                                                                                                            //
			this.data.push(_id);                                                                                     // 18
			if (this.sent) return this._cursor(sub, _id);                                                            // 19
		}                                                                                                         //
                                                                                                            //
		return push;                                                                                              //
	})();                                                                                                      //
                                                                                                            //
	CursorJoin.prototype.send = (function () {                                                                 // 5
		function send(sub) {                                                                                      // 22
			this.sent = true;                                                                                        // 23
			if (!this.data.length) return;                                                                           // 24
                                                                                                            //
			return this._cursor(sub);                                                                                // 26
		}                                                                                                         //
                                                                                                            //
		return send;                                                                                              //
	})();                                                                                                      //
                                                                                                            //
	CursorJoin.prototype._selector = (function () {                                                            // 5
		function _selector() {                                                                                    // 28
			var _id = arguments.length <= 0 || arguments[0] === undefined ? { $in: this.data } : arguments[0];       //
                                                                                                            //
			return _.isFunction(this.selector) ? this.selector(_id) : { _id: _id };                                  // 29
		}                                                                                                         //
                                                                                                            //
		return _selector;                                                                                         //
	})();                                                                                                      //
                                                                                                            //
	CursorJoin.prototype._cursor = (function () {                                                              // 5
		function _cursor(sub, _id) {                                                                              // 31
			return sub.cursor(this.collection.find(this._selector(_id), this.options), this.name);                   // 32
		}                                                                                                         //
                                                                                                            //
		return _cursor;                                                                                           //
	})();                                                                                                      //
                                                                                                            //
	return CursorJoin;                                                                                         //
})();                                                                                                       //
                                                                                                            //
;                                                                                                           // 34
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/crossbar.js                                           //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
// designed to paginate a list, works in conjunction with the methods                                       //
// do not call back to the main callback, only the array is changed in the collection                       //
CursorMethods.prototype.paginate = function (fieldData, limit, infinite) {                                  // 3
	var sub = this.sub,                                                                                        // 4
	    _id = this._id,                                                                                        //
	    collection = this.collection;                                                                          //
                                                                                                            //
	if (!_id || !collection) throw new Error("you can't use this method without being within a document");     // 8
                                                                                                            //
	var field = Object.keys(fieldData)[0],                                                                     // 11
	    copy = _.clone(fieldData)[field],                                                                      //
	    max = copy.length,                                                                                     //
	    connectionId = sub.connection.id;                                                                      //
                                                                                                            //
	fieldData[field] = copy.slice(0, limit);                                                                   // 16
                                                                                                            //
	var listener = Crossbar.listen({                                                                           // 18
		collection: 'paginations',                                                                                // 19
		id: connectionId                                                                                          // 20
	}, function (data) {                                                                                       //
		if (!data.id || data.id !== connectionId) return;                                                         // 22
                                                                                                            //
		var skip = data.skip;                                                                                     // 24
                                                                                                            //
		if (skip >= max && !infinite) return;                                                                     // 26
                                                                                                            //
		fieldData[field] = infinite ? copy.slice(0, skip) : copy.slice(skip, skip + limit);                       // 29
		sub.changed(collection, data._id, fieldData);                                                             // 30
	});                                                                                                        //
                                                                                                            //
	this.handler.addBasic(field, listener);                                                                    // 33
                                                                                                            //
	return fieldData[field];                                                                                   // 35
};                                                                                                          //
                                                                                                            //
CursorMethods.prototype.listen = function (options, callback, run) {                                        // 38
	var sub = this.sub,                                                                                        // 39
	    name = 'listen-' + this._publicationName,                                                              //
	    listener = Crossbar.listen({                                                                           //
		collection: name,                                                                                         // 43
		id: sub.connection.id                                                                                     // 44
	}, function (data) {                                                                                       //
		if (!data.id || data.id !== sub.connection.id) return;                                                    // 46
                                                                                                            //
		_.extend(options, _.omit(data, 'collection', 'id'));                                                      // 48
		callback.call(methods);                                                                                   // 49
	}),                                                                                                        //
	    handler = this.handler.addBasic(name),                                                                 //
	    methods = new CursorMethods(sub, handler);                                                             //
                                                                                                            //
	if (run !== false) callback.call(methods, true);                                                           // 55
                                                                                                            //
	return handler.set(listener);                                                                              // 57
};                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/cottz_publish-relations/lib/server/cursor/change_parent_doc.js                                  //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
// DEPRECATED                                                                                               //
// designed to change something in the master document while the callbacks are executed                     //
// changes to the document are sent to the main document with the return of the callbacks                   //
CursorMethods.prototype.changeParentDoc = function (cursor, callbacks, onRemoved) {                         // 4
	var sub = this.sub,                                                                                        // 5
	    _id = this._id,                                                                                        //
	    collection = this.collection,                                                                          //
	    result = this;                                                                                         //
                                                                                                            //
	if (!_id || !collection) throw new Error("you can't use this method without being within a document");     // 10
                                                                                                            //
	callbacks = this._getCallbacks(callbacks, onRemoved);                                                      // 13
                                                                                                            //
	this.handler.add(cursor, {                                                                                 // 15
		handler: 'observeChanges',                                                                                // 16
		callbacks: {                                                                                              // 17
			added: function (id, doc) {                                                                              // 18
				result._addedWithCPD = callbacks.added(id, doc);                                                        // 19
			},                                                                                                       //
			changed: function (id, doc) {                                                                            // 21
				var changes = callbacks.changed(id, doc);                                                               // 22
				if (changes) sub.changed(collection, _id, changes);                                                     // 23
			},                                                                                                       //
			removed: function (id) {                                                                                 // 26
				var changes = callbacks.removed(id);                                                                    // 27
				if (changes) sub.changed(collection, _id, changes);                                                     // 28
			}                                                                                                        //
		}                                                                                                         //
	});                                                                                                        //
                                                                                                            //
	return result._addedWithCPD || {};                                                                         // 34
};                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cottz:publish-relations'] = {};

})();

//# sourceMappingURL=cottz_publish-relations.js.map
