(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/users.js                                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Users = Meteor.users; // eslint-disable-line meteor/collections        // 1
                                                                       //
// Search a user in the complete server database by its name or username. This
// is used for instance to add a new user to a board.                  //
var searchInFields = ['username', 'profile.fullname'];                 // 5
Users.initEasySearch(searchInFields, {                                 // 6
  use: 'mongo-db',                                                     // 7
  returnFields: [].concat(searchInFields, ['profile.avatarUrl'])       // 8
});                                                                    //
                                                                       //
if (Meteor.isClient) {                                                 // 11
  Users.helpers({                                                      // 12
    isBoardMember: function () {                                       // 13
      var board = Boards.findOne(Session.get('currentBoard'));         // 14
      return board && board.hasMember(this._id);                       // 15
    },                                                                 //
                                                                       //
    isBoardAdmin: function () {                                        // 18
      var board = Boards.findOne(Session.get('currentBoard'));         // 19
      return board && board.hasAdmin(this._id);                        // 20
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
Users.helpers({                                                        // 25
  boards: function () {                                                // 26
    return Boards.find({ userId: this._id });                          // 27
  },                                                                   //
                                                                       //
  starredBoards: function () {                                         // 30
    var _profile$starredBoards = this.profile.starredBoards;           //
    var starredBoards = _profile$starredBoards === undefined ? [] : _profile$starredBoards;
                                                                       //
    return Boards.find({ archived: false, _id: { $in: starredBoards } });
  },                                                                   //
                                                                       //
  hasStarred: function (boardId) {                                     // 35
    var _profile$starredBoards2 = this.profile.starredBoards;          //
    var starredBoards = _profile$starredBoards2 === undefined ? [] : _profile$starredBoards2;
                                                                       //
    return _.contains(starredBoards, boardId);                         // 37
  },                                                                   //
                                                                       //
  invitedBoards: function () {                                         // 40
    var _profile$invitedBoards = this.profile.invitedBoards;           //
    var invitedBoards = _profile$invitedBoards === undefined ? [] : _profile$invitedBoards;
                                                                       //
    return Boards.find({ archived: false, _id: { $in: invitedBoards } });
  },                                                                   //
                                                                       //
  isInvitedTo: function (boardId) {                                    // 45
    var _profile$invitedBoards2 = this.profile.invitedBoards;          //
    var invitedBoards = _profile$invitedBoards2 === undefined ? [] : _profile$invitedBoards2;
                                                                       //
    return _.contains(invitedBoards, boardId);                         // 47
  },                                                                   //
                                                                       //
  getInitials: function () {                                           // 50
    var profile = this.profile || {};                                  // 51
    if (profile.initials) return profile.initials;else if (profile.fullname) {
      return profile.fullname.split(/\s+/).reduce(function (memo, word) {
        if (memo === undefined) memo = '';                             //
                                                                       //
        return memo + word[0];                                         // 57
      }).toUpperCase();                                                //
    } else {                                                           //
      return this.username[0].toUpperCase();                           // 61
    }                                                                  //
  },                                                                   //
                                                                       //
  getName: function () {                                               // 65
    var profile = this.profile || {};                                  // 66
    return profile.fullname || this.username;                          // 67
  },                                                                   //
                                                                       //
  getLanguage: function () {                                           // 70
    var profile = this.profile || {};                                  // 71
    return profile.language || 'en';                                   // 72
  }                                                                    //
});                                                                    //
                                                                       //
Users.mutations({                                                      // 76
  toggleBoardStar: function (boardId) {                                // 77
    var _ref;                                                          //
                                                                       //
    var queryKind = this.hasStarred(boardId) ? '$pull' : '$addToSet';  // 78
    return (_ref = {}, _ref[queryKind] = {                             // 79
      'profile.starredBoards': boardId                                 // 81
    }, _ref);                                                          //
  },                                                                   //
                                                                       //
  addInvite: function (boardId) {                                      // 86
    return {                                                           // 87
      $addToSet: {                                                     // 88
        'profile.invitedBoards': boardId                               // 89
      }                                                                //
    };                                                                 //
  },                                                                   //
                                                                       //
  removeInvite: function (boardId) {                                   // 94
    return {                                                           // 95
      $pull: {                                                         // 96
        'profile.invitedBoards': boardId                               // 97
      }                                                                //
    };                                                                 //
  },                                                                   //
                                                                       //
  setAvatarUrl: function (avatarUrl) {                                 // 102
    return { $set: { 'profile.avatarUrl': avatarUrl } };               // 103
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 107
  setUsername: function (username) {                                   // 108
    check(username, String);                                           // 109
    var nUsersWithUsername = Users.find({ username: username }).count();
    if (nUsersWithUsername > 0) {                                      // 111
      throw new Meteor.Error('username-already-taken');                // 112
    } else {                                                           //
      Users.update(this.userId, { $set: { username: username } });     // 114
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 119
  Meteor.methods({                                                     // 120
    // we accept userId, username, email                               //
    inviteUserToBoard: function (username, boardId) {                  // 122
      check(username, String);                                         // 123
      check(boardId, String);                                          // 124
                                                                       //
      var inviter = Meteor.user();                                     // 126
      var board = Boards.findOne(boardId);                             // 127
      var allowInvite = inviter && board && board.members && _.contains(_.pluck(board.members, 'userId'), inviter._id) && _.where(board.members, { userId: inviter._id })[0].isActive && _.where(board.members, { userId: inviter._id })[0].isAdmin;
      if (!allowInvite) throw new Meteor.Error('error-board-notAMember');
                                                                       //
      this.unblock();                                                  // 136
                                                                       //
      var posAt = username.indexOf('@');                               // 138
      var user = null;                                                 // 139
      if (posAt >= 0) {                                                // 140
        user = Users.findOne({ emails: { $elemMatch: { address: username } } });
      } else {                                                         //
        user = Users.findOne(username) || Users.findOne({ username: username });
      }                                                                //
      if (user) {                                                      // 145
        if (user._id === inviter._id) throw new Meteor.Error('error-user-notAllowSelf');
      } else {                                                         //
        if (posAt <= 0) throw new Meteor.Error('error-user-doesNotExist');
                                                                       //
        var email = username;                                          // 150
        username = email.substring(0, posAt);                          // 151
        var newUserId = Accounts.createUser({ username: username, email: email });
        if (!newUserId) throw new Meteor.Error('error-user-notCreated');
        // assume new user speak same language with inviter            //
        if (inviter.profile && inviter.profile.language) {             // 155
          Users.update(newUserId, {                                    // 156
            $set: {                                                    // 157
              'profile.language': inviter.profile.language             // 158
            }                                                          //
          });                                                          //
        }                                                              //
        Accounts.sendEnrollmentEmail(newUserId);                       // 162
        user = Users.findOne(newUserId);                               // 163
      }                                                                //
                                                                       //
      board.addMember(user._id);                                       // 166
      user.addInvite(boardId);                                         // 167
                                                                       //
      if (!process.env.MAIL_URL || !Email) return { username: user.username };
                                                                       //
      try {                                                            // 171
        var rootUrl = Meteor.absoluteUrl.defaultOptions.rootUrl || '';
        if (!rootUrl.endsWith('/')) rootUrl = rootUrl + '/';           // 173
        var boardUrl = rootUrl + 'b/' + board._id + '/' + board.slug;  // 174
                                                                       //
        var vars = {                                                   // 176
          user: user.username,                                         // 177
          inviter: inviter.username,                                   // 178
          board: board.title,                                          // 179
          url: boardUrl                                                // 180
        };                                                             //
        var lang = user.getLanguage();                                 // 182
        Email.send({                                                   // 183
          to: user.emails[0].address,                                  // 184
          from: Accounts.emailTemplates.from,                          // 185
          subject: TAPi18n.__('email-invite-subject', vars, lang),     // 186
          text: TAPi18n.__('email-invite-text', vars, lang)            // 187
        });                                                            //
      } catch (e) {                                                    //
        throw new Meteor.Error('email-fail', e.message);               // 190
      }                                                                //
                                                                       //
      return { username: user.username, email: user.emails[0].address };
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
Users.before.insert(function (userId, doc) {                           // 198
  doc.profile = doc.profile || {};                                     // 199
                                                                       //
  if (!doc.username && doc.profile.name) {                             // 201
    doc.username = doc.profile.name.toLowerCase().replace(/\s/g, '');  // 202
  }                                                                    //
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 206
  // Let mongoDB ensure username unicity                               //
  Meteor.startup(function () {                                         // 208
    Users._collection._ensureIndex({                                   // 209
      username: 1                                                      // 210
    }, { unique: true });                                              //
  });                                                                  //
                                                                       //
  // Each board document contains the de-normalized number of users that have
  // starred it. If the user star or unstar a board, we need to update this
  // counter.                                                          //
  // We need to run this code on the server only, otherwise the incrementation
  // will be done twice.                                               //
  Users.after.update(function (userId, user, fieldNames) {             // 219
    // The `starredBoards` list is hosted on the `profile` field. If this
    // field hasn't been modificated we don't need to run this hook.   //
    if (!_.contains(fieldNames, 'profile')) return;                    // 222
                                                                       //
    // To calculate a diff of board starred ids, we get both the previous
    // and the newly board ids list                                    //
    function getStarredBoardsIds(doc) {                                // 227
      return doc.profile && doc.profile.starredBoards;                 // 228
    }                                                                  //
    var oldIds = getStarredBoardsIds(this.previous);                   // 230
    var newIds = getStarredBoardsIds(user);                            // 231
                                                                       //
    // The _.difference(a, b) method returns the values from a that are not in
    // b. We use it to find deleted and newly inserted ids by using it in one
    // direction and then in the other.                                //
    function incrementBoards(boardsIds, inc) {                         // 236
      boardsIds.forEach(function (boardId) {                           // 237
        Boards.update(boardId, { $inc: { stars: inc } });              // 238
      });                                                              //
    }                                                                  //
    incrementBoards(_.difference(oldIds, newIds), -1);                 // 241
    incrementBoards(_.difference(newIds, oldIds), +1);                 // 242
  });                                                                  //
                                                                       //
  // XXX i18n                                                          //
  Users.after.insert(function (userId, doc) {                          // 246
    var ExampleBoard = {                                               // 247
      title: 'Welcome Board',                                          // 248
      userId: doc._id,                                                 // 249
      permission: 'private'                                            // 250
    };                                                                 //
                                                                       //
    // Insert the Welcome Board                                        //
    Boards.insert(ExampleBoard, function (err, boardId) {              // 254
                                                                       //
      ['Basics', 'Advanced'].forEach(function (title) {                // 256
        var list = {                                                   // 257
          title: title,                                                // 258
          boardId: boardId,                                            // 259
          userId: ExampleBoard.userId,                                 // 260
                                                                       //
          // XXX Not certain this is a bug, but we except these fields get
          // inserted by the Lists.before.insert collection-hook. Since this
          // hook is not called in this case, we have to dublicate the logic and
          // set them here.                                            //
          archived: false,                                             // 266
          createdAt: new Date()                                        // 267
        };                                                             //
                                                                       //
        Lists.insert(list);                                            // 270
      });                                                              //
    });                                                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=users.js.map
