(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/cards.js                                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Cards = new Mongo.Collection('cards');                                 // 1
                                                                       //
// XXX To improve pub/sub performances a card document should include a
// de-normalized number of comments so we don't have to publish the whole list
// of comments just to display the number of them in the board view.   //
Cards.attachSchema(new SimpleSchema({                                  // 6
  title: {                                                             // 7
    type: String                                                       // 8
  },                                                                   //
  archived: {                                                          // 10
    type: Boolean                                                      // 11
  },                                                                   //
  listId: {                                                            // 13
    type: String                                                       // 14
  },                                                                   //
  // The system could work without this `boardId` information (we could deduce
  // the board identifier from the card), but it would make the system more
  // difficult to manage and less efficient.                           //
  boardId: {                                                           // 19
    type: String                                                       // 20
  },                                                                   //
  coverId: {                                                           // 22
    type: String,                                                      // 23
    optional: true                                                     // 24
  },                                                                   //
  createdAt: {                                                         // 26
    type: Date,                                                        // 27
    denyUpdate: true                                                   // 28
  },                                                                   //
  dateLastActivity: {                                                  // 30
    type: Date                                                         // 31
  },                                                                   //
  description: {                                                       // 33
    type: String,                                                      // 34
    optional: true                                                     // 35
  },                                                                   //
  labelIds: {                                                          // 37
    type: [String],                                                    // 38
    optional: true                                                     // 39
  },                                                                   //
  members: {                                                           // 41
    type: [String],                                                    // 42
    optional: true                                                     // 43
  },                                                                   //
  // XXX Should probably be called `authorId`. Is it even needed since we have
  // the `members` field?                                              //
  userId: {                                                            // 47
    type: String                                                       // 48
  },                                                                   //
  sort: {                                                              // 50
    type: Number,                                                      // 51
    decimal: true                                                      // 52
  }                                                                    //
}));                                                                   //
                                                                       //
Cards.allow({                                                          // 56
  insert: function (userId, doc) {                                     // 57
    return allowIsBoardMember(userId, Boards.findOne(doc.boardId));    // 58
  },                                                                   //
  update: function (userId, doc) {                                     // 60
    return allowIsBoardMember(userId, Boards.findOne(doc.boardId));    // 61
  },                                                                   //
  remove: function (userId, doc) {                                     // 63
    return allowIsBoardMember(userId, Boards.findOne(doc.boardId));    // 64
  },                                                                   //
  fetch: ['boardId']                                                   // 66
});                                                                    //
                                                                       //
Cards.helpers({                                                        // 69
  list: function () {                                                  // 70
    return Lists.findOne(this.listId);                                 // 71
  },                                                                   //
                                                                       //
  board: function () {                                                 // 74
    return Boards.findOne(this.boardId);                               // 75
  },                                                                   //
                                                                       //
  labels: function () {                                                // 78
    var _this = this;                                                  //
                                                                       //
    var boardLabels = this.board().labels;                             // 79
    var cardLabels = _.filter(boardLabels, function (label) {          // 80
      return _.contains(_this.labelIds, label._id);                    // 81
    });                                                                //
    return cardLabels;                                                 // 83
  },                                                                   //
                                                                       //
  hasLabel: function (labelId) {                                       // 86
    return _.contains(this.labelIds, labelId);                         // 87
  },                                                                   //
                                                                       //
  user: function () {                                                  // 90
    return Users.findOne(this.userId);                                 // 91
  },                                                                   //
                                                                       //
  isAssigned: function (memberId) {                                    // 94
    return _.contains(this.members, memberId);                         // 95
  },                                                                   //
                                                                       //
  activities: function () {                                            // 98
    return Activities.find({ cardId: this._id }, { sort: { createdAt: -1 } });
  },                                                                   //
                                                                       //
  comments: function () {                                              // 102
    return CardComments.find({ cardId: this._id }, { sort: { createdAt: -1 } });
  },                                                                   //
                                                                       //
  attachments: function () {                                           // 106
    return Attachments.find({ cardId: this._id }, { sort: { uploadedAt: -1 } });
  },                                                                   //
                                                                       //
  cover: function () {                                                 // 110
    var cover = Attachments.findOne(this.coverId);                     // 111
    // if we return a cover before it is fully stored, we will get errors when we try to display it
    // todo XXX we could return a default "upload pending" image in the meantime?
    return cover && cover.url() && cover;                              // 114
  },                                                                   //
                                                                       //
  absoluteUrl: function () {                                           // 117
    var board = this.board();                                          // 118
    return FlowRouter.path('card', {                                   // 119
      boardId: board._id,                                              // 120
      slug: board.slug,                                                // 121
      cardId: this._id                                                 // 122
    });                                                                //
  },                                                                   //
                                                                       //
  rootUrl: function () {                                               // 126
    return Meteor.absoluteUrl(this.absoluteUrl().replace('/', ''));    // 127
  }                                                                    //
});                                                                    //
                                                                       //
Cards.mutations({                                                      // 131
  archive: function () {                                               // 132
    return { $set: { archived: true } };                               // 133
  },                                                                   //
                                                                       //
  restore: function () {                                               // 136
    return { $set: { archived: false } };                              // 137
  },                                                                   //
                                                                       //
  setTitle: function (title) {                                         // 140
    return { $set: { title: title } };                                 // 141
  },                                                                   //
                                                                       //
  setDescription: function (description) {                             // 144
    return { $set: { description: description } };                     // 145
  },                                                                   //
                                                                       //
  move: function (listId, sortIndex) {                                 // 148
    var mutatedFields = { listId: listId };                            // 149
    if (sortIndex) {                                                   // 150
      mutatedFields.sort = sortIndex;                                  // 151
    }                                                                  //
    return { $set: mutatedFields };                                    // 153
  },                                                                   //
                                                                       //
  addLabel: function (labelId) {                                       // 156
    return { $addToSet: { labelIds: labelId } };                       // 157
  },                                                                   //
                                                                       //
  removeLabel: function (labelId) {                                    // 160
    return { $pull: { labelIds: labelId } };                           // 161
  },                                                                   //
                                                                       //
  toggleLabel: function (labelId) {                                    // 164
    if (this.labelIds && this.labelIds.indexOf(labelId) > -1) {        // 165
      return this.removeLabel(labelId);                                // 166
    } else {                                                           //
      return this.addLabel(labelId);                                   // 168
    }                                                                  //
  },                                                                   //
                                                                       //
  assignMember: function (memberId) {                                  // 172
    return { $addToSet: { members: memberId } };                       // 173
  },                                                                   //
                                                                       //
  unassignMember: function (memberId) {                                // 176
    return { $pull: { members: memberId } };                           // 177
  },                                                                   //
                                                                       //
  toggleMember: function (memberId) {                                  // 180
    if (this.members && this.members.indexOf(memberId) > -1) {         // 181
      return this.unassignMember(memberId);                            // 182
    } else {                                                           //
      return this.assignMember(memberId);                              // 184
    }                                                                  //
  },                                                                   //
                                                                       //
  setCover: function (coverId) {                                       // 188
    return { $set: { coverId: coverId } };                             // 189
  },                                                                   //
                                                                       //
  unsetCover: function () {                                            // 192
    return { $unset: { coverId: '' } };                                // 193
  }                                                                    //
});                                                                    //
                                                                       //
Cards.before.insert(function (userId, doc) {                           // 197
  doc.createdAt = new Date();                                          // 198
  doc.dateLastActivity = new Date();                                   // 199
  if (!doc.hasOwnProperty('archived')) {                               // 200
    doc.archived = false;                                              // 201
  }                                                                    //
  if (!doc.userId) {                                                   // 203
    doc.userId = userId;                                               // 204
  }                                                                    //
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 208
  Cards.after.insert(function (userId, doc) {                          // 209
    Activities.insert({                                                // 210
      userId: userId,                                                  // 211
      activityType: 'createCard',                                      // 212
      boardId: doc.boardId,                                            // 213
      listId: doc.listId,                                              // 214
      cardId: doc._id                                                  // 215
    });                                                                //
  });                                                                  //
                                                                       //
  // New activity for card (un)archivage                               //
  Cards.after.update(function (userId, doc, fieldNames) {              // 220
    if (_.contains(fieldNames, 'archived')) {                          // 221
      if (doc.archived) {                                              // 222
        Activities.insert({                                            // 223
          userId: userId,                                              // 224
          activityType: 'archivedCard',                                // 225
          boardId: doc.boardId,                                        // 226
          listId: doc.listId,                                          // 227
          cardId: doc._id                                              // 228
        });                                                            //
      } else {                                                         //
        Activities.insert({                                            // 231
          userId: userId,                                              // 232
          activityType: 'restoredCard',                                // 233
          boardId: doc.boardId,                                        // 234
          listId: doc.listId,                                          // 235
          cardId: doc._id                                              // 236
        });                                                            //
      }                                                                //
    }                                                                  //
  });                                                                  //
                                                                       //
  // New activity for card moves                                       //
  Cards.after.update(function (userId, doc, fieldNames) {              // 243
    var oldListId = this.previous.listId;                              // 244
    if (_.contains(fieldNames, 'listId') && doc.listId !== oldListId) {
      Activities.insert({                                              // 246
        userId: userId,                                                // 247
        oldListId: oldListId,                                          // 248
        activityType: 'moveCard',                                      // 249
        listId: doc.listId,                                            // 250
        boardId: doc.boardId,                                          // 251
        cardId: doc._id                                                // 252
      });                                                              //
    }                                                                  //
  });                                                                  //
                                                                       //
  // Add a new activity if we add or remove a member to the card       //
  Cards.before.update(function (userId, doc, fieldNames, modifier) {   // 258
    if (!_.contains(fieldNames, 'members')) return;                    // 259
    var memberId = undefined;                                          // 261
    // Say hello to the new member                                     //
    if (modifier.$addToSet && modifier.$addToSet.members) {            // 263
      memberId = modifier.$addToSet.members;                           // 264
      if (!_.contains(doc.members, memberId)) {                        // 265
        Activities.insert({                                            // 266
          userId: userId,                                              // 267
          memberId: memberId,                                          // 268
          activityType: 'joinMember',                                  // 269
          boardId: doc.boardId,                                        // 270
          cardId: doc._id                                              // 271
        });                                                            //
      }                                                                //
    }                                                                  //
                                                                       //
    // Say goodbye to the former member                                //
    if (modifier.$pull && modifier.$pull.members) {                    // 277
      memberId = modifier.$pull.members;                               // 278
      Activities.insert({                                              // 279
        userId: userId,                                                // 280
        memberId: memberId,                                            // 281
        activityType: 'unjoinMember',                                  // 282
        boardId: doc.boardId,                                          // 283
        cardId: doc._id                                                // 284
      });                                                              //
    }                                                                  //
  });                                                                  //
                                                                       //
  // Remove all activities associated with a card if we remove the card
  Cards.after.remove(function (userId, doc) {                          // 290
    Activities.remove({                                                // 291
      cardId: doc._id                                                  // 292
    });                                                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=cards.js.map
