(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// packages/idmontie_migrations/migrations.js                                          //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
/**                                                                                    // 1
 * Meteor Migration                                                                    // 2
 *                                                                                     // 3
 * Simple database migrations for meteor                                               // 4
 *                                                                                     // 5
 * @author idmontie                                                                    // 6
 */                                                                                    // 7
                                                                                       // 8
/* global console */                                                                   // 9
                                                                                       // 10
if ( Meteor.isServer ) {                                                               // 11
  var _$ = this;                                                                       // 12
                                                                                       // 13
  // =================                                                                 // 14
  // Meteor Migrations                                                                 // 15
  // =================                                                                 // 16
                                                                                       // 17
  this.Migrations = {                                                                  // 18
    /**                                                                                // 19
     * Meteor collection to store data in                                              // 20
     * TODO settings should dictate what db to use.                                    // 21
     */                                                                                // 22
    warehouse : new Meteor.Collection( 'meteor-migrations' ),                          // 23
    /**                                                                                // 24
     * Add a migration.  Will run the given migration once and only                    // 25
     * once, even when the app is restarted.                                           // 26
     *                                                                                 // 27
     * Returns true if a migration of the same name is not already added.              // 28
     * Returns false if otherwise.                                                     // 29
     *                                                                                 // 30
     * Migration names should be globally unique.                                      // 31
     *                                                                                 // 32
     * The order number is an optional parameter that sets what                        // 33
     * order the migrations should be run in. Migrations are run                       // 34
     * from smallest order number to largest order number.  If an                      // 35
     * order number is not provided, the largest order number + 10                     // 36
     * is used.                                                                        // 37
     *                                                                                 // 38
     * @param String name Name of the migration                                        // 39
     * @param Function migrationCallback The function to run once and only once        // 40
     * @param Number order Optional order number                                       // 41
     * @return boolean                                                                 // 42
     */                                                                                // 43
    add : function ( name, migrationCallback, rollbackCallback, order ) {              // 44
      'use strict';                                                                    // 45
                                                                                       // 46
      // If we are called with less than 4 arguments, than assume                      // 47
      // that we are being called with the following signature:                        // 48
      // ( name, migrationCallback, order )                                            // 49
      if ( arguments.length < 4 ) {                                                    // 50
        order = rollbackCallback;                                                      // 51
        rollbackCallback = null;                                                       // 52
      }                                                                                // 53
                                                                                       // 54
      var found = false                                                                // 55
                                                                                       // 56
      for ( var i = 0; i < _$.Migrations.migrations.length; i++ ) {                    // 57
        if ( name == _$.Migrations.migrations[i].name ) {                              // 58
          found = true                                                                 // 59
          break                                                                        // 60
        }                                                                              // 61
      }                                                                                // 62
                                                                                       // 63
      if ( ! found ) {                                                                 // 64
        if ( order == null ) {                                                         // 65
          order = _$.Migrations.largestOrderNumber + 10                                // 66
          _$.Migrations.largestOrderNumber = order                                     // 67
        } else if ( order > _$.Migrations.largestOrderNumber ) {                       // 68
          _$.Migrations.largestOrderNumber = order                                     // 69
        }                                                                              // 70
                                                                                       // 71
        _$.Migrations.migrations.push( {                                               // 72
          migrationCallback: migrationCallback,                                        // 73
          rollbackCallback: rollbackCallback,                                          // 74
          name: name,                                                                  // 75
          order: order                                                                 // 76
        } )                                                                            // 77
                                                                                       // 78
        return true                                                                    // 79
      } else {                                                                         // 80
        return false                                                                   // 81
      }                                                                                // 82
    },                                                                                 // 83
    /**                                                                                // 84
     * Removes the migration from the current queue.                                   // 85
     * This does NOT remove the migration from the collection of                       // 86
     * previously run migrations.                                                      // 87
     *                                                                                 // 88
     * To remove a migration to allow it to rerun, use removeFromDatabase.             // 89
     *                                                                                 // 90
     * @param String name Name of the migration                                        // 91
     */                                                                                // 92
    remove : function ( name ) {                                                       // 93
      'use strict';                                                                    // 94
                                                                                       // 95
      for ( var i = 0; i < _$.Migrations.migrations.length; i++ ) {                    // 96
        if ( _$.Migrations.migrations[i].name == name ) {                              // 97
          delete _$.Migrations.migrations[i];                                          // 98
        }                                                                              // 99
      }                                                                                // 100
    },                                                                                 // 101
    /**                                                                                // 102
     * Removes the migration from the database, so that it can be run again.           // 103
     *                                                                                 // 104
     * @param String name Name of the migration                                        // 105
     */                                                                                // 106
    removeFromDatabase : function ( name ) {                                           // 107
      'use strict';                                                                    // 108
                                                                                       // 109
      // TODO settings should dictate what db to use                                   // 110
      _$.Migrations.warehouse.remove( {                                                // 111
        name : name                                                                    // 112
      } )                                                                              // 113
    },                                                                                 // 114
    /**                                                                                // 115
     * Changes which function to run when the migration is performed.                  // 116
     *                                                                                 // 117
     * If the migration with the given name has already been run, this will            // 118
     * NOT force a re-run of the migration.  This is only available to override        // 119
     * which migration to run.                                                         // 120
     *                                                                                 // 121
     * @param String name Name of the migration                                        // 122
     * @param Function newMigrationCallback The new function to run once and only once
     */                                                                                // 124
    update : function ( name, newMigrationCallback, order ) {                          // 125
      'use strict';                                                                    // 126
                                                                                       // 127
      for ( var i = 0; i < _$.Migrations.migrations.length; i++ ) {                    // 128
        if ( name == _$.Migrations.migrations[i].name ) {                              // 129
          if ( order == null ) {                                                       // 130
            order = _$.Migrations.migrations[i].order                                  // 131
          } else if ( order > _$.Migrations.largestOrderNumber ) {                     // 132
            _$.Migrations.largestOrderNumber = order                                   // 133
          }                                                                            // 134
        }                                                                              // 135
                                                                                       // 136
        _$.Migrations.migrations[i] = {                                                // 137
          migrationCallback: newMigrationCallback,                                     // 138
          name: name,                                                                  // 139
          order: order                                                                 // 140
        }                                                                              // 141
      }                                                                                // 142
    },                                                                                 // 143
    /**                                                                                // 144
     * Rollback a given migration. The migration will be rerun on start up since       // 145
     * this also removes the migration from the database.                              // 146
     *                                                                                 // 147
     * @param String name The name of the migration to rollback                        // 148
     */                                                                                // 149
    rollback : function ( name ) {                                                     // 150
      for ( var i = 0; i < _$.Migrations.migrations.length; i++ ) {                    // 151
        if ( _$.Migrations.migrations[i].name == name ) {                              // 152
                                                                                       // 153
          if ( _$.Migrations.migrations[i].rollbackCallback ) {                        // 154
            _$.Migrations.migrations[i].rollbackCallback();                            // 155
          }                                                                            // 156
        }                                                                              // 157
      }                                                                                // 158
                                                                                       // 159
      _$.Migrations.removeFromDatabase( name );                                        // 160
    },                                                                                 // 161
    /**                                                                                // 162
     * Enables console logs for already run migrations.                                // 163
     *                                                                                 // 164
     * @type boolean                                                                   // 165
     */                                                                                // 166
    verbose : false,                                                                   // 167
    /**                                                                                // 168
     * Array of migration objects.  Do not use directly.                               // 169
     *                                                                                 // 170
     * Initially empty, no migrations to run                                           // 171
     *                                                                                 // 172
     * Object structure:                                                               // 173
     *                                                                                 // 174
     * - orderNumber                                                                   // 175
     * - name                                                                          // 176
     * - migrationCallback                                                             // 177
     *                                                                                 // 178
     * @type Array                                                                     // 179
     */                                                                                // 180
    migrations : [],                                                                   // 181
    /**                                                                                // 182
     * Stores the largest order number                                                 // 183
     *                                                                                 // 184
     * @type Number                                                                    // 185
     */                                                                                // 186
    largestOrderNumber : 0                                                             // 187
  };                                                                                   // 188
                                                                                       // 189
  // ==============                                                                    // 190
  // Meteor Startup                                                                    // 191
  // ==============                                                                    // 192
                                                                                       // 193
  Meteor.startup( function () {                                                        // 194
    'use strict';                                                                      // 195
                                                                                       // 196
    /*                                                                                 // 197
     * Migrations are unsorted.  Sort them and do them in order of                     // 198
     * smallest to largest order number                                                // 199
     */                                                                                // 200
                                                                                       // 201
    _$.Migrations.migrations.sort( function ( a, b ) {                                 // 202
      if ( a.order < b.order ) {                                                       // 203
        return -1;                                                                     // 204
      } else if ( a.order > b.order ) {                                                // 205
        return 1;                                                                      // 206
      } else {                                                                         // 207
        return 0;                                                                      // 208
      }                                                                                // 209
    } )                                                                                // 210
                                                                                       // 211
                                                                                       // 212
    for ( var i = 0; i < _$.Migrations.migrations.length; i++ ) {                      // 213
      var migration = _$.Migrations.migrations[i]                                      // 214
      // Do the migration                                                              // 215
      var pastMigration = _$.Migrations.warehouse.findOne( {                           // 216
        name : migration.name                                                          // 217
      } )                                                                              // 218
                                                                                       // 219
      if ( ! pastMigration ) {                                                         // 220
        console.log ( '> Starting ' + migration.name + ' migration.' )                 // 221
                                                                                       // 222
        migration.migrationCallback()                                                  // 223
                                                                                       // 224
        _$.Migrations.warehouse.insert( {                                              // 225
          name : migration.name                                                        // 226
        } )                                                                            // 227
                                                                                       // 228
        console.log ( '> Finishing ' + migration.name + ' migration.' )                // 229
      } else {                                                                         // 230
        if ( _$.verbose ) {                                                            // 231
          console.log( '> Skipping ' + migration.name + '.' )                          // 232
        }                                                                              // 233
      }                                                                                // 234
    }                                                                                  // 235
  } )                                                                                  // 236
}                                                                                      // 237
                                                                                       // 238
/////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['idmontie:migrations'] = {};

})();

//# sourceMappingURL=idmontie_migrations.js.map
