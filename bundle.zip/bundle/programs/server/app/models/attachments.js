(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/attachments.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Attachments = new FS.Collection('attachments', { // eslint-disable-line meteor/collections
  stores: [                                                            // 2
                                                                       //
  // XXX Add a new store for cover thumbnails so we don't load big images in
  // the general board view                                            //
  new FS.Store.GridFS('attachments')]                                  // 6
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 10
  Attachments.allow({                                                  // 11
    insert: function (userId, doc) {                                   // 12
      return allowIsBoardMember(userId, Boards.findOne(doc.boardId));  // 13
    },                                                                 //
    update: function (userId, doc) {                                   // 15
      return allowIsBoardMember(userId, Boards.findOne(doc.boardId));  // 16
    },                                                                 //
    remove: function (userId, doc) {                                   // 18
      return allowIsBoardMember(userId, Boards.findOne(doc.boardId));  // 19
    },                                                                 //
    // We authorize the attachment download either:                    //
    // - if the board is public, everyone (even unconnected) can download it
    // - if the board is private, only board members can download it   //
    //                                                                 //
    // XXX We have a bug with the `userId` verification:               //
    //                                                                 //
    //   https://github.com/CollectionFS/Meteor-CollectionFS/issues/449
    //                                                                 //
    download: function (userId, doc) {                                 // 29
      var query = {                                                    // 30
        $or: [{ 'members.userId': userId }, { permission: 'public' }]  // 31
      };                                                               //
      return Boolean(Boards.findOne(doc.boardId, query));              // 36
    },                                                                 //
                                                                       //
    fetch: ['boardId']                                                 // 39
  });                                                                  //
}                                                                      //
                                                                       //
// XXX Enforce a schema for the Attachments CollectionFS               //
                                                                       //
Attachments.files.before.insert(function (userId, doc) {               // 45
  var file = new FS.File(doc);                                         // 46
  doc.userId = userId;                                                 // 47
                                                                       //
  // If the uploaded document is not an image we need to enforce browser
  // download instead of execution. This is particularly important for HTML
  // files that the browser will just execute if we don't serve them with the
  // appropriate `application/octet-stream` MIME header which can lead to user
  // data leaks. I imagine other formats (like PDF) can also be attack vectors.
  // See https://github.com/libreboard/libreboard/issues/99            //
  // XXX Should we use `beforeWrite` option of CollectionFS instead of
  // collection-hooks?                                                 //
  if (!file.isImage()) {                                               // 57
    file.original.type = 'application/octet-stream';                   // 58
  }                                                                    //
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 62
  Attachments.files.after.insert(function (userId, doc) {              // 63
    Activities.insert({                                                // 64
      userId: userId,                                                  // 65
      type: 'card',                                                    // 66
      activityType: 'addAttachment',                                   // 67
      attachmentId: doc._id,                                           // 68
      boardId: doc.boardId,                                            // 69
      cardId: doc.cardId                                               // 70
    });                                                                //
  });                                                                  //
                                                                       //
  Attachments.files.after.remove(function (userId, doc) {              // 74
    Activities.remove({                                                // 75
      attachmentId: doc._id                                            // 76
    });                                                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=attachments.js.map
