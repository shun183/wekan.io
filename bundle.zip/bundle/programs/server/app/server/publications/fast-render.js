(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/fast-render.js                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
FastRender.onAllRoutes(function () {                                   // 1
  this.subscribe('boards');                                            // 2
});                                                                    //
                                                                       //
FastRender.route('/b/:id/:slug', function (_ref) {                     // 5
  var id = _ref.id;                                                    //
                                                                       //
  this.subscribe('board', id);                                         // 6
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fast-render.js.map
