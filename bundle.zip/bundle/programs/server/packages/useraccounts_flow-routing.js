(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var check = Package.check.check;
var Match = Package.check.Match;
var FlowRouter = Package['kadira:flow-router'].FlowRouter;
var _ = Package.underscore._;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var T9n = Package['softwarerero:accounts-t9n'].T9n;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/useraccounts_flow-routing/lib/core.js                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/* global                                                                                                            // 1
  AccountsTemplates: false,                                                                                          // 2
  BlazeLayout: false,                                                                                                // 3
  FlowRouter: false                                                                                                  // 4
*/                                                                                                                   // 5
'use strict';                                                                                                        // 6
                                                                                                                     // 7
// ---------------------------------------------------------------------------------                                 // 8
                                                                                                                     // 9
// Patterns for methods" parameters                                                                                  // 10
                                                                                                                     // 11
// ---------------------------------------------------------------------------------                                 // 12
                                                                                                                     // 13
// Add new configuration options                                                                                     // 14
_.extend(AccountsTemplates.CONFIG_PAT, {                                                                             // 15
  defaultLayoutType: Match.Optional(String),                                                                         // 16
  defaultLayout: Match.Optional(Match.OneOf(String, Match.Where(_.isFunction))),                                     // 17
  defaultTemplate: Match.Optional(String),                                                                           // 18
  defaultLayoutRegions: Match.Optional(Object),                                                                      // 19
  defaultContentRegion: Match.Optional(String),                                                                      // 20
  renderLayout: Match.Optional(Object),                                                                              // 21
  contentRange: Match.Optional(String),                                                                              // 22
});                                                                                                                  // 23
                                                                                                                     // 24
// Route configuration pattern to be checked with check                                                              // 25
var ROUTE_PAT = {                                                                                                    // 26
  name: Match.Optional(String),                                                                                      // 27
  path: Match.Optional(String),                                                                                      // 28
  template: Match.Optional(String),                                                                                  // 29
  layoutTemplate: Match.Optional(String),                                                                            // 30
  renderLayout: Match.Optional(Object),                                                                              // 31
  contentRange: Match.Optional(String),                                                                              // 32
  redirect: Match.Optional(Match.OneOf(String, Match.Where(_.isFunction))),                                          // 33
};                                                                                                                   // 34
                                                                                                                     // 35
/*                                                                                                                   // 36
  Routes configuration can be done by calling AccountsTemplates.configureRoute with the route name and the           // 37
  following options in a separate object. E.g. AccountsTemplates.configureRoute("gingIn", option);                   // 38
    name:           String (optional). A unique route"s name to be passed to iron-router                             // 39
    path:           String (optional). A unique route"s path to be passed to iron-router                             // 40
    template:       String (optional). The name of the template to be rendered                                       // 41
    layoutTemplate: String (optional). The name of the layout to be used                                             // 42
    redirect:       String (optional). The name of the route (or its path) where to redirect after form submit       // 43
*/                                                                                                                   // 44
                                                                                                                     // 45
                                                                                                                     // 46
// Allowed routes along with theirs default configuration values                                                     // 47
AccountsTemplates.ROUTE_DEFAULT = {                                                                                  // 48
  changePwd:      { name: "atChangePwd",      path: "/change-password"},                                             // 49
  enrollAccount:  { name: "atEnrollAccount",  path: "/enroll-account"},                                              // 50
  ensureSignedIn: { name: "atEnsureSignedIn", path: null},                                                           // 51
  forgotPwd:      { name: "atForgotPwd",      path: "/forgot-password"},                                             // 52
  resetPwd:       { name: "atResetPwd",       path: "/reset-password"},                                              // 53
  signIn:         { name: "atSignIn",         path: "/sign-in"},                                                     // 54
  signUp:         { name: "atSignUp",         path: "/sign-up"},                                                     // 55
  verifyEmail:    { name: "atVerifyEmail",    path: "/verify-email"},                                                // 56
  resendVerificationEmail: { name: "atResendVerificationEmail", path: "/send-again"}                                 // 57
};                                                                                                                   // 58
                                                                                                                     // 59
// Current configuration values                                                                                      // 60
AccountsTemplates.options.defaultLayoutRegions = {};                                                                 // 61
// Redirects                                                                                                         // 62
AccountsTemplates.options.homeRoutePath = "/";                                                                       // 63
AccountsTemplates.options.redirectTimeout = 2000; // 2 seconds                                                       // 64
                                                                                                                     // 65
// Known routes used to filter out previous path for redirects...                                                    // 66
AccountsTemplates.knownRoutes = [];                                                                                  // 67
                                                                                                                     // 68
// Configured routes                                                                                                 // 69
AccountsTemplates.routes = {};                                                                                       // 70
                                                                                                                     // 71
AccountsTemplates.configureRoute = function(route, options) {                                                        // 72
  check(route, String);                                                                                              // 73
  check(options, Match.OneOf(undefined, Match.ObjectIncluding(ROUTE_PAT)));                                          // 74
  options = _.clone(options);                                                                                        // 75
  // Route Configuration can be done only before initialization                                                      // 76
  if (this._initialized) {                                                                                           // 77
    throw new Error("Route Configuration can be done only before AccountsTemplates.init!");                          // 78
  }                                                                                                                  // 79
  // Only allowed routes can be configured                                                                           // 80
  if (!(route in this.ROUTE_DEFAULT)) {                                                                              // 81
    throw new Error("Unknown Route!");                                                                               // 82
  }                                                                                                                  // 83
  // Allow route configuration only once                                                                             // 84
  if (route in this.routes) {                                                                                        // 85
    throw new Error("Route already configured!");                                                                    // 86
  }                                                                                                                  // 87
                                                                                                                     // 88
  // Possibly adds a initial / to the provided path                                                                  // 89
  if (options && options.path && options.path[0] !== "/") {                                                          // 90
    options.path = "/" + options.path;                                                                               // 91
  }                                                                                                                  // 92
                                                                                                                     // 93
  // Updates the current configuration                                                                               // 94
  options = _.defaults(options || {}, this.ROUTE_DEFAULT[route]);                                                    // 95
                                                                                                                     // 96
  // Store route options                                                                                             // 97
  this.routes[route] = options;                                                                                      // 98
                                                                                                                     // 99
  // Known routes are used to filter out previous path for redirects...                                              // 100
  AccountsTemplates.knownRoutes.push(options.name);                                                                  // 101
                                                                                                                     // 102
  if (Meteor.isServer) {                                                                                             // 103
    // Configures "reset password" email link                                                                        // 104
    if (route === "resetPwd") {                                                                                      // 105
      var resetPwdPath = options.path.substr(1);                                                                     // 106
      Accounts.urls.resetPassword = function(token) {                                                                // 107
        return Meteor.absoluteUrl(resetPwdPath + "/" + token);                                                       // 108
      };                                                                                                             // 109
    }                                                                                                                // 110
    // Configures "enroll account" email link                                                                        // 111
    if (route === "enrollAccount") {                                                                                 // 112
      var enrollAccountPath = options.path.substr(1);                                                                // 113
      Accounts.urls.enrollAccount = function(token) {                                                                // 114
        return Meteor.absoluteUrl(enrollAccountPath + "/" + token);                                                  // 115
      };                                                                                                             // 116
    }                                                                                                                // 117
    // Configures "verify email" email link                                                                          // 118
    if (route === "verifyEmail") {                                                                                   // 119
      var verifyEmailPath = options.path.substr(1);                                                                  // 120
      Accounts.urls.verifyEmail = function(token) {                                                                  // 121
        return Meteor.absoluteUrl(verifyEmailPath + "/" + token);                                                    // 122
      };                                                                                                             // 123
    }                                                                                                                // 124
  }                                                                                                                  // 125
                                                                                                                     // 126
  if (route === "ensureSignedIn") {                                                                                  // 127
    return;                                                                                                          // 128
  }                                                                                                                  // 129
  if (route === "changePwd" && !AccountsTemplates.options.enablePasswordChange) {                                    // 130
    throw new Error("changePwd route configured but enablePasswordChange set to false!");                            // 131
  }                                                                                                                  // 132
  if (route === "forgotPwd" && !AccountsTemplates.options.showForgotPasswordLink) {                                  // 133
    throw new Error("forgotPwd route configured but showForgotPasswordLink set to false!");                          // 134
  }                                                                                                                  // 135
  if (route === "signUp" && AccountsTemplates.options.forbidClientAccountCreation) {                                 // 136
    throw new Error("signUp route configured but forbidClientAccountCreation set to true!");                         // 137
  }                                                                                                                  // 138
                                                                                                                     // 139
  // Use BlazeLayout by default                                                                                      // 140
  var defaultLayoutType = AccountsTemplates.options.defaultLayoutType || 'blaze';                                    // 141
  // fullPageAtForm template unless user specified a different site-wide default                                     // 142
  var defaultTemplate = AccountsTemplates.options.defaultTemplate || "fullPageAtForm";                               // 143
  // Determines the default layout to be used in case no specific one is                                             // 144
  // specified for single routes                                                                                     // 145
  var defaultLayout = AccountsTemplates.options.defaultLayout;                                                       // 146
  var defaultLayoutRegions = AccountsTemplates.options.defaultLayoutRegions;                                         // 147
  var defaultContentRegion = AccountsTemplates.options.defaultContentRegion;                                         // 148
                                                                                                                     // 149
  var name = options.name; // Default provided...                                                                    // 150
  var path = options.path; // Default provided...                                                                    // 151
  var layoutType = options.layoutType || defaultLayoutType;                                                          // 152
  var template = options.template || defaultTemplate;                                                                // 153
  var layoutTemplate = options.layoutTemplate || defaultLayout;                                                      // 154
  var contentRegion = options.contentRegion || defaultContentRegion;                                                 // 155
  var layoutRegions = _.clone(options.layoutRegions || defaultLayoutRegions || {});                                  // 156
                                                                                                                     // 157
  if (layoutType === "blaze") {                                                                                      // 158
                                                                                                                     // 159
    // Ensure that we have the required packages to render Blaze templates                                           // 160
                                                                                                                     // 161
    if (Package['kadira:blaze-layout']) {                                                                            // 162
      var BlazeLayout = Package['kadira:blaze-layout'].BlazeLayout;                                                  // 163
    } else {                                                                                                         // 164
      throw new Error("useraccounts:flow-routing requires that your project includes kadira:blaze-layout package.");
    }                                                                                                                // 166
                                                                                                                     // 167
    // Strings are assumed to be Blaze template names                                                                // 168
    layoutRegions[contentRegion] = template;                                                                         // 169
  }                                                                                                                  // 170
                                                                                                                     // 171
  if (layoutType === "blaze-to-react") {                                                                             // 172
                                                                                                                     // 173
    // Ensure that we have the required packages to render Blaze templates                                           // 174
    //                                                                                                               // 175
    // For now we need to render the main template using BlazeToReact                                                // 176
                                                                                                                     // 177
    if (Package['react-runtime']) {                                                                                  // 178
      var React = Package['react-runtime'].React;                                                                    // 179
    } else {                                                                                                         // 180
      throw new Error("layoutTemplate is a React element but React runtime package is not found");                   // 181
    }                                                                                                                // 182
                                                                                                                     // 183
    if (Package['kadira:react-layout']) {                                                                            // 184
      var ReactLayout = Package['kadira:react-layout'].ReactLayout;                                                  // 185
    } else {                                                                                                         // 186
      throw new Error("useraccounts:flow-routing requires that your project includes kadira:react-layout package.");
    }                                                                                                                // 188
                                                                                                                     // 189
    if (Package['gwendall:blaze-to-react']) {                                                                        // 190
      var BlazeToReact = Package['gwendall:blaze-to-react'].BlazeToReact;                                            // 191
    } else {                                                                                                         // 192
      throw new Error("useraccounts:flow-routing requires that your project includes the gwendall:blaze-to-react package.");
    }                                                                                                                // 194
                                                                                                                     // 195
    layoutRegions[contentRegion] = React.createElement(BlazeToReact, { blazeTemplate: template });                   // 196
                                                                                                                     // 197
  }                                                                                                                  // 198
                                                                                                                     // 199
  function doLayout() {                                                                                              // 200
    if (layoutType === "blaze-to-react") {                                                                           // 201
                                                                                                                     // 202
      // The layout template is a React Class.                                                                       // 203
      // We need to render using ReactLayout and BlazeToReact                                                        // 204
                                                                                                                     // 205
      ReactLayout.render(layoutTemplate, layoutRegions);                                                             // 206
    } else {                                                                                                         // 207
      // Render using BlazeLayout                                                                                    // 208
      BlazeLayout.render(layoutTemplate, layoutRegions);                                                             // 209
    }                                                                                                                // 210
  }                                                                                                                  // 211
                                                                                                                     // 212
  // Possibly adds token parameter                                                                                   // 213
  if (_.contains(["enrollAccount", "resetPwd", "verifyEmail"], route)) {                                             // 214
    path += "/:paramToken";                                                                                          // 215
    if (route === "verifyEmail") {                                                                                   // 216
      FlowRouter.route(path, {                                                                                       // 217
        name: name,                                                                                                  // 218
        triggersEnter: [                                                                                             // 219
          function() {                                                                                               // 220
            AccountsTemplates.setState(route);                                                                       // 221
            AccountsTemplates.setDisabled(true);                                                                     // 222
          }                                                                                                          // 223
        ],                                                                                                           // 224
        action: function(params) {                                                                                   // 225
          doLayout();                                                                                                // 226
                                                                                                                     // 227
          var token = params.paramToken;                                                                             // 228
          Accounts.verifyEmail(token, function(error) {                                                              // 229
            AccountsTemplates.setDisabled(false);                                                                    // 230
            AccountsTemplates.submitCallback(error, route, function() {                                              // 231
              AccountsTemplates.state.form.set("result", AccountsTemplates.texts.info.emailVerified);                // 232
            });                                                                                                      // 233
          });                                                                                                        // 234
        }                                                                                                            // 235
      });                                                                                                            // 236
    } else {                                                                                                         // 237
      FlowRouter.route(path, {                                                                                       // 238
        name: name,                                                                                                  // 239
        triggersEnter: [                                                                                             // 240
          function() {                                                                                               // 241
            AccountsTemplates.setState(route);                                                                       // 242
          }                                                                                                          // 243
        ],                                                                                                           // 244
        action: function(params) {                                                                                   // 245
          doLayout();                                                                                                // 246
        }                                                                                                            // 247
      });                                                                                                            // 248
    }                                                                                                                // 249
  } else {                                                                                                           // 250
    FlowRouter.route(path, {                                                                                         // 251
      name: name,                                                                                                    // 252
      triggersEnter: [                                                                                               // 253
        function() {                                                                                                 // 254
          var redirect = false;                                                                                      // 255
          if (route === 'changePwd') {                                                                               // 256
            if (!Meteor.loggingIn() && !Meteor.userId()) {                                                           // 257
              redirect = true;                                                                                       // 258
            }                                                                                                        // 259
          } else if (Meteor.userId()) {                                                                              // 260
            redirect = true;                                                                                         // 261
          }                                                                                                          // 262
          if (redirect) {                                                                                            // 263
            AccountsTemplates.postSubmitRedirect(route);                                                             // 264
          } else {                                                                                                   // 265
            AccountsTemplates.setState(route);                                                                       // 266
          }                                                                                                          // 267
        }                                                                                                            // 268
      ],                                                                                                             // 269
      action: function() {                                                                                           // 270
        doLayout();                                                                                                  // 271
      }                                                                                                              // 272
    });                                                                                                              // 273
  }                                                                                                                  // 274
};                                                                                                                   // 275
                                                                                                                     // 276
                                                                                                                     // 277
AccountsTemplates.getRouteName = function(route) {                                                                   // 278
  if (route in this.routes) {                                                                                        // 279
    return this.routes[route].name;                                                                                  // 280
  }                                                                                                                  // 281
  return null;                                                                                                       // 282
};                                                                                                                   // 283
                                                                                                                     // 284
AccountsTemplates.getRoutePath = function(route) {                                                                   // 285
  if (route in this.routes) {                                                                                        // 286
    return this.routes[route].path;                                                                                  // 287
  }                                                                                                                  // 288
  return "#";                                                                                                        // 289
};                                                                                                                   // 290
                                                                                                                     // 291
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['useraccounts:flow-routing'] = {};

})();

//# sourceMappingURL=useraccounts_flow-routing.js.map
