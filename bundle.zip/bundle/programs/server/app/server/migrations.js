(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/migrations.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Anytime you change the schema of one of the collection in a non-backward
// compatible way you have to write a migration in this file using the following
// API:                                                                //
//                                                                     //
//   Migrations.add(name, migrationCallback, optionalOrder);           //
                                                                       //
// Note that we have extra migrations defined in `sandstorm.js` that are
// exclusive to Sandstorm and shouldn’t be executed in the general case.
// XXX I guess if we had ES6 modules we could                          //
// `import { isSandstorm } from sandstorm.js` and define the migration here as
// well, but for now I want to avoid definied too many globals.        //
                                                                       //
// In the context of migration functions we don't want to validate database
// mutation queries against the current (ie, latest) collection schema. Doing
// that would work at the time we write the migration but would break in the
// future when we'll update again the concerned collection schema.     //
//                                                                     //
// To prevent this bug we always have to disable the schema validation and
// argument transformations. We generally use the shorthandlers defined below.
var noValidate = {                                                     // 20
  validate: false,                                                     // 21
  filter: false,                                                       // 22
  autoConvert: false,                                                  // 23
  removeEmptyStrings: false,                                           // 24
  getAutoValues: false                                                 // 25
};                                                                     //
var noValidateMulti = babelHelpers._extends({}, noValidate, { multi: true });
                                                                       //
Migrations.add('board-background-color', function () {                 // 29
  var defaultColor = '#16A085';                                        // 30
  Boards.update({                                                      // 31
    background: {                                                      // 32
      $exists: false                                                   // 33
    }                                                                  //
  }, {                                                                 //
    $set: {                                                            // 36
      background: {                                                    // 37
        type: 'color',                                                 // 38
        color: defaultColor                                            // 39
      }                                                                //
    }                                                                  //
  }, noValidateMulti);                                                 //
});                                                                    //
                                                                       //
Migrations.add('lowercase-board-permission', function () {             // 45
  ['Public', 'Private'].forEach(function (permission) {                // 46
    Boards.update({ permission: permission }, { $set: { permission: permission.toLowerCase() } }, noValidateMulti);
  });                                                                  //
});                                                                    //
                                                                       //
// Security migration: see https://github.com/wekan/wekan/issues/99    //
Migrations.add('change-attachments-type-for-non-images', function () {
  var newTypeForNonImage = 'application/octet-stream';                 // 57
  Attachments.find().forEach(function (file) {                         // 58
    if (!file.isImage()) {                                             // 59
      Attachments.update(file._id, {                                   // 60
        $set: {                                                        // 61
          'original.type': newTypeForNonImage,                         // 62
          'copies.attachments.type': newTypeForNonImage                // 63
        }                                                              //
      }, noValidate);                                                  //
    }                                                                  //
  });                                                                  //
});                                                                    //
                                                                       //
Migrations.add('card-covers', function () {                            // 70
  Cards.find().forEach(function (card) {                               // 71
    var cover = Attachments.findOne({ cardId: card._id, cover: true });
    if (cover) {                                                       // 73
      Cards.update(card._id, { $set: { coverId: cover._id } }, noValidate);
    }                                                                  //
  });                                                                  //
  Attachments.update({}, { $unset: { cover: '' } }, noValidateMulti);  // 77
});                                                                    //
                                                                       //
Migrations.add('use-css-class-for-boards-colors', function () {        // 80
  var associationTable = {                                             // 81
    '#27AE60': 'nephritis',                                            // 82
    '#C0392B': 'pomegranate',                                          // 83
    '#2980B9': 'belize',                                               // 84
    '#8E44AD': 'wisteria',                                             // 85
    '#2C3E50': 'midnight',                                             // 86
    '#E67E22': 'pumpkin'                                               // 87
  };                                                                   //
  Boards.find().forEach(function (board) {                             // 89
    var oldBoardColor = board.background.color;                        // 90
    var newBoardColor = associationTable[oldBoardColor];               // 91
    Boards.update(board._id, {                                         // 92
      $set: { color: newBoardColor },                                  // 93
      $unset: { background: '' }                                       // 94
    }, noValidate);                                                    //
  });                                                                  //
});                                                                    //
                                                                       //
Migrations.add('denormalize-star-number-per-board', function () {      // 99
  Boards.find().forEach(function (board) {                             // 100
    var nStars = Users.find({ 'profile.starredBoards': board._id }).count();
    Boards.update(board._id, { $set: { stars: nStars } }, noValidate);
  });                                                                  //
});                                                                    //
                                                                       //
// We want to keep a trace of former members so we can efficiently publish their
// infos in the general board publication.                             //
Migrations.add('add-member-isactive-field', function () {              // 108
  Boards.find({}, { fields: { members: 1 } }).forEach(function (board) {
    var allUsersWithSomeActivity = _.chain(Activities.find({ boardId: board._id }, { fields: { userId: 1 } }).fetch()).pluck('userId').uniq().value();
    var currentUsers = _.pluck(board.members, 'userId');               // 115
    var formerUsers = _.difference(allUsersWithSomeActivity, currentUsers);
                                                                       //
    var newMemberSet = [];                                             // 118
    board.members.forEach(function (member) {                          // 119
      member.isActive = true;                                          // 120
      newMemberSet.push(member);                                       // 121
    });                                                                //
    formerUsers.forEach(function (userId) {                            // 123
      newMemberSet.push({                                              // 124
        userId: userId,                                                // 125
        isAdmin: false,                                                // 126
        isActive: false                                                // 127
      });                                                              //
    });                                                                //
    Boards.update(board._id, { $set: { members: newMemberSet } }, noValidate);
  });                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=migrations.js.map
