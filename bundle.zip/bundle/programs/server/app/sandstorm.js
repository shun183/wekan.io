(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// sandstorm.js                                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Sandstorm context is detected using the METEOR_SETTINGS environment variable
// in the package definition.                                          //
var isSandstorm = Meteor.settings && Meteor.settings['public'] && Meteor.settings['public'].sandstorm;
                                                                       //
// In sandstorm we only have one board per sandstorm instance. Since we want to
// keep most of our code unchanged, we simply hard-code a board `_id` and
// redirect the user to this particular board.                         //
var sandstormBoard = {                                                 // 9
  _id: 'sandstorm',                                                    // 10
                                                                       //
  // XXX Should be shared with the grain instance name.                //
  title: 'Wekan',                                                      // 13
  slug: 'libreboard',                                                  // 14
  members: [],                                                         // 15
                                                                       //
  // Board access security is handled by sandstorm, so in our point of view we
  // can alway assume that the board is public (unauthorized users won't be able
  // to access it anyway).                                             //
  permission: 'public'                                                 // 20
};                                                                     //
                                                                       //
if (isSandstorm && Meteor.isServer) {                                  // 23
  function updateUserPermissions(userId, permissions) {                // 24
    var _$set;                                                         //
                                                                       //
    var isActive = permissions.indexOf('participate') > -1;            // 25
    var isAdmin = permissions.indexOf('configure') > -1;               // 26
    var permissionDoc = { userId: userId, isActive: isActive, isAdmin: isAdmin };
                                                                       //
    var boardMembers = Boards.findOne(sandstormBoard._id).members;     // 29
    var memberIndex = _.pluck(boardMembers, 'userId').indexOf(userId);
                                                                       //
    var modifier = undefined;                                          // 32
    if (memberIndex > -1) modifier = { $set: (_$set = {}, _$set['members.' + memberIndex] = permissionDoc, _$set) };else if (!isActive) modifier = {};else modifier = { $push: { members: permissionDoc } };
                                                                       //
    Boards.update(sandstormBoard._id, modifier);                       // 40
  }                                                                    //
                                                                       //
  Picker.route('/', function (params, req, res) {                      // 43
    // Redirect the user to the hard-coded board. On the first launch the user
    // will be redirected to the board before its creation. But that's not a
    // problem thanks to the reactive board publication. We used to do this
    // redirection on the client side but that was sometimes visible on loading,
    // and the home page was accessible by pressing the back button of the
    // browser, a server-side redirection solves both of these issues.
    //                                                                 //
    // XXX Maybe the sandstorm http-bridge could provide some kind of "home URL"
    // in the manifest?                                                //
    var base = req.headers['x-sandstorm-base-path'];                   // 53
    // XXX If this routing scheme changes, this will break. We should generate
    // the location URL using the router, but at the time of writing, the
    // it is only accessible on the client.                            //
    var boardPath = '/b/' + sandstormBoard._id + '/' + sandstormBoard.slug;
                                                                       //
    res.writeHead(301, {                                               // 59
      Location: base + boardPath                                       // 60
    });                                                                //
    res.end();                                                         // 62
                                                                       //
    // `accounts-sandstorm` populate the Users collection when new users
    // accesses the document, but in case a already known user comes back, we
    // need to update his associated document to match the request HTTP headers
    // informations.                                                   //
    // XXX We need to update this document even if the initial route is not `/`.
    // Unfortuanlty I wasn't able to make the Webapp.rawConnectHandlers solution
    // work.                                                           //
    var user = Users.findOne({                                         // 71
      'services.sandstorm.id': req.headers['x-sandstorm-user-id']      // 72
    });                                                                //
    if (user) {                                                        // 74
      // XXX At this point the user.services.sandstorm credentials haven't been
      // updated, which mean that the user will have to restart the application
      // a second time to see its updated name and avatar.             //
      Users.update(user._id, {                                         // 78
        $set: {                                                        // 79
          'profile.fullname': user.services.sandstorm.name,            // 80
          'profile.avatarUrl': user.services.sandstorm.picture         // 81
        }                                                              //
      });                                                              //
      updateUserPermissions(user._id, user.services.sandstorm.permissions);
    }                                                                  //
  });                                                                  //
                                                                       //
  // On the first launch of the instance a user is automatically created thanks
  // to the `accounts-sandstorm` package. After its creation we insert the
  // unique board document. Note that when the `Users.after.insert` hook is
  // called, the user is inserted into the database but not connected. So
  // despite the appearances `userId` is null in this block.           //
  Users.after.insert(function (userId, doc) {                          // 93
    if (!Boards.findOne(sandstormBoard._id)) {                         // 94
      Boards.insert(sandstormBoard, { validate: false });              // 95
      Activities.update({ activityTypeId: sandstormBoard._id }, { $set: { userId: doc._id } });
    }                                                                  //
                                                                       //
    // We rely on username uniqueness for the user mention feature, but
    // Sandstorm doesn't enforce this property -- see #352. Our strategy to
    // generate unique usernames from the Sandstorm `preferredHandle` is to
    // append a number that we increment until we generate a username that no
    // one already uses (eg, 'max', 'max1', 'max2').                   //
    function generateUniqueUsername(username, appendNumber) {          // 107
      return username + String(appendNumber === 0 ? '' : appendNumber);
    }                                                                  //
                                                                       //
    var username = doc.services.sandstorm.preferredHandle;             // 111
    var appendNumber = 0;                                              // 112
    while (Users.findOne({                                             // 113
      _id: { $ne: doc._id },                                           // 114
      username: generateUniqueUsername(username, appendNumber)         // 115
    })) {                                                              //
      appendNumber += 1;                                               // 117
    }                                                                  //
                                                                       //
    Users.update(doc._id, {                                            // 120
      $set: {                                                          // 121
        username: generateUniqueUsername(username, appendNumber),      // 122
        'profile.fullname': doc.services.sandstorm.name,               // 123
        'profile.avatarUrl': doc.services.sandstorm.picture            // 124
      }                                                                //
    });                                                                //
                                                                       //
    updateUserPermissions(doc._id, doc.services.sandstorm.permissions);
  });                                                                  //
                                                                       //
  // LibreBoard v0.8 didn’t implement the Sandstorm sharing model and instead
  // kept the visibility setting (“public” or “private”) in the UI as does the
  // main Meteor application. We need to enforce “public” visibility as the
  // sharing is now handled by Sandstorm.                              //
  // See https://github.com/wekan/wekan/issues/346                     //
  Migrations.add('enforce-public-visibility-for-sandstorm', function () {
    Boards.update('sandstorm', { $set: { permission: 'public' } });    // 137
  });                                                                  //
}                                                                      //
                                                                       //
if (isSandstorm && Meteor.isClient) {                                  // 141
  (function () {                                                       //
    // Since the Sandstorm grain is displayed in an iframe of the Sandstorm shell,
    // we need to explicitly expose meta data like the page title or the URL path
    // so that they could appear in the browser window.                //
    // See https://docs.sandstorm.io/en/latest/developing/path/        //
    function updateSandstormMetaData(msg) {                            // 146
      return window.parent.postMessage(msg, '*');                      // 147
    }                                                                  //
                                                                       //
    FlowRouter.triggers.enter([function (_ref) {                       // 150
      var path = _ref.path;                                            //
                                                                       //
      updateSandstormMetaData({ setPath: path });                      // 151
    }]);                                                               //
                                                                       //
    Tracker.autorun(function () {                                      // 154
      updateSandstormMetaData({ setTitle: DocHead.getTitle() });       // 155
    });                                                                //
                                                                       //
    // Runtime redirection from the home page to the unique board -- since the
    // home page contains a list of a single board it's not worth to display.
    //                                                                 //
    // XXX Hack. The home route is already defined at this point so we need to
    // add the redirection trigger to the internal route object.       //
    FlowRouter._routesMap.home._triggersEnter.push(function (context, redirect) {
      redirect(FlowRouter.path('board', {                              // 164
        id: sandstormBoard._id,                                        // 165
        slug: sandstormBoard.slug                                      // 166
      }));                                                             //
    });                                                                //
                                                                       //
    // XXX Hack. `Meteor.absoluteUrl` doesn't work in Sandstorm, since every
    // session has a different URL whereas Meteor computes absoluteUrl based on
    // the ROOT_URL environment variable. So we overwrite this function on a
    // sandstorm client to return relative paths instead of absolutes.
    var _absoluteUrl = Meteor.absoluteUrl;                             // 174
    var _defaultOptions = Meteor.absoluteUrl.defaultOptions;           // 175
    Meteor.absoluteUrl = function (path, options) {                    // 176
      // eslint-disable-line meteor/core                               //
      var url = _absoluteUrl(path, options);                           // 177
      return url.replace(/^https?:\/\/127\.0\.0\.1:[0-9]{2,5}/, '');   // 178
    };                                                                 //
    Meteor.absoluteUrl.defaultOptions = _defaultOptions;               // 180
  })();                                                                //
}                                                                      //
                                                                       //
// We use this blaze helper in the UI to hide some templates that does not make
// sense in the context of sandstorm, like board staring, board archiving, user
// name edition, etc.                                                  //
Blaze.registerHelper('isSandstorm', isSandstorm);                      // 186
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=sandstorm.js.map
