(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/export.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/* global JsonRoutes */                                                //
if (Meteor.isServer) {                                                 // 2
  // todo XXX once we have a real API in place, move that route there  //
  // todo XXX also  share the route definition between the client and the server
  // so that we could use something like ApiRoutes.path('boards/export', boardId)
  // on the client instead of copy/pasting the route path manually between the client and the server.
  /*                                                                   //
   * This route is used to export the board FROM THE APPLICATION.      //
   * If user is already logged-in, pass loginToken as param "authToken":
   * '/api/boards/:boardId?authToken=:token'                           //
   *                                                                   //
   * See https://blog.kayla.com.au/server-side-route-authentication-in-meteor/
   * for detailed explanations                                         //
   */                                                                  //
  JsonRoutes.add('get', '/api/boards/:boardId', function (req, res) {  // 15
    var boardId = req.params.boardId;                                  // 16
    var user = null;                                                   // 17
    // todo XXX for real API, first look for token in Authentication: header
    // then fallback to parameter                                      //
    var loginToken = req.query.authToken;                              // 20
    if (loginToken) {                                                  // 21
      var hashToken = Accounts._hashLoginToken(loginToken);            // 22
      user = Meteor.users.findOne({                                    // 23
        'services.resume.loginTokens.hashedToken': hashToken           // 24
      });                                                              //
    }                                                                  //
                                                                       //
    var exporter = new Exporter(boardId);                              // 28
    if (exporter.canExport(user)) {                                    // 29
      JsonRoutes.sendResult(res, 200, exporter.build());               // 30
    } else {                                                           //
      // we could send an explicit error message, but on the other hand the only way to
      // get there is by hacking the UI so let's keep it raw.          //
      JsonRoutes.sendResult(res, 403);                                 // 34
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
var Exporter = (function () {                                          //
  function Exporter(boardId) {                                         // 40
    babelHelpers.classCallCheck(this, Exporter);                       //
                                                                       //
    this._boardId = boardId;                                           // 41
  }                                                                    //
                                                                       //
  Exporter.prototype.build = (function () {                            // 39
    function build() {                                                 // 44
      var byBoard = { boardId: this._boardId };                        // 45
      // we do not want to retrieve boardId in related elements        //
      var noBoardId = { fields: { boardId: 0 } };                      // 47
      var result = {                                                   // 48
        _format: 'wekan-board-1.0.0'                                   // 49
      };                                                               //
      _.extend(result, Boards.findOne(this._boardId, { fields: { stars: 0 } }));
      result.lists = Lists.find(byBoard, noBoardId).fetch();           // 52
      result.cards = Cards.find(byBoard, noBoardId).fetch();           // 53
      result.comments = CardComments.find(byBoard, noBoardId).fetch();
      result.activities = Activities.find(byBoard, noBoardId).fetch();
      // for attachments we only export IDs and absolute url to original doc
      result.attachments = Attachments.find(byBoard).fetch().map(function (attachment) {
        return {                                                       // 57
          _id: attachment._id,                                         // 58
          cardId: attachment.cardId,                                   // 59
          url: Meteor.absoluteUrl(Utils.stripLeadingSlash(attachment.url()))
        };                                                             //
      });                                                              //
                                                                       //
      // we also have to export some user data - as the other elements only include id
      // but we have to be careful:                                    //
      // 1- only exports users that are linked somehow to that board   //
      // 2- do not export any sensitive information                    //
      var users = {};                                                  // 67
      result.members.forEach(function (member) {                       // 68
        users[member.userId] = true;                                   // 68
      });                                                              //
      result.lists.forEach(function (list) {                           // 69
        users[list.userId] = true;                                     // 69
      });                                                              //
      result.cards.forEach(function (card) {                           // 70
        users[card.userId] = true;                                     // 71
        if (card.members) {                                            // 72
          card.members.forEach(function (memberId) {                   // 73
            users[memberId] = true;                                    // 73
          });                                                          //
        }                                                              //
      });                                                              //
      result.comments.forEach(function (comment) {                     // 76
        users[comment.userId] = true;                                  // 76
      });                                                              //
      result.activities.forEach(function (activity) {                  // 77
        users[activity.userId] = true;                                 // 77
      });                                                              //
      var byUserIds = { _id: { $in: Object.getOwnPropertyNames(users) } };
      // we use whitelist to be sure we do not expose inadvertently    //
      // some secret fields that gets added to User later.             //
      var userFields = { fields: {                                     // 81
          _id: 1,                                                      // 82
          username: 1,                                                 // 83
          'profile.fullname': 1,                                       // 84
          'profile.initials': 1,                                       // 85
          'profile.avatarUrl': 1                                       // 86
        } };                                                           //
      result.users = Users.find(byUserIds, userFields).fetch().map(function (user) {
        // user avatar is stored as a relative url, we export absolute
        if (user.profile.avatarUrl) {                                  // 90
          user.profile.avatarUrl = Meteor.absoluteUrl(Utils.stripLeadingSlash(user.profile.avatarUrl));
        }                                                              //
        return user;                                                   // 93
      });                                                              //
      return result;                                                   // 95
    }                                                                  //
                                                                       //
    return build;                                                      //
  })();                                                                //
                                                                       //
  Exporter.prototype.canExport = (function () {                        // 39
    function canExport(user) {                                         // 98
      var board = Boards.findOne(this._boardId);                       // 99
      return board && board.isVisibleBy(user);                         // 100
    }                                                                  //
                                                                       //
    return canExport;                                                  //
  })();                                                                //
                                                                       //
  return Exporter;                                                     //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=export.js.map
