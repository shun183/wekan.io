(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/unsavedEdits.js                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('unsaved-edits', function () {                          // 1
  return UnsavedEditCollection.find({                                  // 2
    userId: this.userId                                                // 3
  });                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=unsavedEdits.js.map
