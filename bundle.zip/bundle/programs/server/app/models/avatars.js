(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/avatars.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Avatars = new FS.Collection('avatars', {                               // 1
  stores: [new FS.Store.GridFS('avatars')],                            // 2
  filter: {                                                            // 5
    maxSize: 72000,                                                    // 6
    allow: {                                                           // 7
      contentTypes: ['image/*']                                        // 8
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
function isOwner(userId, file) {                                       // 13
  return userId && userId === file.userId;                             // 14
}                                                                      //
                                                                       //
Avatars.allow({                                                        // 17
  insert: isOwner,                                                     // 18
  update: isOwner,                                                     // 19
  remove: isOwner,                                                     // 20
  download: function () {                                              // 21
    return true;                                                       // 21
  },                                                                   //
  fetch: ['userId']                                                    // 22
});                                                                    //
                                                                       //
Avatars.files.before.insert(function (userId, doc) {                   // 25
  doc.userId = userId;                                                 // 26
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=avatars.js.map
