(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/cardComments.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
CardComments = new Mongo.Collection('card_comments');                  // 1
                                                                       //
CardComments.attachSchema(new SimpleSchema({                           // 3
  boardId: {                                                           // 4
    type: String                                                       // 5
  },                                                                   //
  cardId: {                                                            // 7
    type: String                                                       // 8
  },                                                                   //
  // XXX Rename in `content`? `text` is a bit vague...                 //
  text: {                                                              // 11
    type: String                                                       // 12
  },                                                                   //
  // XXX We probably don't need this information here, since we already have it
  // in the associated comment creation activity                       //
  createdAt: {                                                         // 16
    type: Date,                                                        // 17
    denyUpdate: false                                                  // 18
  },                                                                   //
  // XXX Should probably be called `authorId`                          //
  userId: {                                                            // 21
    type: String                                                       // 22
  }                                                                    //
}));                                                                   //
                                                                       //
CardComments.allow({                                                   // 26
  insert: function (userId, doc) {                                     // 27
    return allowIsBoardMember(userId, Boards.findOne(doc.boardId));    // 28
  },                                                                   //
  update: function (userId, doc) {                                     // 30
    return userId === doc.userId;                                      // 31
  },                                                                   //
  remove: function (userId, doc) {                                     // 33
    return userId === doc.userId;                                      // 34
  },                                                                   //
  fetch: ['userId', 'boardId']                                         // 36
});                                                                    //
                                                                       //
CardComments.helpers({                                                 // 39
  user: function () {                                                  // 40
    return Users.findOne(this.userId);                                 // 41
  }                                                                    //
});                                                                    //
                                                                       //
CardComments.hookOptions.after.update = { fetchPrevious: false };      // 45
                                                                       //
CardComments.before.insert(function (userId, doc) {                    // 47
  doc.createdAt = new Date();                                          // 48
  doc.userId = userId;                                                 // 49
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 52
  CardComments.after.insert(function (userId, doc) {                   // 53
    Activities.insert({                                                // 54
      userId: userId,                                                  // 55
      activityType: 'addComment',                                      // 56
      boardId: doc.boardId,                                            // 57
      cardId: doc.cardId,                                              // 58
      commentId: doc._id                                               // 59
    });                                                                //
  });                                                                  //
                                                                       //
  CardComments.after.remove(function (userId, doc) {                   // 63
    var activity = Activities.findOne({ commentId: doc._id });         // 64
    if (activity) {                                                    // 65
      Activities.remove(activity._id);                                 // 66
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=cardComments.js.map
