(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var EJSON = Package.ejson.EJSON;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var Random = Package.random.Random;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/alethes_pages/packages/alethes_pages.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function () {                                                                                                         // 1
                                                                                                                       // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/alethes:pages/lib/pages.coffee.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Pages,                                                                                                             // 10
  __slice = [].slice,                                                                                                  // 11
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };
                                                                                                                       // 13
this.__Pages = Pages = (function() {                                                                                   // 14
  Pages.prototype.settings = {                                                                                         // 15
    dataMargin: [true, Number, 3],                                                                                     // 16
    divWrapper: [true, Match.OneOf(Match.Optional(String), Match.Optional(Boolean)), "pagesCont"],                     // 17
    fields: [true, Object, {}],                                                                                        // 18
    filters: [true, Object, {}],                                                                                       // 19
    itemTemplate: [true, String, "_pagesItemDefault"],                                                                 // 20
    navShowEdges: [true, Boolean, false],                                                                              // 21
    navShowFirst: [true, Boolean, true],                                                                               // 22
    navShowLast: [true, Boolean, true],                                                                                // 23
    resetOnReload: [true, Boolean, false],                                                                             // 24
    paginationMargin: [true, Number, 3],                                                                               // 25
    perPage: [true, Number, 10],                                                                                       // 26
    route: [true, String, "/page/"],                                                                                   // 27
    router: [true, Match.Optional(String), void 0],                                                                    // 28
    routerTemplate: [true, String, "pages"],                                                                           // 29
    routerLayout: [true, Match.Optional(String), void 0],                                                              // 30
    sort: [true, Object, {}],                                                                                          // 31
    auth: [false, Match.Optional(Function), void 0],                                                                   // 32
    availableSettings: [false, Object, {}],                                                                            // 33
    fastRender: [false, Boolean, false],                                                                               // 34
    homeRoute: [false, Match.OneOf(String, Array, Boolean), "/"],                                                      // 35
    infinite: [false, Boolean, false],                                                                                 // 36
    infiniteItemsLimit: [false, Number, Infinity],                                                                     // 37
    infiniteTrigger: [false, Number, .9],                                                                              // 38
    infiniteRateLimit: [false, Number, 1],                                                                             // 39
    navTemplate: [false, String, "_pagesNavCont"],                                                                     // 40
    onDeniedSetting: [                                                                                                 // 41
      false, Function, function(k, v, e) {                                                                             // 42
        return typeof console !== "undefined" && console !== null ? console.log("Changing " + k + " not allowed.") : void 0;
      }                                                                                                                // 44
    ],                                                                                                                 // 45
    pageSizeLimit: [false, Number, 60],                                                                                // 46
    pageTemplate: [false, String, "_pagesPageCont"],                                                                   // 47
    rateLimit: [false, Number, 1],                                                                                     // 48
    routeSettings: [false, Match.Optional(Function), void 0],                                                          // 49
    table: [false, Match.OneOf(Boolean, Object), false],                                                               // 50
    tableItemTemplate: [false, String, "_pagesTableItem"],                                                             // 51
    tableTemplate: [false, String, "_pagesTable"],                                                                     // 52
    templateName: [false, Match.Optional(String), void 0]                                                              // 53
  };                                                                                                                   // 54
                                                                                                                       // 55
  Pages.prototype._nInstances = 0;                                                                                     // 56
                                                                                                                       // 57
  Pages.prototype.collections = {};                                                                                    // 58
                                                                                                                       // 59
  Pages.prototype.instances = {};                                                                                      // 60
                                                                                                                       // 61
  Pages.prototype.methods = {                                                                                          // 62
    "CountPages": function(sub) {                                                                                      // 63
      var n;                                                                                                           // 64
      n = sub.get("nPublishedPages");                                                                                  // 65
      if (n != null) {                                                                                                 // 66
        return n;                                                                                                      // 67
      }                                                                                                                // 68
      n = Math.ceil(this.Collection.find({                                                                             // 69
        $and: [sub.get("filters"), sub.get("realFilters") || {}]                                                       // 70
      }).count() / (sub.get("perPage")));                                                                              // 71
      return n || 1;                                                                                                   // 72
    },                                                                                                                 // 73
    "Set": function(k, v, sub) {                                                                                       // 74
      var changes, _k, _v;                                                                                             // 75
      if (this.settings[k] == null) {                                                                                  // 76
        this.error(4003, "Invalid option: " + k + ".");                                                                // 77
      }                                                                                                                // 78
      check(k, String);                                                                                                // 79
      check(v, this.settings[k][1]);                                                                                   // 80
      check(sub, Match.Where(function(sub) {                                                                           // 81
        var _ref;                                                                                                      // 82
        return ((_ref = sub.connection) != null ? _ref.id : void 0) != null;                                           // 83
      }));                                                                                                             // 84
      if (!this.availableSettings[k] || (_.isFunction(this.availableSettings[k]) && !this.availableSettings[k](v, sub))) {
        this.error(4002, "Changing " + k + " not allowed.");                                                           // 86
      }                                                                                                                // 87
      changes = 0;                                                                                                     // 88
      if (v != null) {                                                                                                 // 89
        changes = this._set(k, v, {                                                                                    // 90
          cid: sub.connection.id                                                                                       // 91
        });                                                                                                            // 92
      } else if (!_.isString(k)) {                                                                                     // 93
        for (_k in k) {                                                                                                // 94
          _v = k[_k];                                                                                                  // 95
          changes += this.set(_k, _v, {                                                                                // 96
            cid: sub.connection.id                                                                                     // 97
          });                                                                                                          // 98
        }                                                                                                              // 99
      }                                                                                                                // 100
      return changes;                                                                                                  // 101
    },                                                                                                                 // 102
    "Unsubscribe": function() {                                                                                        // 103
      var i, k, subs, _i, _len, _ref;                                                                                  // 104
      subs = [];                                                                                                       // 105
      _ref = this.subscriptions;                                                                                       // 106
      for (k = _i = 0, _len = _ref.length; _i < _len; k = ++_i) {                                                      // 107
        i = _ref[k];                                                                                                   // 108
        if (i.connection.id === arguments[arguments.length - 1].connection.id) {                                       // 109
          i.stop();                                                                                                    // 110
        } else {                                                                                                       // 111
          subs.push(i);                                                                                                // 112
        }                                                                                                              // 113
      }                                                                                                                // 114
      this.subscriptions = subs;                                                                                       // 115
      return true;                                                                                                     // 116
    }                                                                                                                  // 117
  };                                                                                                                   // 118
                                                                                                                       // 119
  function Pages(collection, settings) {                                                                               // 120
    if (settings == null) {                                                                                            // 121
      settings = {};                                                                                                   // 122
    }                                                                                                                  // 123
    if (!(this instanceof Meteor.Pagination)) {                                                                        // 124
      throw new Meteor.Error(4000, "The Meteor.Pagination instance has to be initiated with `new`");                   // 125
    }                                                                                                                  // 126
    this.init = true;                                                                                                  // 127
    this.subscriptions = [];                                                                                           // 128
    this.userSettings = {};                                                                                            // 129
    this._currentPage = 1;                                                                                             // 130
    this.setCollection(collection);                                                                                    // 131
    this.setInitial(settings);                                                                                         // 132
    this.setDefaults();                                                                                                // 133
    this.setRouter();                                                                                                  // 134
    this[(Meteor.isServer ? "server" : "client") + "Init"]();                                                          // 135
    this.registerInstance();                                                                                           // 136
    this;                                                                                                              // 137
  }                                                                                                                    // 138
                                                                                                                       // 139
  Pages.prototype.error = function(code, msg) {                                                                        // 140
    if (code == null) {                                                                                                // 141
      msg = code;                                                                                                      // 142
    }                                                                                                                  // 143
    throw new Meteor.Error(code, msg);                                                                                 // 144
  };                                                                                                                   // 145
                                                                                                                       // 146
  Pages.prototype.serverInit = function() {                                                                            // 147
    var self;                                                                                                          // 148
    this.setMethods();                                                                                                 // 149
    self = this;                                                                                                       // 150
    Meteor.onConnection((function(_this) {                                                                             // 151
      return function(connection) {                                                                                    // 152
        return connection.onClose(function() {                                                                         // 153
          return delete _this.userSettings[connection.id];                                                             // 154
        });                                                                                                            // 155
      };                                                                                                               // 156
    })(this));                                                                                                         // 157
    return Meteor.publish(this.id, function(page) {                                                                    // 158
      return self.publish.call(self, page, this);                                                                      // 159
    });                                                                                                                // 160
  };                                                                                                                   // 161
                                                                                                                       // 162
  Pages.prototype.clientInit = function() {                                                                            // 163
    this.requested = {};                                                                                               // 164
    this.received = {};                                                                                                // 165
    this.queue = [];                                                                                                   // 166
    this.setTemplates();                                                                                               // 167
    this.countPages();                                                                                                 // 168
    Tracker.autorun((function(_this) {                                                                                 // 169
      return function() {                                                                                              // 170
        if (typeof Meteor.userId === "function") {                                                                     // 171
          Meteor.userId();                                                                                             // 172
        }                                                                                                              // 173
        return _this.reload();                                                                                         // 174
      };                                                                                                               // 175
    })(this));                                                                                                         // 176
    if (this.infinite) {                                                                                               // 177
      return this.setInfiniteTrigger();                                                                                // 178
    }                                                                                                                  // 179
  };                                                                                                                   // 180
                                                                                                                       // 181
  Pages.prototype.reload = function() {                                                                                // 182
    return this.unsubscribe((function(_this) {                                                                         // 183
      return function() {                                                                                              // 184
        return _this.call("CountPages", function(e, total) {                                                           // 185
          var p;                                                                                                       // 186
          _this.sess("totalPages", total);                                                                             // 187
          p = _this.currentPage();                                                                                     // 188
          if ((p == null) || _this.resetOnReload || p > total) {                                                       // 189
            p = 1;                                                                                                     // 190
          }                                                                                                            // 191
          _this.sess("currentPage", false);                                                                            // 192
          return _this.sess("currentPage", p);                                                                         // 193
        });                                                                                                            // 194
      };                                                                                                               // 195
    })(this));                                                                                                         // 196
  };                                                                                                                   // 197
                                                                                                                       // 198
  Pages.prototype.unsubscribe = function(cb) {                                                                         // 199
    return this.call("Unsubscribe", (function(_this) {                                                                 // 200
      return function() {                                                                                              // 201
        delete _this.initPage;                                                                                         // 202
        _this.subscriptions = [];                                                                                      // 203
        _this.requested = {};                                                                                          // 204
        _this.received = {};                                                                                           // 205
        _this.queue = [];                                                                                              // 206
        return typeof cb === "function" ? cb() : void 0;                                                               // 207
      };                                                                                                               // 208
    })(this));                                                                                                         // 209
  };                                                                                                                   // 210
                                                                                                                       // 211
  Pages.prototype.setDefaults = function() {                                                                           // 212
    var k, v, _ref, _results;                                                                                          // 213
    _ref = this.settings;                                                                                              // 214
    _results = [];                                                                                                     // 215
    for (k in _ref) {                                                                                                  // 216
      v = _ref[k];                                                                                                     // 217
      if (v[2] != null) {                                                                                              // 218
        _results.push(this[k] != null ? this[k] : this[k] = v[2]);                                                     // 219
      } else {                                                                                                         // 220
        _results.push(void 0);                                                                                         // 221
      }                                                                                                                // 222
    }                                                                                                                  // 223
    return _results;                                                                                                   // 224
  };                                                                                                                   // 225
                                                                                                                       // 226
  Pages.prototype.syncSettings = function(cb) {                                                                        // 227
    var S, k, v, _ref;                                                                                                 // 228
    S = {};                                                                                                            // 229
    _ref = this.settings;                                                                                              // 230
    for (k in _ref) {                                                                                                  // 231
      v = _ref[k];                                                                                                     // 232
      if (v[0]) {                                                                                                      // 233
        S[k] = this[k];                                                                                                // 234
      }                                                                                                                // 235
    }                                                                                                                  // 236
    return this.set(S, cb != null ? {                                                                                  // 237
      cb: cb.bind(this)                                                                                                // 238
    } : null);                                                                                                         // 239
  };                                                                                                                   // 240
                                                                                                                       // 241
  Pages.prototype.setMethods = function() {                                                                            // 242
    var f, n, nm, self, _ref;                                                                                          // 243
    nm = {};                                                                                                           // 244
    self = this;                                                                                                       // 245
    _ref = this.methods;                                                                                               // 246
    for (n in _ref) {                                                                                                  // 247
      f = _ref[n];                                                                                                     // 248
      nm[this.getMethodName(n)] = (function(f) {                                                                       // 249
        return function() {                                                                                            // 250
          var arg, k, r, v;                                                                                            // 251
          arg = (function() {                                                                                          // 252
            var _results;                                                                                              // 253
            _results = [];                                                                                             // 254
            for (k in arguments) {                                                                                     // 255
              v = arguments[k];                                                                                        // 256
              _results.push(v);                                                                                        // 257
            }                                                                                                          // 258
            return _results;                                                                                           // 259
          }).apply(this, arguments);                                                                                   // 260
          arg.push(this);                                                                                              // 261
          this.get = (function(self, k) {                                                                              // 262
            return self.get(k, this.connection.id);                                                                    // 263
          }).bind(this, self);                                                                                         // 264
          r = f.apply(self, arg);                                                                                      // 265
          return r;                                                                                                    // 266
        };                                                                                                             // 267
      })(f);                                                                                                           // 268
    }                                                                                                                  // 269
    return Meteor.methods(nm);                                                                                         // 270
  };                                                                                                                   // 271
                                                                                                                       // 272
  Pages.prototype.getMethodName = function(name) {                                                                     // 273
    return "" + this.id + "/" + name;                                                                                  // 274
  };                                                                                                                   // 275
                                                                                                                       // 276
  Pages.prototype.call = function() {                                                                                  // 277
    var args, last;                                                                                                    // 278
    args = 1 <= arguments.length ? __slice.call(arguments, 0) : [];                                                    // 279
    check(args, Array);                                                                                                // 280
    if (args.length < 1) {                                                                                             // 281
      this.error(4001, "Method name not provided in a method call.");                                                  // 282
    }                                                                                                                  // 283
    args[0] = this.getMethodName(args[0]);                                                                             // 284
    last = args.length - 1;                                                                                            // 285
    if (_.isFunction(args[last])) {                                                                                    // 286
      args[last] = args[last].bind(this);                                                                              // 287
    }                                                                                                                  // 288
    return Meteor.call.apply(this, args);                                                                              // 289
  };                                                                                                                   // 290
                                                                                                                       // 291
  Pages.prototype.sess = function(k, v) {                                                                              // 292
    if (typeof Session === "undefined" || Session === null) {                                                          // 293
      return;                                                                                                          // 294
    }                                                                                                                  // 295
    k = "" + this.id + "." + k;                                                                                        // 296
    if (arguments.length === 2) {                                                                                      // 297
      return Session.set(k, v);                                                                                        // 298
    } else {                                                                                                           // 299
      return Session.get(k);                                                                                           // 300
    }                                                                                                                  // 301
  };                                                                                                                   // 302
                                                                                                                       // 303
  Pages.prototype.get = function(setting, connectionId) {                                                              // 304
    var _ref, _ref1;                                                                                                   // 305
    return (_ref = (_ref1 = this.userSettings[connectionId]) != null ? _ref1[setting] : void 0) != null ? _ref : this[setting];
  };                                                                                                                   // 307
                                                                                                                       // 308
  Pages.prototype.set = function() {                                                                                   // 309
    var ch, k, opts, _k, _v;                                                                                           // 310
    k = arguments[0], opts = 2 <= arguments.length ? __slice.call(arguments, 1) : [];                                  // 311
    ch = 0;                                                                                                            // 312
    switch (opts.length) {                                                                                             // 313
      case 0:                                                                                                          // 314
        if (_.isObject(k)) {                                                                                           // 315
          for (_k in k) {                                                                                              // 316
            _v = k[_k];                                                                                                // 317
            ch += this._set(_k, _v);                                                                                   // 318
          }                                                                                                            // 319
        }                                                                                                              // 320
        break;                                                                                                         // 321
      case 1:                                                                                                          // 322
        if (_.isObject(k)) {                                                                                           // 323
          if (_.isFunction(opts[0])) {                                                                                 // 324
            opts[0] = {                                                                                                // 325
              cb: opts[0]                                                                                              // 326
            };                                                                                                         // 327
          }                                                                                                            // 328
          for (_k in k) {                                                                                              // 329
            _v = k[_k];                                                                                                // 330
            ch += this._set(_k, _v, opts[0]);                                                                          // 331
          }                                                                                                            // 332
        } else {                                                                                                       // 333
          check(k, String);                                                                                            // 334
          ch = this._set(k, opts[0]);                                                                                  // 335
        }                                                                                                              // 336
        break;                                                                                                         // 337
      case 2:                                                                                                          // 338
        if (_.isFunction(opts[1])) {                                                                                   // 339
          opts[1] = {                                                                                                  // 340
            cb: opts[1]                                                                                                // 341
          };                                                                                                           // 342
        }                                                                                                              // 343
        ch = this._set(k, opts[0], opts[1]);                                                                           // 344
        break;                                                                                                         // 345
      case 3:                                                                                                          // 346
        check(opts[1], Object);                                                                                        // 347
        check(opts[2], Function);                                                                                      // 348
        opts[2] = {                                                                                                    // 349
          cb: opts[2]                                                                                                  // 350
        };                                                                                                             // 351
        ch = this._set(k, opts[1], opts[2]);                                                                           // 352
    }                                                                                                                  // 353
    if (Meteor.isClient && ch) {                                                                                       // 354
      this.reload();                                                                                                   // 355
    }                                                                                                                  // 356
    return ch;                                                                                                         // 357
  };                                                                                                                   // 358
                                                                                                                       // 359
  Pages.prototype.setInitial = function(settings) {                                                                    // 360
    this.setInitDone = false;                                                                                          // 361
    this.set(settings);                                                                                                // 362
    return this.setInitDone = true;                                                                                    // 363
  };                                                                                                                   // 364
                                                                                                                       // 365
  Pages.prototype.sanitizeRegex = function(v) {                                                                        // 366
    var lis;                                                                                                           // 367
    if (_.isRegExp(v)) {                                                                                               // 368
      v = v.toString();                                                                                                // 369
      lis = v.lastIndexOf("/");                                                                                        // 370
      v = {                                                                                                            // 371
        $regex: v.slice(1, lis),                                                                                       // 372
        $options: v.slice(1 + lis)                                                                                     // 373
      };                                                                                                               // 374
    }                                                                                                                  // 375
    return v;                                                                                                          // 376
  };                                                                                                                   // 377
                                                                                                                       // 378
  Pages.prototype.sanitizeRegexObj = function(obj) {                                                                   // 379
    var k, v;                                                                                                          // 380
    if (_.isRegExp(obj)) {                                                                                             // 381
      return this.sanitizeRegex(obj);                                                                                  // 382
    }                                                                                                                  // 383
    for (k in obj) {                                                                                                   // 384
      v = obj[k];                                                                                                      // 385
      if (_.isRegExp(v)) {                                                                                             // 386
        obj[k] = this.sanitizeRegex(v);                                                                                // 387
      } else if ("object" === typeof v) {                                                                              // 388
        obj[k] = this.sanitizeRegexObj(v);                                                                             // 389
      }                                                                                                                // 390
    }                                                                                                                  // 391
    return obj;                                                                                                        // 392
  };                                                                                                                   // 393
                                                                                                                       // 394
  Pages.prototype._set = function(k, v, opts) {                                                                        // 395
    var ch, oldV, _base, _name, _ref, _ref1, _ref2;                                                                    // 396
    if (opts == null) {                                                                                                // 397
      opts = {};                                                                                                       // 398
    }                                                                                                                  // 399
    check(k, String);                                                                                                  // 400
    ch = 1;                                                                                                            // 401
    if (Meteor.isServer || (this[k] == null) || ((_ref = this.settings[k]) != null ? _ref[0] : void 0) || opts.init) {
      if ((((_ref1 = this.settings[k]) != null ? _ref1[1] : void 0) != null) && ((_ref2 = this.settings[k]) != null ? _ref2[1] : void 0) !== true) {
        check(v, this.settings[k][1]);                                                                                 // 404
      }                                                                                                                // 405
      this.sanitizeRegexObj(v);                                                                                        // 406
      oldV = this.get(k, opts != null ? opts.cid : void 0);                                                            // 407
      if (this.valuesEqual(v, oldV)) {                                                                                 // 408
        return 0;                                                                                                      // 409
      }                                                                                                                // 410
      if (Meteor.isClient) {                                                                                           // 411
        this[k] = v;                                                                                                   // 412
        if (this.setInitDone) {                                                                                        // 413
          this.call("Set", k, v, function(e, r) {                                                                      // 414
            if (e) {                                                                                                   // 415
              this[k] = oldV;                                                                                          // 416
              return this.onDeniedSetting.call(this, k, v, e);                                                         // 417
            }                                                                                                          // 418
            return typeof opts.cb === "function" ? opts.cb(ch) : void 0;                                               // 419
          });                                                                                                          // 420
        }                                                                                                              // 421
      } else {                                                                                                         // 422
        if (opts.cid) {                                                                                                // 423
          if (ch != null) {                                                                                            // 424
            if ((_base = this.userSettings)[_name = opts.cid] == null) {                                               // 425
              _base[_name] = {};                                                                                       // 426
            }                                                                                                          // 427
            this.userSettings[opts.cid][k] = v;                                                                        // 428
          }                                                                                                            // 429
        } else {                                                                                                       // 430
          this[k] = v;                                                                                                 // 431
        }                                                                                                              // 432
        if (typeof opts.cb === "function") {                                                                           // 433
          opts.cb(ch);                                                                                                 // 434
        }                                                                                                              // 435
      }                                                                                                                // 436
    } else {                                                                                                           // 437
      this.onDeniedSetting.call(this, k, v);                                                                           // 438
    }                                                                                                                  // 439
    return ch;                                                                                                         // 440
  };                                                                                                                   // 441
                                                                                                                       // 442
  Pages.prototype.valuesEqual = function(v1, v2) {                                                                     // 443
    if (_.isFunction(v1)) {                                                                                            // 444
      return _.isFunction(v2) && v1.toString() === v2.toString();                                                      // 445
    } else {                                                                                                           // 446
      return _.isEqual(v1, v2);                                                                                        // 447
    }                                                                                                                  // 448
  };                                                                                                                   // 449
                                                                                                                       // 450
  Pages.prototype.setId = function(name) {                                                                             // 451
    var n;                                                                                                             // 452
    if (this.templateName) {                                                                                           // 453
      name = this.templateName;                                                                                        // 454
    }                                                                                                                  // 455
    while (name in Pages.prototype.instances) {                                                                        // 456
      n = name.match(/[0-9]+$/);                                                                                       // 457
      if (n != null) {                                                                                                 // 458
        name = name.slice(0, name.length - n[0].length) + (parseInt(n) + 1);                                           // 459
      } else {                                                                                                         // 460
        name = name + "2";                                                                                             // 461
      }                                                                                                                // 462
    }                                                                                                                  // 463
    this.id = "pages_" + name;                                                                                         // 464
    return this.name = name;                                                                                           // 465
  };                                                                                                                   // 466
                                                                                                                       // 467
  Pages.prototype.registerInstance = function() {                                                                      // 468
    Pages.prototype._nInstances++;                                                                                     // 469
    return Pages.prototype.instances[this.name] = this;                                                                // 470
  };                                                                                                                   // 471
                                                                                                                       // 472
  Pages.prototype.setCollection = function(collection) {                                                               // 473
    var e;                                                                                                             // 474
    if (typeof collection === "object") {                                                                              // 475
      Pages.prototype.collections[collection._name] = collection;                                                      // 476
      this.Collection = collection;                                                                                    // 477
    } else {                                                                                                           // 478
      try {                                                                                                            // 479
        this.Collection = new Mongo.Collection(collection);                                                            // 480
        Pages.prototype.collections[collection] = this.Collection;                                                     // 481
      } catch (_error) {                                                                                               // 482
        e = _error;                                                                                                    // 483
        this.Collection = Pages.prototype.collections[collection];                                                     // 484
        this.Collection instanceof Mongo.Collection || this.error(4000, "The '" + collection + "' collection was created outside of <Meteor.Pagination>. Pass the collection object instead of the collection's name to the <Meteor.Pagination> constructor.");
      }                                                                                                                // 486
    }                                                                                                                  // 487
    this.setId(this.Collection._name);                                                                                 // 488
    return this.PaginatedCollection = new Mongo.Collection(this.id);                                                   // 489
  };                                                                                                                   // 490
                                                                                                                       // 491
  Pages.prototype.linkTo = function(page) {                                                                            // 492
    var params, _ref;                                                                                                  // 493
    if ((_ref = Router.current()) != null ? _ref.params : void 0) {                                                    // 494
      params = Router.current().params;                                                                                // 495
      params.page = page;                                                                                              // 496
      return Router.routes["" + this.name + "_page"].path(params);                                                     // 497
    }                                                                                                                  // 498
  };                                                                                                                   // 499
                                                                                                                       // 500
  Pages.prototype.setRouter = function() {                                                                             // 501
    var init, l, pr, self, t, _ref;                                                                                    // 502
    if (this.router === "iron-router") {                                                                               // 503
      if (this.route.indexOf(":page") === -1) {                                                                        // 504
        if (this.route[0] !== "/") {                                                                                   // 505
          this.route = "/" + this.route;                                                                               // 506
        }                                                                                                              // 507
        if (this.route[this.route.length - 1] !== "/") {                                                               // 508
          this.route += "/";                                                                                           // 509
        }                                                                                                              // 510
        pr = this.route = "" + this.route + ":page";                                                                   // 511
      }                                                                                                                // 512
      t = this.routerTemplate;                                                                                         // 513
      l = (_ref = this.routerLayout) != null ? _ref : void 0;                                                          // 514
      self = this;                                                                                                     // 515
      init = true;                                                                                                     // 516
      Router.map(function() {                                                                                          // 517
        var hr, k, _i, _len, _ref1, _results;                                                                          // 518
        if (!self.infinite) {                                                                                          // 519
          this.route("" + self.name + "_page", {                                                                       // 520
            path: pr,                                                                                                  // 521
            template: t,                                                                                               // 522
            layoutTemplate: l,                                                                                         // 523
            onBeforeAction: function() {                                                                               // 524
              var page;                                                                                                // 525
              page = parseInt(this.params.page);                                                                       // 526
              if (self.init) {                                                                                         // 527
                self.sess("oldPage", page);                                                                            // 528
                self.sess("currentPage", page);                                                                        // 529
              }                                                                                                        // 530
              if (self.routeSettings != null) {                                                                        // 531
                self.routeSettings(this);                                                                              // 532
              }                                                                                                        // 533
              Tracker.nonreactive((function(_this) {                                                                   // 534
                return function() {                                                                                    // 535
                  return self.onNavClick(page);                                                                        // 536
                };                                                                                                     // 537
              })(this));                                                                                               // 538
              return this.next();                                                                                      // 539
            }                                                                                                          // 540
          });                                                                                                          // 541
        }                                                                                                              // 542
        if (self.homeRoute) {                                                                                          // 543
          if (_.isString(self.homeRoute)) {                                                                            // 544
            self.homeRoute = [self.homeRoute];                                                                         // 545
          }                                                                                                            // 546
          _ref1 = self.homeRoute;                                                                                      // 547
          _results = [];                                                                                               // 548
          for (k = _i = 0, _len = _ref1.length; _i < _len; k = ++_i) {                                                 // 549
            hr = _ref1[k];                                                                                             // 550
            _results.push(this.route("" + self.name + "_home" + k, {                                                   // 551
              path: hr,                                                                                                // 552
              template: t,                                                                                             // 553
              layoutTemplate: l,                                                                                       // 554
              onBeforeAction: function() {                                                                             // 555
                if (self.routeSettings != null) {                                                                      // 556
                  self.routeSettings(this);                                                                            // 557
                }                                                                                                      // 558
                if (self.init) {                                                                                       // 559
                  self.sess("oldPage", 1);                                                                             // 560
                  self.sess("currentPage", 1);                                                                         // 561
                }                                                                                                      // 562
                return this.next();                                                                                    // 563
              }                                                                                                        // 564
            }));                                                                                                       // 565
          }                                                                                                            // 566
          return _results;                                                                                             // 567
        }                                                                                                              // 568
      });                                                                                                              // 569
      if (Meteor.isServer && this.fastRender) {                                                                        // 570
        self = this;                                                                                                   // 571
        FastRender.route(pr, function(params) {                                                                        // 572
          return this.subscribe(self.id, parseInt(params.page));                                                       // 573
        });                                                                                                            // 574
        return FastRender.route(this.homeRoute, function() {                                                           // 575
          return this.subscribe(self.id, 1);                                                                           // 576
        });                                                                                                            // 577
      }                                                                                                                // 578
    }                                                                                                                  // 579
  };                                                                                                                   // 580
                                                                                                                       // 581
  Pages.prototype.setPerPage = function() {                                                                            // 582
    return this.perPage = this.pageSizeLimit < this.perPage ? this.pageSizeLimit : this.perPage;                       // 583
  };                                                                                                                   // 584
                                                                                                                       // 585
  Pages.prototype.setTemplates = function() {                                                                          // 586
    var i, name, tn, _i, _len, _ref;                                                                                   // 587
    name = this.templateName || this.name;                                                                             // 588
    if (this.table && this.itemTemplate === "_pagesItemDefault") {                                                     // 589
      this.itemTemplate = this.tableItemTemplate;                                                                      // 590
    }                                                                                                                  // 591
    _ref = [this.navTemplate, this.pageTemplate, this.itemTemplate, this.tableTemplate];                               // 592
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {                                                                // 593
      i = _ref[_i];                                                                                                    // 594
      tn = this.id + i;                                                                                                // 595
      Template[tn] = new Blaze.Template("Template." + tn, Template[i].renderFunction);                                 // 596
      Template[tn].helpers(_TemplateHelpers[i]);                                                                       // 597
      Template[tn].events(_TemplateEvents[i]);                                                                         // 598
      Template[tn].helpers({                                                                                           // 599
        pagesData: this                                                                                                // 600
      });                                                                                                              // 601
    }                                                                                                                  // 602
    return Template[name].helpers({                                                                                    // 603
      pagesData: this,                                                                                                 // 604
      pagesNav: Template[this.id + this.navTemplate],                                                                  // 605
      pages: Template[this.id + this.pageTemplate]                                                                     // 606
    });                                                                                                                // 607
  };                                                                                                                   // 608
                                                                                                                       // 609
  Pages.prototype.countPages = _.throttle(function() {                                                                 // 610
    return this.call("CountPages", (function(e, r) {                                                                   // 611
      this.sess("totalPages", r);                                                                                      // 612
      if (this.sess("currentPage") > r) {                                                                              // 613
        return this.sess("currentPage", 1);                                                                            // 614
      }                                                                                                                // 615
    }).bind(this));                                                                                                    // 616
  }, 500);                                                                                                             // 617
                                                                                                                       // 618
  Pages.prototype.publish = function(page, sub) {                                                                      // 619
    var c, cid, filters, get, handle, handle2, init, n, options, r, self, set, skip, _ref, _ref1;                      // 620
    check(page, Number);                                                                                               // 621
    check(sub, Match.Where(function(s) {                                                                               // 622
      return s.ready != null;                                                                                          // 623
    }));                                                                                                               // 624
    cid = sub.connection.id;                                                                                           // 625
    get = sub.get = (function(cid, k) {                                                                                // 626
      return this.get(k, cid);                                                                                         // 627
    }).bind(this, cid);                                                                                                // 628
    set = sub.set = (function(cid, k, v) {                                                                             // 629
      return this.set(k, v, {                                                                                          // 630
        cid: cid                                                                                                       // 631
      });                                                                                                              // 632
    }).bind(this, cid);                                                                                                // 633
    if ((_ref = this.userSettings[cid]) != null) {                                                                     // 634
      delete _ref.realFilters;                                                                                         // 635
    }                                                                                                                  // 636
    if ((_ref1 = this.userSettings[cid]) != null) {                                                                    // 637
      delete _ref1.nPublishedPages;                                                                                    // 638
    }                                                                                                                  // 639
    this.setPerPage();                                                                                                 // 640
    skip = (page - 1) * get("perPage");                                                                                // 641
    if (skip < 0) {                                                                                                    // 642
      skip = 0;                                                                                                        // 643
    }                                                                                                                  // 644
    filters = get("filters");                                                                                          // 645
    options = {                                                                                                        // 646
      sort: get("sort"),                                                                                               // 647
      fields: get("fields"),                                                                                           // 648
      skip: skip,                                                                                                      // 649
      limit: get("perPage")                                                                                            // 650
    };                                                                                                                 // 651
    if (this.auth != null) {                                                                                           // 652
      r = this.auth.call(this, skip, sub);                                                                             // 653
      if (!r) {                                                                                                        // 654
        set("nPublishedPages", 0);                                                                                     // 655
        sub.ready();                                                                                                   // 656
        return this.ready();                                                                                           // 657
      } else if (_.isNumber(r)) {                                                                                      // 658
        set("nPublishedPages", r);                                                                                     // 659
        if (page > r) {                                                                                                // 660
          sub.ready();                                                                                                 // 661
          return this.ready();                                                                                         // 662
        }                                                                                                              // 663
      } else if (_.isArray(r) && r.length === 2) {                                                                     // 664
        if (_.isFunction(r[0].fetch)) {                                                                                // 665
          c = r;                                                                                                       // 666
        } else {                                                                                                       // 667
          filters = r[0];                                                                                              // 668
          options = r[1];                                                                                              // 669
        }                                                                                                              // 670
      } else if (_.isFunction(r.fetch)) {                                                                              // 671
        c = r;                                                                                                         // 672
      }                                                                                                                // 673
    }                                                                                                                  // 674
    if (!EJSON.equals({}, filters) && !EJSON.equals(get("filters"), filters)) {                                        // 675
      set("realFilters", filters);                                                                                     // 676
    }                                                                                                                  // 677
    if (c == null) {                                                                                                   // 678
      c = this.Collection.find(filters, options);                                                                      // 679
    }                                                                                                                  // 680
    init = true;                                                                                                       // 681
    self = this;                                                                                                       // 682
    handle = c.observe({                                                                                               // 683
      addedAt: (function(sub, doc, at) {                                                                               // 684
        var e, id;                                                                                                     // 685
        try {                                                                                                          // 686
          doc["_" + this.id + "_p"] = page;                                                                            // 687
          doc["_" + this.id + "_i"] = at;                                                                              // 688
          id = doc._id;                                                                                                // 689
          delete doc._id;                                                                                              // 690
          if (!init) {                                                                                                 // 691
            sub.added(this.id, id, doc);                                                                               // 692
            return (this.Collection.find(get("filters"), {                                                             // 693
              sort: get("sort"),                                                                                       // 694
              fields: get("fields"),                                                                                   // 695
              skip: skip,                                                                                              // 696
              limit: get("perPage")                                                                                    // 697
            })).forEach((function(_this) {                                                                             // 698
              return function(o, i) {                                                                                  // 699
                if (i >= at) {                                                                                         // 700
                  return sub.changed(_this.id, o._id, _.object([["_" + _this.id + "_i", i + 1]]));                     // 701
                }                                                                                                      // 702
              };                                                                                                       // 703
            })(this));                                                                                                 // 704
          }                                                                                                            // 705
        } catch (_error) {                                                                                             // 706
          e = _error;                                                                                                  // 707
        }                                                                                                              // 708
      }).bind(this, sub)                                                                                               // 709
    });                                                                                                                // 710
    handle2 = c.observeChanges({                                                                                       // 711
      movedBefore: (function(sub, id, before) {                                                                        // 712
        var at, ref;                                                                                                   // 713
        at = -1;                                                                                                       // 714
        ref = false;                                                                                                   // 715
        (this.Collection.find(get("filters"), {                                                                        // 716
          sort: get("sort"),                                                                                           // 717
          fields: get("fields"),                                                                                       // 718
          skip: skip,                                                                                                  // 719
          limit: get("perPage")                                                                                        // 720
        })).forEach((function(_this) {                                                                                 // 721
          return function(o, i) {                                                                                      // 722
            if (ref) {                                                                                                 // 723
              return sub.changed(_this.id, o._id, _.object([["_" + _this.id + "_i", i + 1]]));                         // 724
            } else if (o._id === before) {                                                                             // 725
              ref = true;                                                                                              // 726
              return at = i;                                                                                           // 727
            }                                                                                                          // 728
          };                                                                                                           // 729
        })(this));                                                                                                     // 730
        return sub.changed(this.id, id, _.object([["_" + this.id + "_i", at]]));                                       // 731
      }).bind(this, sub),                                                                                              // 732
      changed: (function(sub, id, fields) {                                                                            // 733
        var e;                                                                                                         // 734
        try {                                                                                                          // 735
          return sub.changed(this.id, id, fields);                                                                     // 736
        } catch (_error) {                                                                                             // 737
          e = _error;                                                                                                  // 738
        }                                                                                                              // 739
      }).bind(this, sub),                                                                                              // 740
      removed: (function(sub, id) {                                                                                    // 741
        var e;                                                                                                         // 742
        try {                                                                                                          // 743
          return sub.removed(this.id, id);                                                                             // 744
        } catch (_error) {                                                                                             // 745
          e = _error;                                                                                                  // 746
        }                                                                                                              // 747
      }).bind(this, sub)                                                                                               // 748
    });                                                                                                                // 749
    n = 0;                                                                                                             // 750
    c.forEach((function(doc, index, cursor) {                                                                          // 751
      n++;                                                                                                             // 752
      doc["_" + this.id + "_p"] = page;                                                                                // 753
      doc["_" + this.id + "_i"] = index;                                                                               // 754
      return sub.added(this.id, doc._id, doc);                                                                         // 755
    }).bind(this));                                                                                                    // 756
    init = false;                                                                                                      // 757
    sub.onStop(function() {                                                                                            // 758
      handle.stop();                                                                                                   // 759
      return handle2.stop();                                                                                           // 760
    });                                                                                                                // 761
    this.ready();                                                                                                      // 762
    this.subscriptions.push(sub);                                                                                      // 763
    return c;                                                                                                          // 764
  };                                                                                                                   // 765
                                                                                                                       // 766
  Pages.prototype.loading = function(p) {                                                                              // 767
    if (!this.fastRender && p === this.currentPage()) {                                                                // 768
      return this.sess("ready", false);                                                                                // 769
    }                                                                                                                  // 770
  };                                                                                                                   // 771
                                                                                                                       // 772
  Pages.prototype.now = function() {                                                                                   // 773
    return (new Date()).getTime();                                                                                     // 774
  };                                                                                                                   // 775
                                                                                                                       // 776
  Pages.prototype.log = function(msg) {                                                                                // 777
    return console.log("" + this.name + " " + msg);                                                                    // 778
  };                                                                                                                   // 779
                                                                                                                       // 780
  Pages.prototype.logRequest = function(p) {                                                                           // 781
    this.timeLastRequest = this.now();                                                                                 // 782
    this.requesting = p;                                                                                               // 783
    return this.requested[p] = 1;                                                                                      // 784
  };                                                                                                                   // 785
                                                                                                                       // 786
  Pages.prototype.logResponse = function(p) {                                                                          // 787
    delete this.requested[p];                                                                                          // 788
    return this.received[p] = 1;                                                                                       // 789
  };                                                                                                                   // 790
                                                                                                                       // 791
  Pages.prototype.clearQueue = function() {                                                                            // 792
    return this.queue = [];                                                                                            // 793
  };                                                                                                                   // 794
                                                                                                                       // 795
  Pages.prototype.neighbors = function(page) {                                                                         // 796
    var d, np, pp, _i, _ref;                                                                                           // 797
    this.n = [];                                                                                                       // 798
    if (this.dataMargin === 0) {                                                                                       // 799
      return this.n;                                                                                                   // 800
    }                                                                                                                  // 801
    for (d = _i = 1, _ref = this.dataMargin; 1 <= _ref ? _i <= _ref : _i >= _ref; d = 1 <= _ref ? ++_i : --_i) {       // 802
      np = page + d;                                                                                                   // 803
      if (np <= this.sess("totalPages")) {                                                                             // 804
        this.n.push(np);                                                                                               // 805
      }                                                                                                                // 806
      pp = page - d;                                                                                                   // 807
      if (pp > 0) {                                                                                                    // 808
        this.n.push(pp);                                                                                               // 809
      }                                                                                                                // 810
    }                                                                                                                  // 811
    return this.n;                                                                                                     // 812
  };                                                                                                                   // 813
                                                                                                                       // 814
  Pages.prototype.queueNeighbors = function(page) {                                                                    // 815
    var p, _i, _len, _ref, _results;                                                                                   // 816
    _ref = this.neighbors(page);                                                                                       // 817
    _results = [];                                                                                                     // 818
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {                                                                // 819
      p = _ref[_i];                                                                                                    // 820
      if (!this.received[p] && !this.requested[p]) {                                                                   // 821
        _results.push(this.queue.push(p));                                                                             // 822
      } else {                                                                                                         // 823
        _results.push(void 0);                                                                                         // 824
      }                                                                                                                // 825
    }                                                                                                                  // 826
    return _results;                                                                                                   // 827
  };                                                                                                                   // 828
                                                                                                                       // 829
  Pages.prototype.paginationNavItem = function(label, page, disabled, active) {                                        // 830
    if (active == null) {                                                                                              // 831
      active = false;                                                                                                  // 832
    }                                                                                                                  // 833
    return {                                                                                                           // 834
      p: label,                                                                                                        // 835
      n: page,                                                                                                         // 836
      active: active ? "active" : "",                                                                                  // 837
      disabled: disabled ? "disabled" : ""                                                                             // 838
    };                                                                                                                 // 839
  };                                                                                                                   // 840
                                                                                                                       // 841
  Pages.prototype.paginationNeighbors = function() {                                                                   // 842
    var from, i, k, n, p, page, to, total, _i, _j, _len;                                                               // 843
    page = this.currentPage();                                                                                         // 844
    total = this.sess("totalPages");                                                                                   // 845
    from = page - this.paginationMargin;                                                                               // 846
    to = page + this.paginationMargin;                                                                                 // 847
    if (from < 1) {                                                                                                    // 848
      to += 1 - from;                                                                                                  // 849
      from = 1;                                                                                                        // 850
    }                                                                                                                  // 851
    if (to > total) {                                                                                                  // 852
      from -= to - total;                                                                                              // 853
      to = total;                                                                                                      // 854
    }                                                                                                                  // 855
    if (from < 1) {                                                                                                    // 856
      from = 1;                                                                                                        // 857
    }                                                                                                                  // 858
    if (to > total) {                                                                                                  // 859
      to = total;                                                                                                      // 860
    }                                                                                                                  // 861
    n = [];                                                                                                            // 862
    if (this.navShowFirst || this.navShowEdges) {                                                                      // 863
      n.push(this.paginationNavItem("«", 1, page === 1));                                                              // 864
    }                                                                                                                  // 865
    n.push(this.paginationNavItem("<", page - 1, page === 1));                                                         // 866
    for (p = _i = from; from <= to ? _i <= to : _i >= to; p = from <= to ? ++_i : --_i) {                              // 867
      n.push(this.paginationNavItem(p, p, page > total, p === page));                                                  // 868
    }                                                                                                                  // 869
    n.push(this.paginationNavItem(">", page + 1, page >= total));                                                      // 870
    if (this.navShowLast || this.navShowEdges) {                                                                       // 871
      n.push(this.paginationNavItem("»", total, page >= total));                                                       // 872
    }                                                                                                                  // 873
    for (k = _j = 0, _len = n.length; _j < _len; k = ++_j) {                                                           // 874
      i = n[k];                                                                                                        // 875
      n[k]['_p'] = this;                                                                                               // 876
    }                                                                                                                  // 877
    return n;                                                                                                          // 878
  };                                                                                                                   // 879
                                                                                                                       // 880
  Pages.prototype.onNavClick = function(n) {                                                                           // 881
    if (n <= this.sess("totalPages") && n > 0) {                                                                       // 882
      Tracker.nonreactive((function(_this) {                                                                           // 883
        return function() {                                                                                            // 884
          var cp;                                                                                                      // 885
          cp = _this.sess("currentPage");                                                                              // 886
          if (_this.received[cp]) {                                                                                    // 887
            return _this.sess("oldPage", cp);                                                                          // 888
          }                                                                                                            // 889
        };                                                                                                             // 890
      })(this));                                                                                                       // 891
      return this.sess("currentPage", n);                                                                              // 892
    }                                                                                                                  // 893
  };                                                                                                                   // 894
                                                                                                                       // 895
  Pages.prototype.setInfiniteTrigger = function() {                                                                    // 896
    return $(window).scroll((_.throttle(function() {                                                                   // 897
      var l, oh, t;                                                                                                    // 898
      t = this.infiniteTrigger;                                                                                        // 899
      oh = document.body.offsetHeight;                                                                                 // 900
      if (t > 1) {                                                                                                     // 901
        l = oh - t;                                                                                                    // 902
      } else if (t > 0) {                                                                                              // 903
        l = oh * t;                                                                                                    // 904
      } else {                                                                                                         // 905
        return;                                                                                                        // 906
      }                                                                                                                // 907
      if ((window.innerHeight + window.scrollY) >= l) {                                                                // 908
        if (this.lastPage < this.sess("totalPages")) {                                                                 // 909
          return this.sess("currentPage", this.lastPage + 1);                                                          // 910
        }                                                                                                              // 911
      }                                                                                                                // 912
    }, this.infiniteRateLimit * 1000)).bind(this));                                                                    // 913
  };                                                                                                                   // 914
                                                                                                                       // 915
  Pages.prototype.checkQueue = _.throttle(function() {                                                                 // 916
    var cp, i, k, neighbors, v, _ref, _results, _results1;                                                             // 917
    cp = this.currentPage();                                                                                           // 918
    neighbors = this.neighbors(cp);                                                                                    // 919
    if (!this.received[cp]) {                                                                                          // 920
      this.clearQueue();                                                                                               // 921
      this.requestPage(cp);                                                                                            // 922
      cp = String(cp);                                                                                                 // 923
      _ref = this.requested;                                                                                           // 924
      _results = [];                                                                                                   // 925
      for (k in _ref) {                                                                                                // 926
        v = _ref[k];                                                                                                   // 927
        if (k !== cp) {                                                                                                // 928
          if (this.subscriptions[k] != null) {                                                                         // 929
            this.subscriptions[k].stop();                                                                              // 930
            delete this.subscriptions[k];                                                                              // 931
          }                                                                                                            // 932
          _results.push(delete this.requested[k]);                                                                     // 933
        } else {                                                                                                       // 934
          _results.push(void 0);                                                                                       // 935
        }                                                                                                              // 936
      }                                                                                                                // 937
      return _results;                                                                                                 // 938
    } else if (this.queue.length) {                                                                                    // 939
      _results1 = [];                                                                                                  // 940
      while (this.queue.length > 0) {                                                                                  // 941
        i = this.queue.shift();                                                                                        // 942
        if (__indexOf.call(neighbors, i) >= 0) {                                                                       // 943
          this.requestPage(i);                                                                                         // 944
          break;                                                                                                       // 945
        } else {                                                                                                       // 946
          _results1.push(void 0);                                                                                      // 947
        }                                                                                                              // 948
      }                                                                                                                // 949
      return _results1;                                                                                                // 950
    }                                                                                                                  // 951
  }, 500);                                                                                                             // 952
                                                                                                                       // 953
  Pages.prototype.currentPage = function() {                                                                           // 954
    if (Meteor.isClient && (this.sess("currentPage") != null)) {                                                       // 955
      return this.sess("currentPage");                                                                                 // 956
    } else {                                                                                                           // 957
      return this._currentPage;                                                                                        // 958
    }                                                                                                                  // 959
  };                                                                                                                   // 960
                                                                                                                       // 961
  Pages.prototype.isReady = function() {                                                                               // 962
    return this.sess("ready");                                                                                         // 963
  };                                                                                                                   // 964
                                                                                                                       // 965
  Pages.prototype.ready = function(p) {                                                                                // 966
    if (p === true || p === this.currentPage() && (typeof Session !== "undefined" && Session !== null)) {              // 967
      return this.sess("ready", true);                                                                                 // 968
    }                                                                                                                  // 969
  };                                                                                                                   // 970
                                                                                                                       // 971
  Pages.prototype.checkInitPage = function() {                                                                         // 972
    var _ref, _ref1, _ref2;                                                                                            // 973
    if (this.init) {                                                                                                   // 974
      if (this.router) {                                                                                               // 975
        if ((_ref = Router.current()) != null) {                                                                       // 976
          if ((_ref1 = _ref.route) != null) {                                                                          // 977
            _ref1.getName();                                                                                           // 978
          }                                                                                                            // 979
        }                                                                                                              // 980
        try {                                                                                                          // 981
          this.initPage = parseInt((_ref2 = Router.current().route.params(location.href)) != null ? _ref2.page : void 0) || 1;
          this.init = false;                                                                                           // 983
        } catch (_error) {                                                                                             // 984
          return;                                                                                                      // 985
        }                                                                                                              // 986
      } else {                                                                                                         // 987
        this.initPage = 1;                                                                                             // 988
        this.init = false;                                                                                             // 989
      }                                                                                                                // 990
    }                                                                                                                  // 991
    this.sess("oldPage", this.initPage);                                                                               // 992
    return this.sess("currentPage", this.initPage);                                                                    // 993
  };                                                                                                                   // 994
                                                                                                                       // 995
  Pages.prototype.getPage = function(page) {                                                                           // 996
    var c, n, total;                                                                                                   // 997
    if (Meteor.isClient) {                                                                                             // 998
      if (page == null) {                                                                                              // 999
        page = this.currentPage();                                                                                     // 1000
      }                                                                                                                // 1001
      page = parseInt(page);                                                                                           // 1002
      if (page === NaN) {                                                                                              // 1003
        return;                                                                                                        // 1004
      }                                                                                                                // 1005
      total = this.sess("totalPages");                                                                                 // 1006
      if (total === 0) {                                                                                               // 1007
        return this.ready(true);                                                                                       // 1008
      }                                                                                                                // 1009
      if (page <= total) {                                                                                             // 1010
        this.requestPage(page);                                                                                        // 1011
        this.queueNeighbors(page);                                                                                     // 1012
        this.checkQueue();                                                                                             // 1013
      }                                                                                                                // 1014
      if (this.infinite) {                                                                                             // 1015
        n = this.PaginatedCollection.find({}, {                                                                        // 1016
          fields: this.fields,                                                                                         // 1017
          sort: this.sort                                                                                              // 1018
        }).count();                                                                                                    // 1019
        c = this.PaginatedCollection.find({}, {                                                                        // 1020
          fields: this.fields,                                                                                         // 1021
          sort: this.sort,                                                                                             // 1022
          skip: this.infiniteItemsLimit !== Infinity && n > this.infiniteItemsLimit ? n - this.infiniteItemsLimit : 0,
          limit: this.infiniteItemsLimit                                                                               // 1024
        });                                                                                                            // 1025
      } else {                                                                                                         // 1026
        c = this.PaginatedCollection.find(_.object([["_" + this.id + "_p", page]]), {                                  // 1027
          fields: this.fields,                                                                                         // 1028
          sort: _.object([["_" + this.id + "_i", 1]])                                                                  // 1029
        });                                                                                                            // 1030
        c.observeChanges({                                                                                             // 1031
          added: (function(_this) {                                                                                    // 1032
            return function() {                                                                                        // 1033
              return _this.countPages();                                                                               // 1034
            };                                                                                                         // 1035
          })(this),                                                                                                    // 1036
          removed: (function(_this) {                                                                                  // 1037
            return function() {                                                                                        // 1038
              return _this.countPages();                                                                               // 1039
            };                                                                                                         // 1040
          })(this)                                                                                                     // 1041
        });                                                                                                            // 1042
      }                                                                                                                // 1043
      return c.fetch();                                                                                                // 1044
    }                                                                                                                  // 1045
  };                                                                                                                   // 1046
                                                                                                                       // 1047
  Pages.prototype.requestPage = function(page) {                                                                       // 1048
    if (!page || this.requested[page] || this.received[page]) {                                                        // 1049
      return;                                                                                                          // 1050
    }                                                                                                                  // 1051
    this.logRequest(page);                                                                                             // 1052
    return Meteor.defer((function(page) {                                                                              // 1053
      return this.subscriptions[page] = Meteor.subscribe(this.id, page, {                                              // 1054
        onReady: (function(page) {                                                                                     // 1055
          return this.onPage(page);                                                                                    // 1056
        }).bind(this, page),                                                                                           // 1057
        onError: (function(_this) {                                                                                    // 1058
          return function(e) {                                                                                         // 1059
            return _this.error(e.message);                                                                             // 1060
          };                                                                                                           // 1061
        })(this)                                                                                                       // 1062
      });                                                                                                              // 1063
    }).bind(this, page));                                                                                              // 1064
  };                                                                                                                   // 1065
                                                                                                                       // 1066
  Pages.prototype.onPage = function(page) {                                                                            // 1067
    this.logResponse(page);                                                                                            // 1068
    this.ready(page);                                                                                                  // 1069
    if (this.infinite) {                                                                                               // 1070
      this.lastPage = page;                                                                                            // 1071
    }                                                                                                                  // 1072
    this.countPages();                                                                                                 // 1073
    return this.checkQueue();                                                                                          // 1074
  };                                                                                                                   // 1075
                                                                                                                       // 1076
  return Pages;                                                                                                        // 1077
                                                                                                                       // 1078
})();                                                                                                                  // 1079
                                                                                                                       // 1080
Meteor.Pagination = Pages;                                                                                             // 1081
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 1083
}).call(this);                                                                                                         // 1084
                                                                                                                       // 1085
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['alethes:pages'] = {};

})();

//# sourceMappingURL=alethes_pages.js.map
