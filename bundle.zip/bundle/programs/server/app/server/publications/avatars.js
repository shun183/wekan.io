(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/avatars.js                                      //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('my-avatars', function () {                             // 1
  return Avatars.find({ userId: this.userId });                        // 2
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=avatars.js.map
