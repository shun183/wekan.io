(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/import.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var DateString = Match.Where(function (dateAsString) {                 // 1
  check(dateAsString, String);                                         // 2
  return moment(dateAsString, moment.ISO_8601).isValid();              // 3
});                                                                    //
                                                                       //
var TrelloCreator = (function () {                                     //
  function TrelloCreator(data) {                                       // 7
    babelHelpers.classCallCheck(this, TrelloCreator);                  //
                                                                       //
    // we log current date, to use the same timestamp for all our actions.
    // this helps to retrieve all elements performed by the same import.
    this._nowDate = new Date();                                        // 10
    // The object creation dates, indexed by Trello id                 //
    // (so we only parse actions once!)                                //
    this.createdAt = {                                                 // 13
      board: null,                                                     // 14
      cards: {},                                                       // 15
      lists: {}                                                        // 16
    };                                                                 //
    // The object creator Trello Id, indexed by the object Trello id   //
    // (so we only parse actions once!)                                //
    this.createdBy = {                                                 // 20
      cards: {} };                                                     // 21
                                                                       //
    // Map of labels Trello ID => Wekan ID                             //
    // only cards have a field for that                                //
    this.labels = {};                                                  // 25
    // Map of lists Trello ID => Wekan ID                              //
    this.lists = {};                                                   // 27
    // The comments, indexed by Trello card id (to map when importing cards)
    this.comments = {};                                                // 29
    // the members, indexed by Trello member id => Wekan user ID       //
    this.members = data.membersMapping ? data.membersMapping : {};     // 31
                                                                       //
    // maps a trelloCardId to an array of trelloAttachments            //
    this.attachments = {};                                             // 34
  }                                                                    //
                                                                       //
  /**                                                                  //
   * If dateString is provided,                                        //
   * return the Date it represents.                                    //
   * If not, will return the date when it was first called.            //
   * This is useful for us, as we want all import operations to        //
   * have the exact same date for easier later retrieval.              //
   *                                                                   //
   * @param {String} dateString a properly formatted Date              //
   */                                                                  //
                                                                       //
  TrelloCreator.prototype._now = (function () {                        // 6
    function _now(dateString) {                                        // 46
      if (dateString) {                                                // 47
        return new Date(dateString);                                   // 48
      }                                                                //
      if (!this._nowDate) {                                            // 50
        this._nowDate = new Date();                                    // 51
      }                                                                //
      return this._nowDate;                                            // 53
    }                                                                  //
                                                                       //
    return _now;                                                       //
  })();                                                                //
                                                                       //
  /**                                                                  //
   * if trelloUserId is provided and we have a mapping,                //
   * return it.                                                        //
   * Otherwise return current logged user.                             //
   * @param trelloUserId                                               //
   * @private                                                          //
     */                                                                //
                                                                       //
  TrelloCreator.prototype._user = (function () {                       // 6
    function _user(trelloUserId) {                                     // 63
      if (trelloUserId && this.members[trelloUserId]) {                // 64
        return this.members[trelloUserId];                             // 65
      }                                                                //
      return Meteor.userId();                                          // 67
    }                                                                  //
                                                                       //
    return _user;                                                      //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.checkActions = (function () {                // 6
    function checkActions(trelloActions) {                             // 70
      check(trelloActions, [Match.ObjectIncluding({                    // 71
        data: Object,                                                  // 72
        date: DateString,                                              // 73
        type: String                                                   // 74
      })]);                                                            //
      // XXX we could perform more thorough checks based on action type
    }                                                                  //
                                                                       //
    return checkActions;                                               //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.checkBoard = (function () {                  // 6
    function checkBoard(trelloBoard) {                                 // 79
      check(trelloBoard, Match.ObjectIncluding({                       // 80
        closed: Boolean,                                               // 81
        name: String,                                                  // 82
        prefs: Match.ObjectIncluding({                                 // 83
          // XXX refine control by validating 'background' against a list of
          // allowed values (is it worth the maintenance?)             //
          background: String,                                          // 86
          permissionLevel: Match.Where(function (value) {              // 87
            return ['org', 'private', 'public'].indexOf(value) >= 0;   // 88
          })                                                           //
        })                                                             //
      }));                                                             //
    }                                                                  //
                                                                       //
    return checkBoard;                                                 //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.checkCards = (function () {                  // 6
    function checkCards(trelloCards) {                                 // 94
      check(trelloCards, [Match.ObjectIncluding({                      // 95
        closed: Boolean,                                               // 96
        dateLastActivity: DateString,                                  // 97
        desc: String,                                                  // 98
        idLabels: [String],                                            // 99
        idMembers: [String],                                           // 100
        name: String,                                                  // 101
        pos: Number                                                    // 102
      })]);                                                            //
    }                                                                  //
                                                                       //
    return checkCards;                                                 //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.checkLabels = (function () {                 // 6
    function checkLabels(trelloLabels) {                               // 106
      check(trelloLabels, [Match.ObjectIncluding({                     // 107
        // XXX refine control by validating 'color' against a list of allowed
        // values (is it worth the maintenance?)                       //
        color: String,                                                 // 110
        name: String                                                   // 111
      })]);                                                            //
    }                                                                  //
                                                                       //
    return checkLabels;                                                //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.checkLists = (function () {                  // 6
    function checkLists(trelloLists) {                                 // 115
      check(trelloLists, [Match.ObjectIncluding({                      // 116
        closed: Boolean,                                               // 117
        name: String                                                   // 118
      })]);                                                            //
    }                                                                  //
                                                                       //
    return checkLists;                                                 //
  })();                                                                //
                                                                       //
  // You must call parseActions before calling this one.               //
                                                                       //
  TrelloCreator.prototype.createBoardAndLabels = (function () {        // 6
    function createBoardAndLabels(trelloBoard) {                       // 123
      var _this = this;                                                //
                                                                       //
      var boardToCreate = {                                            // 124
        archived: trelloBoard.closed,                                  // 125
        color: this.getColor(trelloBoard.prefs.background),            // 126
        // very old boards won't have a creation activity so no creation date
        createdAt: this._now(this.createdAt.board),                    // 128
        labels: [],                                                    // 129
        members: [{                                                    // 130
          userId: Meteor.userId(),                                     // 131
          isAdmin: true,                                               // 132
          isActive: true                                               // 133
        }],                                                            //
        permission: this.getPermission(trelloBoard.prefs.permissionLevel),
        slug: getSlug(trelloBoard.name) || 'board',                    // 136
        stars: 0,                                                      // 137
        title: trelloBoard.name                                        // 138
      };                                                               //
      // now add other members                                         //
      if (trelloBoard.memberships) {                                   // 141
        trelloBoard.memberships.forEach(function (trelloMembership) {  // 142
          var trelloId = trelloMembership.idMember;                    // 143
          // do we have a mapping?                                     //
          if (_this.members[trelloId]) {                               // 145
            (function () {                                             //
              var wekanId = _this.members[trelloId];                   // 146
              // do we already have it in our list?                    //
              var wekanMember = boardToCreate.members.find(function (wekanMember) {
                return wekanMember.userId === wekanId;                 //
              });                                                      //
              if (wekanMember) {                                       // 149
                // we're already mapped, but maybe with lower rights   //
                if (!wekanMember.isAdmin) {                            // 151
                  wekanMember.isAdmin = _this.getAdmin(trelloMembership.memberType);
                }                                                      //
              } else {                                                 //
                boardToCreate.members.push({                           // 155
                  userId: wekanId,                                     // 156
                  isAdmin: _this.getAdmin(trelloMembership.memberType),
                  isActive: true                                       // 158
                });                                                    //
              }                                                        //
            })();                                                      //
          }                                                            //
        });                                                            //
      }                                                                //
      trelloBoard.labels.forEach(function (label) {                    // 164
        var labelToCreate = {                                          // 165
          _id: Random.id(6),                                           // 166
          color: label.color,                                          // 167
          name: label.name                                             // 168
        };                                                             //
        // We need to remember them by Trello ID, as this is the only ref we have
        // when importing cards.                                       //
        _this.labels[label.id] = labelToCreate._id;                    // 172
        boardToCreate.labels.push(labelToCreate);                      // 173
      });                                                              //
      var boardId = Boards.direct.insert(boardToCreate);               // 175
      Boards.direct.update(boardId, { $set: { modifiedAt: this._now() } });
      // log activity                                                  //
      Activities.direct.insert({                                       // 178
        activityType: 'importBoard',                                   // 179
        boardId: boardId,                                              // 180
        createdAt: this._now(),                                        // 181
        source: {                                                      // 182
          id: trelloBoard.id,                                          // 183
          system: 'Trello',                                            // 184
          url: trelloBoard.url                                         // 185
        },                                                             //
        // We attribute the import to current user,                    //
        // not the author from the original object.                    //
        userId: this._user()                                           // 189
      });                                                              //
      return boardId;                                                  // 191
    }                                                                  //
                                                                       //
    return createBoardAndLabels;                                       //
  })();                                                                //
                                                                       //
  /**                                                                  //
   * Create the Wekan cards corresponding to the supplied Trello cards,
   * as well as all linked data: activities, comments, and attachments
   * @param trelloCards                                                //
   * @param boardId                                                    //
   * @returns {Array}                                                  //
   */                                                                  //
                                                                       //
  TrelloCreator.prototype.createCards = (function () {                 // 6
    function createCards(trelloCards, boardId) {                       // 201
      var _this2 = this;                                               //
                                                                       //
      var result = [];                                                 // 202
      trelloCards.forEach(function (card) {                            // 203
        var cardToCreate = {                                           // 204
          archived: card.closed,                                       // 205
          boardId: boardId,                                            // 206
          // very old boards won't have a creation activity so no creation date
          createdAt: _this2._now(_this2.createdAt.cards[card.id]),     // 208
          dateLastActivity: _this2._now(),                             // 209
          description: card.desc,                                      // 210
          listId: _this2.lists[card.idList],                           // 211
          sort: card.pos,                                              // 212
          title: card.name,                                            // 213
          // we attribute the card to its creator if available         //
          userId: _this2._user(_this2.createdBy.cards[card.id])        // 215
        };                                                             //
        // add labels                                                  //
        if (card.idLabels) {                                           // 218
          cardToCreate.labelIds = card.idLabels.map(function (trelloId) {
            return _this2.labels[trelloId];                            // 220
          });                                                          //
        }                                                              //
        // add members {                                               //
        if (card.idMembers) {                                          // 224
          (function () {                                               //
            var wekanMembers = [];                                     // 225
            // we can't just map, as some members may not have been mapped
            card.idMembers.forEach(function (trelloId) {               // 227
              if (_this2.members[trelloId]) {                          // 228
                (function () {                                         //
                  var wekanId = _this2.members[trelloId];              // 229
                  // we may map multiple Trello members to the same wekan user
                  // in which case we risk adding the same user multiple times
                  if (!wekanMembers.find(function (wId) {              // 232
                    return wId === wekanId;                            //
                  })) {                                                //
                    wekanMembers.push(wekanId);                        // 233
                  }                                                    //
                })();                                                  //
              }                                                        //
              return true;                                             // 236
            });                                                        //
            if (wekanMembers.length > 0) {                             // 238
              cardToCreate.members = wekanMembers;                     // 239
            }                                                          //
          })();                                                        //
        }                                                              //
        // insert card                                                 //
        var cardId = Cards.direct.insert(cardToCreate);                // 243
        // log activity                                                //
        Activities.direct.insert({                                     // 245
          activityType: 'importCard',                                  // 246
          boardId: boardId,                                            // 247
          cardId: cardId,                                              // 248
          createdAt: _this2._now(),                                    // 249
          listId: cardToCreate.listId,                                 // 250
          source: {                                                    // 251
            id: card.id,                                               // 252
            system: 'Trello',                                          // 253
            url: card.url                                              // 254
          },                                                           //
          // we attribute the import to current user,                  //
          // not the author of the original card                       //
          userId: _this2._user()                                       // 258
        });                                                            //
        // add comments                                                //
        var comments = _this2.comments[card.id];                       // 261
        if (comments) {                                                // 262
          comments.forEach(function (comment) {                        // 263
            var commentToCreate = {                                    // 264
              boardId: boardId,                                        // 265
              cardId: cardId,                                          // 266
              createdAt: _this2._now(comment.date),                    // 267
              text: comment.data.text,                                 // 268
              // we attribute the comment to the original author, default to current user
              userId: _this2._user(comment.memberCreator.id)           // 270
            };                                                         //
            // dateLastActivity will be set from activity insert, no need to
            // update it ourselves                                     //
            var commentId = CardComments.direct.insert(commentToCreate);
            Activities.direct.insert({                                 // 275
              activityType: 'addComment',                              // 276
              boardId: commentToCreate.boardId,                        // 277
              cardId: commentToCreate.cardId,                          // 278
              commentId: commentId,                                    // 279
              createdAt: _this2._now(commentToCreate.createdAt),       // 280
              // we attribute the addComment (not the import)          //
              // to the original author - it is needed by some UI elements.
              userId: commentToCreate.userId                           // 283
            });                                                        //
          });                                                          //
        }                                                              //
        var attachments = _this2.attachments[card.id];                 // 287
        var trelloCoverId = card.idAttachmentCover;                    // 288
        if (attachments) {                                             // 289
          attachments.forEach(function (att) {                         // 290
            var file = new FS.File();                                  // 291
            // Simulating file.attachData on the client generates multiple errors
            // - HEAD returns null, which causes exception down the line
            // - the template then tries to display the url to the attachment which causes other errors
            // so we make it server only, and let UI catch up once it is done, forget about latency comp.
            if (Meteor.isServer) {                                     // 296
              file.attachData(att.url, function (error) {              // 297
                file.boardId = boardId;                                // 298
                file.cardId = cardId;                                  // 299
                if (error) {                                           // 300
                  throw error;                                         // 301
                } else {                                               //
                  var wekanAtt = Attachments.insert(file, function () {
                    // we do nothing                                   //
                  });                                                  //
                  //                                                   //
                  if (trelloCoverId === att.id) {                      // 307
                    Cards.direct.update(cardId, { $set: { coverId: wekanAtt._id } });
                  }                                                    //
                }                                                      //
              });                                                      //
            }                                                          //
            // todo XXX set cover - if need be                         //
          });                                                          //
        }                                                              //
        result.push(cardId);                                           // 316
      });                                                              //
      return result;                                                   // 318
    }                                                                  //
                                                                       //
    return createCards;                                                //
  })();                                                                //
                                                                       //
  // Create labels if they do not exist and load this.labels.          //
                                                                       //
  TrelloCreator.prototype.createLabels = (function () {                // 6
    function createLabels(trelloLabels, board) {                       // 322
      var _this3 = this;                                               //
                                                                       //
      trelloLabels.forEach(function (label) {                          // 323
        var color = label.color;                                       // 324
        var name = label.name;                                         // 325
        var existingLabel = board.getLabel(name, color);               // 326
        if (existingLabel) {                                           // 327
          _this3.labels[label.id] = existingLabel._id;                 // 328
        } else {                                                       //
          var idLabelCreated = board.pushLabel(name, color);           // 330
          _this3.labels[label.id] = idLabelCreated;                    // 331
        }                                                              //
      });                                                              //
    }                                                                  //
                                                                       //
    return createLabels;                                               //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.createLists = (function () {                 // 6
    function createLists(trelloLists, boardId) {                       // 336
      var _this4 = this;                                               //
                                                                       //
      trelloLists.forEach(function (list) {                            // 337
        var listToCreate = {                                           // 338
          archived: list.closed,                                       // 339
          boardId: boardId,                                            // 340
          // We are being defensing here by providing a default date (now) if the
          // creation date wasn't found on the action log. This happen on old
          // Trello boards (eg from 2013) that didn't log the 'createList' action
          // we require.                                               //
          createdAt: _this4._now(_this4.createdAt.lists[list.id]),     // 345
          title: list.name                                             // 346
        };                                                             //
        var listId = Lists.direct.insert(listToCreate);                // 348
        Lists.direct.update(listId, { $set: { 'updatedAt': _this4._now() } });
        _this4.lists[list.id] = listId;                                // 350
        // log activity                                                //
        Activities.direct.insert({                                     // 352
          activityType: 'importList',                                  // 353
          boardId: boardId,                                            // 354
          createdAt: _this4._now(),                                    // 355
          listId: listId,                                              // 356
          source: {                                                    // 357
            id: list.id,                                               // 358
            system: 'Trello'                                           // 359
          },                                                           //
          // We attribute the import to current user,                  //
          // not the creator of the original object                    //
          userId: _this4._user()                                       // 363
        });                                                            //
      });                                                              //
    }                                                                  //
                                                                       //
    return createLists;                                                //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.getAdmin = (function () {                    // 6
    function getAdmin(trelloMemberType) {                              // 368
      return trelloMemberType === 'admin';                             // 369
    }                                                                  //
                                                                       //
    return getAdmin;                                                   //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.getColor = (function () {                    // 6
    function getColor(trelloColorCode) {                               // 372
      // trello color name => wekan color                              //
      var mapColors = {                                                // 374
        'blue': 'belize',                                              // 375
        'orange': 'pumpkin',                                           // 376
        'green': 'nephritis',                                          // 377
        'red': 'pomegranate',                                          // 378
        'purple': 'wisteria',                                          // 379
        'pink': 'pomegranate',                                         // 380
        'lime': 'nephritis',                                           // 381
        'sky': 'belize',                                               // 382
        'grey': 'midnight'                                             // 383
      };                                                               //
      var wekanColor = mapColors[trelloColorCode];                     // 385
      return wekanColor || Boards.simpleSchema()._schema.color.allowedValues[0];
    }                                                                  //
                                                                       //
    return getColor;                                                   //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.getPermission = (function () {               // 6
    function getPermission(trelloPermissionCode) {                     // 389
      if (trelloPermissionCode === 'public') {                         // 390
        return 'public';                                               // 391
      }                                                                //
      // Wekan does NOT have organization level, so we default both 'private' and
      // 'org' to private.                                             //
      return 'private';                                                // 395
    }                                                                  //
                                                                       //
    return getPermission;                                              //
  })();                                                                //
                                                                       //
  TrelloCreator.prototype.parseActions = (function () {                // 6
    function parseActions(trelloActions) {                             // 398
      var _this5 = this;                                               //
                                                                       //
      trelloActions.forEach(function (action) {                        // 399
        switch (action.type) {                                         // 400
          case 'addAttachmentToCard':                                  // 401
            // We have to be cautious, because the attachment could have been removed later.
            // In that case Trello still reports its addition, but removes its 'url' field.
            // So we test for that                                     //
            var trelloAttachment = action.data.attachment;             // 405
            if (trelloAttachment.url) {                                // 406
              // we cannot actually create the Wekan attachment, because we don't yet
              // have the cards to attach it to, so we store it in the instance variable.
              var trelloCardId = action.data.card.id;                  // 409
              if (!_this5.attachments[trelloCardId]) {                 // 410
                _this5.attachments[trelloCardId] = [];                 // 411
              }                                                        //
              _this5.attachments[trelloCardId].push(trelloAttachment);
            }                                                          //
            break;                                                     // 415
          case 'commentCard':                                          // 415
            var id = action.data.card.id;                              // 417
            if (_this5.comments[id]) {                                 // 418
              _this5.comments[id].push(action);                        // 419
            } else {                                                   //
              _this5.comments[id] = [action];                          // 421
            }                                                          //
            break;                                                     // 423
          case 'createBoard':                                          // 423
            _this5.createdAt.board = action.date;                      // 425
            break;                                                     // 426
          case 'createCard':                                           // 426
            var cardId = action.data.card.id;                          // 428
            _this5.createdAt.cards[cardId] = action.date;              // 429
            _this5.createdBy.cards[cardId] = action.idMemberCreator;   // 430
            break;                                                     // 431
          case 'createList':                                           // 431
            var listId = action.data.list.id;                          // 433
            _this5.createdAt.lists[listId] = action.date;              // 434
            break;                                                     // 435
          default:                                                     // 435
            // do nothing                                              //
            break;                                                     // 438
        }                                                              // 438
      });                                                              //
    }                                                                  //
                                                                       //
    return parseActions;                                               //
  })();                                                                //
                                                                       //
  return TrelloCreator;                                                //
})();                                                                  //
                                                                       //
Meteor.methods({                                                       // 444
  importTrelloBoard: function (trelloBoard, data) {                    // 445
    var trelloCreator = new TrelloCreator(data);                       // 446
                                                                       //
    // 1. check all parameters are ok from a syntax point of view      //
    try {                                                              // 449
      check(data, {                                                    // 450
        membersMapping: Match.Optional(Object)                         // 451
      });                                                              //
      trelloCreator.checkActions(trelloBoard.actions);                 // 453
      trelloCreator.checkBoard(trelloBoard);                           // 454
      trelloCreator.checkLabels(trelloBoard.labels);                   // 455
      trelloCreator.checkLists(trelloBoard.lists);                     // 456
      trelloCreator.checkCards(trelloBoard.cards);                     // 457
    } catch (e) {                                                      //
      throw new Meteor.Error('error-json-schema');                     // 459
    }                                                                  //
                                                                       //
    // 2. check parameters are ok from a business point of view (exist &
    // authorized) nothing to check, everyone can import boards in their account
                                                                       //
    // 3. create all elements                                          //
    trelloCreator.parseActions(trelloBoard.actions);                   // 466
    var boardId = trelloCreator.createBoardAndLabels(trelloBoard);     // 467
    trelloCreator.createLists(trelloBoard.lists, boardId);             // 468
    trelloCreator.createCards(trelloBoard.cards, boardId);             // 469
    // XXX add members                                                 //
    return boardId;                                                    // 471
  },                                                                   //
                                                                       //
  importTrelloCard: function (trelloCard, data) {                      // 474
    var trelloCreator = new TrelloCreator(data);                       // 475
                                                                       //
    // 1. check parameters are ok from a syntax point of view          //
    try {                                                              // 478
      check(data, {                                                    // 479
        listId: String,                                                // 480
        sortIndex: Number,                                             // 481
        membersMapping: Match.Optional(Object)                         // 482
      });                                                              //
      trelloCreator.checkCards([trelloCard]);                          // 484
      trelloCreator.checkLabels(trelloCard.labels);                    // 485
      trelloCreator.checkActions(trelloCard.actions);                  // 486
    } catch (e) {                                                      //
      throw new Meteor.Error('error-json-schema');                     // 488
    }                                                                  //
                                                                       //
    // 2. check parameters are ok from a business point of view (exist &
    // authorized)                                                     //
    var list = Lists.findOne(data.listId);                             // 493
    if (!list) {                                                       // 494
      throw new Meteor.Error('error-list-doesNotExist');               // 495
    }                                                                  //
    if (Meteor.isServer) {                                             // 497
      if (!allowIsBoardMember(Meteor.userId(), Boards.findOne(list.boardId))) {
        throw new Meteor.Error('error-board-notAMember');              // 499
      }                                                                //
    }                                                                  //
                                                                       //
    // 3. create all elements                                          //
    trelloCreator.lists[trelloCard.idList] = data.listId;              // 504
    trelloCreator.parseActions(trelloCard.actions);                    // 505
    var board = list.board();                                          // 506
    trelloCreator.createLabels(trelloCard.labels, board);              // 507
    var cardIds = trelloCreator.createCards([trelloCard], board._id);  // 508
    return cardIds[0];                                                 // 509
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=import.js.map
