(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Emoji;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/seriousm_emoji-continued/packages/seriousm_emoji-continu //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['seriousm:emoji-continued'] = {
  Emoji: Emoji
};

})();

//# sourceMappingURL=seriousm_emoji-continued.js.map
