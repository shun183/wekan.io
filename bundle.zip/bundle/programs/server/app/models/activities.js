(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/activities.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Activities don't need a schema because they are always set from the a trusted
// environment - the server - and there is no risk that a user change the logic
// we use with this collection. Moreover using a schema for this collection
// would be difficult (different activities have different fields) and wouldn't
// bring any direct advantage.                                         //
//                                                                     //
// XXX The activities API is not so nice and need some functionalities. For
// instance if a user archive a card, and un-archive it a few seconds later we
// should remove both activities assuming it was an error the user decided to
// revert.                                                             //
Activities = new Mongo.Collection('activities');                       // 11
                                                                       //
Activities.helpers({                                                   // 13
  board: function () {                                                 // 14
    return Boards.findOne(this.boardId);                               // 15
  },                                                                   //
  user: function () {                                                  // 17
    return Users.findOne(this.userId);                                 // 18
  },                                                                   //
  member: function () {                                                // 20
    return Users.findOne(this.memberId);                               // 21
  },                                                                   //
  list: function () {                                                  // 23
    return Lists.findOne(this.listId);                                 // 24
  },                                                                   //
  oldList: function () {                                               // 26
    return Lists.findOne(this.oldListId);                              // 27
  },                                                                   //
  card: function () {                                                  // 29
    return Cards.findOne(this.cardId);                                 // 30
  },                                                                   //
  comment: function () {                                               // 32
    return CardComments.findOne(this.commentId);                       // 33
  },                                                                   //
  attachment: function () {                                            // 35
    return Attachments.findOne(this.attachmentId);                     // 36
  }                                                                    //
});                                                                    //
                                                                       //
Activities.before.insert(function (userId, doc) {                      // 40
  doc.createdAt = new Date();                                          // 41
});                                                                    //
                                                                       //
// For efficiency create an index on the date of creation.             //
if (Meteor.isServer) {                                                 // 45
  Meteor.startup(function () {                                         // 46
    Activities._collection._ensureIndex({                              // 47
      createdAt: -1                                                    // 48
    });                                                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=activities.js.map
