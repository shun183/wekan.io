(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mquandalle_mousetrap-bindglobal/packages/mquandalle_mous //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mquandalle:mousetrap-bindglobal'] = {};

})();

//# sourceMappingURL=mquandalle_mousetrap-bindglobal.js.map
