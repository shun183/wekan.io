(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/lists.js                                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Lists = new Mongo.Collection('lists');                                 // 1
                                                                       //
Lists.attachSchema(new SimpleSchema({                                  // 3
  title: {                                                             // 4
    type: String                                                       // 5
  },                                                                   //
  archived: {                                                          // 7
    type: Boolean                                                      // 8
  },                                                                   //
  boardId: {                                                           // 10
    type: String                                                       // 11
  },                                                                   //
  createdAt: {                                                         // 13
    type: Date,                                                        // 14
    denyUpdate: true                                                   // 15
  },                                                                   //
  sort: {                                                              // 17
    type: Number,                                                      // 18
    decimal: true,                                                     // 19
    // XXX We should probably provide a default                        //
    optional: true                                                     // 21
  },                                                                   //
  updatedAt: {                                                         // 23
    type: Date,                                                        // 24
    denyInsert: true,                                                  // 25
    optional: true                                                     // 26
  }                                                                    //
}));                                                                   //
                                                                       //
Lists.allow({                                                          // 30
  insert: function (userId, doc) {                                     // 31
    return allowIsBoardMember(userId, Boards.findOne(doc.boardId));    // 32
  },                                                                   //
  update: function (userId, doc) {                                     // 34
    return allowIsBoardMember(userId, Boards.findOne(doc.boardId));    // 35
  },                                                                   //
  remove: function (userId, doc) {                                     // 37
    return allowIsBoardMember(userId, Boards.findOne(doc.boardId));    // 38
  },                                                                   //
  fetch: ['boardId']                                                   // 40
});                                                                    //
                                                                       //
Lists.helpers({                                                        // 43
  cards: function () {                                                 // 44
    return Cards.find(Filter.mongoSelector({                           // 45
      listId: this._id,                                                // 46
      archived: false                                                  // 47
    }), { sort: ['sort'] });                                           //
  },                                                                   //
                                                                       //
  allCards: function () {                                              // 51
    return Cards.find({ listId: this._id });                           // 52
  },                                                                   //
                                                                       //
  board: function () {                                                 // 55
    return Boards.findOne(this.boardId);                               // 56
  }                                                                    //
});                                                                    //
                                                                       //
Lists.mutations({                                                      // 60
  rename: function (title) {                                           // 61
    return { $set: { title: title } };                                 // 62
  },                                                                   //
                                                                       //
  archive: function () {                                               // 65
    return { $set: { archived: true } };                               // 66
  },                                                                   //
                                                                       //
  restore: function () {                                               // 69
    return { $set: { archived: false } };                              // 70
  }                                                                    //
});                                                                    //
                                                                       //
Lists.hookOptions.after.update = { fetchPrevious: false };             // 74
                                                                       //
Lists.before.insert(function (userId, doc) {                           // 76
  doc.createdAt = new Date();                                          // 77
  doc.archived = false;                                                // 78
  if (!doc.userId) doc.userId = userId;                                // 79
});                                                                    //
                                                                       //
Lists.before.update(function (userId, doc, fieldNames, modifier) {     // 83
  modifier.$set = modifier.$set || {};                                 // 84
  modifier.$set.modifiedAt = new Date();                               // 85
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 88
  Lists.after.insert(function (userId, doc) {                          // 89
    Activities.insert({                                                // 90
      userId: userId,                                                  // 91
      type: 'list',                                                    // 92
      activityType: 'createList',                                      // 93
      boardId: doc.boardId,                                            // 94
      listId: doc._id                                                  // 95
    });                                                                //
  });                                                                  //
                                                                       //
  Lists.after.update(function (userId, doc) {                          // 99
    if (doc.archived) {                                                // 100
      Activities.insert({                                              // 101
        userId: userId,                                                // 102
        type: 'list',                                                  // 103
        activityType: 'archivedList',                                  // 104
        listId: doc._id,                                               // 105
        boardId: doc.boardId                                           // 106
      });                                                              //
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=lists.js.map
