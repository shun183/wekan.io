(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models/unsavedEdits.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// This collection shouldn't be manipulated directly by instead throw the
// `UnsavedEdits` API on the client.                                   //
UnsavedEditCollection = new Mongo.Collection('unsaved-edits');         // 3
                                                                       //
UnsavedEditCollection.attachSchema(new SimpleSchema({                  // 5
  fieldName: {                                                         // 6
    type: String                                                       // 7
  },                                                                   //
  docId: {                                                             // 9
    type: String                                                       // 10
  },                                                                   //
  value: {                                                             // 12
    type: String                                                       // 13
  },                                                                   //
  userId: {                                                            // 15
    type: String                                                       // 16
  }                                                                    //
}));                                                                   //
                                                                       //
if (Meteor.isServer) {                                                 // 20
  function isAuthor(userId, doc) {                                     // 21
    var fieldNames = arguments.length <= 2 || arguments[2] === undefined ? [] : arguments[2];
                                                                       //
    return userId === doc.userId && fieldNames.indexOf('userId') === -1;
  }                                                                    //
  UnsavedEditCollection.allow({                                        // 24
    insert: isAuthor,                                                  // 25
    update: isAuthor,                                                  // 26
    remove: isAuthor,                                                  // 27
    fetch: ['userId']                                                  // 28
  });                                                                  //
}                                                                      //
                                                                       //
UnsavedEditCollection.before.insert(function (userId, doc) {           // 32
  doc.userId = userId;                                                 // 33
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=unsavedEdits.js.map
