(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// config/accounts.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var passwordField = AccountsTemplates.removeField('password');         // 1
var emailField = AccountsTemplates.removeField('email');               // 2
AccountsTemplates.addFields([{                                         // 3
  _id: 'username',                                                     // 4
  type: 'text',                                                        // 5
  displayName: 'username',                                             // 6
  required: true,                                                      // 7
  minLength: 2                                                         // 8
}, emailField, passwordField]);                                        //
                                                                       //
AccountsTemplates.configure({                                          // 11
  defaultLayout: 'userFormsLayout',                                    // 12
  defaultContentRegion: 'content',                                     // 13
  confirmPassword: false,                                              // 14
  enablePasswordChange: true,                                          // 15
  sendVerificationEmail: true,                                         // 16
  showForgotPasswordLink: true,                                        // 17
  onLogoutHook: function () {                                          // 18
    var homePage = 'home';                                             // 19
    if (FlowRouter.getRouteName() === homePage) {                      // 20
      FlowRouter.reload();                                             // 21
    } else {                                                           //
      FlowRouter.go(homePage);                                         // 23
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
['signIn', 'signUp', 'resetPwd', 'forgotPwd', 'enrollAccount'].forEach(function (routeName) {
  return AccountsTemplates.configureRoute(routeName);                  //
});                                                                    //
                                                                       //
// We display the form to change the password in a popup window that already
// have a title, so we unset the title automatically displayed by useraccounts.
AccountsTemplates.configure({                                          // 33
  texts: {                                                             // 34
    title: {                                                           // 35
      changePwd: ''                                                    // 36
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
AccountsTemplates.configureRoute('changePwd', {                        // 41
  redirect: function () {                                              // 42
    // XXX We should emit a notification once we have a notification system.
    // Currently the user has no indication that his modification has been
    // applied.                                                        //
    Popup.back();                                                      // 46
  }                                                                    //
});                                                                    //
                                                                       //
if (Meteor.isServer) {                                                 // 50
  if (process.env.MAIL_FROM) {                                         // 51
    Accounts.emailTemplates.from = process.env.MAIL_FROM;              // 52
  }                                                                    //
                                                                       //
  ['resetPassword-subject', 'resetPassword-text', 'verifyEmail-subject', 'verifyEmail-text', 'enrollAccount-subject', 'enrollAccount-text'].forEach(function (str) {
    var _str$split = str.split('-');                                   //
                                                                       //
    var templateName = _str$split[0];                                  //
    var field = _str$split[1];                                         //
                                                                       //
    Accounts.emailTemplates[templateName][field] = function (user, url) {
      return TAPi18n.__('email-' + str, {                              // 58
        url: url,                                                      // 59
        user: user.getName(),                                          // 60
        siteName: Accounts.emailTemplates.siteName                     // 61
      }, user.getLanguage());                                          //
    };                                                                 //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=accounts.js.map
