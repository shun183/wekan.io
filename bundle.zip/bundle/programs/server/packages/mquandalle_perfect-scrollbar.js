(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mquandalle_perfect-scrollbar/packages/mquandalle_perfect //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mquandalle:perfect-scrollbar'] = {};

})();

//# sourceMappingURL=mquandalle_perfect-scrollbar.js.map
