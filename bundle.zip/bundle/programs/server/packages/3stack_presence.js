(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var Random = Package.random.Random;

/* Package-scope variables */
var __coffeescriptShare, presences, Presence;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/3stack_presence/packages/3stack_presence.js                                    //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
(function () {                                                                             // 1
                                                                                           // 2
//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/3stack:presence/lib/collection.coffee.js                                    //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                           // 10
                                                                                           // 11
presences = new Mongo.Collection('presences');                                             // 12
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                           // 14
}).call(this);                                                                             // 15
                                                                                           // 16
                                                                                           // 17
                                                                                           // 18
                                                                                           // 19
                                                                                           // 20
                                                                                           // 21
(function () {                                                                             // 22
                                                                                           // 23
//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/3stack:presence/lib/heartbeat.coffee.js                                     //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Heartbeat,                                                                             // 31
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };      // 32
                                                                                           // 33
Heartbeat = (function() {                                                                  // 34
  function Heartbeat(interval) {                                                           // 35
    this.interval = interval;                                                              // 36
    this.tock = __bind(this.tock, this);                                                   // 37
    this.tick = __bind(this.tick, this);                                                   // 38
    this.heartbeat = null;                                                                 // 39
    this.action = null;                                                                    // 40
    this.started = false;                                                                  // 41
  }                                                                                        // 42
                                                                                           // 43
  Heartbeat.prototype.start = function(action) {                                           // 44
    this.action = action;                                                                  // 45
    if (this.started) {                                                                    // 46
      return;                                                                              // 47
    }                                                                                      // 48
    this.started = true;                                                                   // 49
    this._enqueue();                                                                       // 50
  };                                                                                       // 51
                                                                                           // 52
  Heartbeat.prototype.stop = function() {                                                  // 53
    this.started = false;                                                                  // 54
    this.action = null;                                                                    // 55
    this._dequeue();                                                                       // 56
  };                                                                                       // 57
                                                                                           // 58
  Heartbeat.prototype.tick = function() {                                                  // 59
    if (typeof this.action === "function") {                                               // 60
      this.action();                                                                       // 61
    }                                                                                      // 62
  };                                                                                       // 63
                                                                                           // 64
  Heartbeat.prototype.tock = function() {                                                  // 65
    if (!this.started) {                                                                   // 66
      return;                                                                              // 67
    }                                                                                      // 68
    this._dequeue();                                                                       // 69
    this._enqueue();                                                                       // 70
  };                                                                                       // 71
                                                                                           // 72
  Heartbeat.prototype._dequeue = function() {                                              // 73
    if (this.heartbeat != null) {                                                          // 74
      Meteor.clearTimeout(this.heartbeat);                                                 // 75
      this.heartbeat = null;                                                               // 76
    }                                                                                      // 77
  };                                                                                       // 78
                                                                                           // 79
  Heartbeat.prototype._enqueue = function() {                                              // 80
    this.heartbeat = Meteor.setTimeout(this.tick, this.interval);                          // 81
  };                                                                                       // 82
                                                                                           // 83
  return Heartbeat;                                                                        // 84
                                                                                           // 85
})();                                                                                      // 86
                                                                                           // 87
this.Heartbeat = Heartbeat;                                                                // 88
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                           // 90
}).call(this);                                                                             // 91
                                                                                           // 92
                                                                                           // 93
                                                                                           // 94
                                                                                           // 95
                                                                                           // 96
                                                                                           // 97
(function () {                                                                             // 98
                                                                                           // 99
//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/3stack:presence/lib/server/monitor.coffee.js                                //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ServerMonitor,                                                                         // 107
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };      // 108
                                                                                           // 109
ServerMonitor = (function() {                                                              // 110
  function ServerMonitor() {                                                               // 111
    this.pulse = __bind(this.pulse, this);                                                 // 112
    this.onStartup = __bind(this.onStartup, this);                                         // 113
    this.serverId = Random.id();                                                           // 114
    this.options = {                                                                       // 115
      heartbeat: false,                                                                    // 116
      timeout: false,                                                                      // 117
      hash: null,                                                                          // 118
      salt: ""                                                                             // 119
    };                                                                                     // 120
    this.heartbeat = null;                                                                 // 121
    this.started = false;                                                                  // 122
    Meteor.startup(this.onStartup);                                                        // 123
  }                                                                                        // 124
                                                                                           // 125
  ServerMonitor.prototype.configure = function(options) {                                  // 126
    if (this.started) {                                                                    // 127
      throw new Error("Must configure Presence on the server before Meteor.startup()");    // 128
    }                                                                                      // 129
    _.extend(this.options, options);                                                       // 130
    if (this.options.heartbeat === false) {                                                // 131
      this.heartbeat = null;                                                               // 132
    } else {                                                                               // 133
      if (!this.options.timeout) {                                                         // 134
        this.options.timeout = this.options.heartbeat * 5;                                 // 135
      }                                                                                    // 136
      this.heartbeat = new Heartbeat(this.options.heartbeat);                              // 137
    }                                                                                      // 138
  };                                                                                       // 139
                                                                                           // 140
  ServerMonitor.prototype.generateSessionKey = function() {                                // 141
    return "" + this.serverId + "-" + (Random.id());                                       // 142
  };                                                                                       // 143
                                                                                           // 144
  ServerMonitor.prototype.onStartup = function() {                                         // 145
    this.started = true;                                                                   // 146
    if (this.heartbeat == null) {                                                          // 147
      presences.remove({});                                                                // 148
    } else {                                                                               // 149
      this.serverHeartbeats = new Mongo.Collection('presence.servers');                    // 150
      this.serverHeartbeats.insert({                                                       // 151
        _id: this.serverId,                                                                // 152
        lastSeen: new Date()                                                               // 153
      });                                                                                  // 154
      this.heartbeat.start(this.pulse);                                                    // 155
    }                                                                                      // 156
  };                                                                                       // 157
                                                                                           // 158
  ServerMonitor.prototype.pulse = function() {                                             // 159
    var serverIds, verify;                                                                 // 160
    verify = this.serverHeartbeats.upsert({                                                // 161
      _id: this.serverId                                                                   // 162
    }, {                                                                                   // 163
      $set: {                                                                              // 164
        lastSeen: new Date()                                                               // 165
      }                                                                                    // 166
    });                                                                                    // 167
    if (verify.insertedId != null) {                                                       // 168
      console.warn("Presence: Server Timeout - Presence lost for current connections");    // 169
    }                                                                                      // 170
    this.serverHeartbeats.remove({                                                         // 171
      lastSeen: {                                                                          // 172
        $lt: new Date(new Date().getTime() - this.options.timeout)                         // 173
      }                                                                                    // 174
    });                                                                                    // 175
    serverIds = _.pluck(this.serverHeartbeats.find({}).fetch(), "_id");                    // 176
    presences.remove({                                                                     // 177
      serverId: {                                                                          // 178
        $nin: serverIds                                                                    // 179
      }                                                                                    // 180
    });                                                                                    // 181
    this.heartbeat.tock();                                                                 // 182
  };                                                                                       // 183
                                                                                           // 184
  ServerMonitor.prototype.hash = function(userId, value) {                                 // 185
    if (this.options.hash !== null) {                                                      // 186
      return this.options.hash(userId + this.options.salt, value);                         // 187
    } else {                                                                               // 188
      return value;                                                                        // 189
    }                                                                                      // 190
  };                                                                                       // 191
                                                                                           // 192
  return ServerMonitor;                                                                    // 193
                                                                                           // 194
})();                                                                                      // 195
                                                                                           // 196
this.ServerMonitor = ServerMonitor;                                                        // 197
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                           // 199
}).call(this);                                                                             // 200
                                                                                           // 201
                                                                                           // 202
                                                                                           // 203
                                                                                           // 204
                                                                                           // 205
                                                                                           // 206
(function () {                                                                             // 207
                                                                                           // 208
//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/3stack:presence/lib/server/presence.coffee.js                               //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                           // 216
                                                                                           // 217
Presence = new ServerMonitor();                                                            // 218
                                                                                           // 219
Meteor.onConnection(function(connection) {                                                 // 220
  var now;                                                                                 // 221
  connection.sessionKey = Presence.generateSessionKey();                                   // 222
  now = new Date();                                                                        // 223
  presences.insert({                                                                       // 224
    _id: connection.sessionKey,                                                            // 225
    serverId: Presence.serverId,                                                           // 226
    clientAddress: connection.clientAddress,                                               // 227
    status: 'connecting',                                                                  // 228
    connectedAt: now,                                                                      // 229
    lastSeen: now,                                                                         // 230
    state: {},                                                                             // 231
    userId: null                                                                           // 232
  });                                                                                      // 233
  connection.onClose(function() {                                                          // 234
    presences.remove({                                                                     // 235
      _id: connection.sessionKey                                                           // 236
    });                                                                                    // 237
  });                                                                                      // 238
});                                                                                        // 239
                                                                                           // 240
Meteor.publish(null, function() {                                                          // 241
  var hashedToken;                                                                         // 242
  presences.update({                                                                       // 243
    _id: this.connection.sessionKey,                                                       // 244
    status: 'connecting'                                                                   // 245
  }, {                                                                                     // 246
    $set: {                                                                                // 247
      status: 'connected'                                                                  // 248
    }                                                                                      // 249
  });                                                                                      // 250
  hashedToken = null;                                                                      // 251
  if (this.userId != null) {                                                               // 252
    hashedToken = Accounts._getLoginToken(this.connection.id);                             // 253
    hashedToken = Presence.hash(this.userId, hashedToken);                                 // 254
  }                                                                                        // 255
  presences.update({                                                                       // 256
    _id: this.connection.sessionKey                                                        // 257
  }, {                                                                                     // 258
    $set: {                                                                                // 259
      loginToken: hashedToken,                                                             // 260
      userId: this.userId,                                                                 // 261
      lastSeen: new Date()                                                                 // 262
    }                                                                                      // 263
  });                                                                                      // 264
  this.ready();                                                                            // 265
});                                                                                        // 266
                                                                                           // 267
Meteor.methods({                                                                           // 268
  'setPresence': function(state) {                                                         // 269
    check(state, Match.Any);                                                               // 270
    this.unblock();                                                                        // 271
    presences.update({                                                                     // 272
      _id: this.connection.sessionKey                                                      // 273
    }, {                                                                                   // 274
      $set: {                                                                              // 275
        userId: this.userId,                                                               // 276
        lastSeen: new Date(),                                                              // 277
        state: state,                                                                      // 278
        status: 'online'                                                                   // 279
      }                                                                                    // 280
    });                                                                                    // 281
    return null;                                                                           // 282
  }                                                                                        // 283
});                                                                                        // 284
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                           // 286
}).call(this);                                                                             // 287
                                                                                           // 288
/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['3stack:presence'] = {
  Presence: Presence,
  presences: presences
};

})();

//# sourceMappingURL=3stack_presence.js.map
